# Réconciliation locale `revenu_de_base` — correctif v4 de l’utilitaire — 1.2.81 / 0.4.85 / 2.16.14

Ce paquet **ne modifie ni la norme, ni le validateur, ni le kit**. Il corrige uniquement les garde-fous du script local de réconciliation du débat `revenu_de_base`.

## Défauts corrigés

### 1. Absence historique des résumés

La première version de l’utilitaire représentait les résumés historiquement absents par une chaîne vide. Depuis la v2, le script reconstruit temporairement les variantes `null`, champ omis et chaîne vide, puis n’accepte que `null` ou champ omis si cette représentation reproduit exactement l’empreinte restaurée scellée :

```text
59ee182dafd35835829f432cbec7a7a14b07f53a9c6acac64ce747dbb1f0f4ee
```

La chaîne vide ne peut jamais être appliquée.

### 2. Pages restaurées ≠ ensemble du checkpoint français

Depuis la v3, l’utilitaire distingue :

- les **168 pages françaises rendues**, toutes relues et comparées ;
- les **104 pages/opérations du payload de restauration**, qui reçoivent en plus un contrôle exact de `introduction` ou `résumé` ;
- les 64 autres pages, qui restent intégralement contrôlées mais ne sont pas supposées avoir une restauration.

### 3. Comparaison MediaWiki alignée sur le kit 2.16.14

La v3 comparait `page.text` au fichier rendu **octet pour octet**. Or le moteur de publication du kit 2.16.14 utilise `wikidebia_publish.normalize_wikicode`, qui :

1. normalise `CRLF`/`CR` en `LF` ;
2. ignore les sauts de ligne terminaux pour décider si deux contenus MediaWiki sont équivalents ;
3. calcule les SHA de contenu publiés à partir de cette représentation normalisée.

Cette différence expliquait un résultat possible de `0/168` correspondances brutes alors que tous les paramètres de premier niveau étaient identiques.

La v4 applique **exactement le même contrat de normalisation** pour :

- la comparaison distant ↔ rendu désiré ;
- les SHA de contenu comparés à `.state/published` ;
- la décision `NO_FRENCH_PUBLICATION_REMAINS_BEFORE_ENGLISH`.

Le rapport conserve parallèlement les métriques brutes :

- `raw_exact_desired_page_matches` ;
- `serialization_only_page_differences` ;
- `wikicode_equivalent_page_matches`.

Une différence qui ne disparaît pas avec la normalisation du kit reste bloquante et est détaillée paramètre par paramètre.

## Préflight uniquement

```bash
rm -rf /tmp/revenu1281-local-reconcile
mkdir -p /tmp/revenu1281-local-reconcile

unzip -q revenu_de_base_local_reconciliation_v4_1.2.81.zip \
  -d /tmp/revenu1281-local-reconcile

./.venv/bin/python \
  /tmp/revenu1281-local-reconcile/reconcile_revenu_de_base_local_state_1281.py \
  .
```

**Ne pas utiliser `--apply-local` tant que le préflight n’a pas conclu** `NO_FRENCH_PUBLICATION_REMAINS_BEFORE_ENGLISH` avec `restore_receipt_valid: true`.

Le rapport est écrit dans :

```text
.state/manual-repairs/revenu_de_base_local_reconciliation_1.2.81/inspection.json
```

Le préflight n’effectue aucune écriture MediaWiki. Il peut écrire uniquement son rapport local de diagnostic/inspection.

## Important

Ne pas relancer `./wikidebia workflow` à ce stade. La réconciliation locale doit d’abord être prouvée puis appliquée. Le correctif générique de préservation historique est traité séparément du nettoyage de cet état 1.2.81.
