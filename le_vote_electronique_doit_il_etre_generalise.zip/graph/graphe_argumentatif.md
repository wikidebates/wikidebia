# Graphe argumentatif importé — Le vote électronique doit-il être généralisé ?

Statut : brouillon importé, non verrouillé.

## Compteurs normatifs

- Nœuds distincts : 99
- Relations : 91
- Occurrences normatives : 102
- Réutilisations supplémentaires : 3
- Profondeur maximale : 4

## Arguments principaux

### Pour

- `A0001` Le vote électronique facilite la mise en place de consultations
- `A0002` Le vote électronique favorise la participation aux élections
- `A0003` Le vote électronique permet de diminuer les coûts d'une élection
- `A0004` Le vote électronique diminue l'empreinte écologique du vote
- `A0005` Le vote électronique permet la mise en oeuvre de méthodes de vote sophistiquées

### Contre

- `A0006` Le vote électronique n'est pas fiable
- `A0007` Le vote électronique est invérifiable et opaque
- `A0008` Le vote électronique expose davantage les électeurs aux pressions
- `A0009` Le vote électronique désacralise l'acte de vote
- `A0010` Le vote électronique a été abandonné par la plupart des pays qui l'ont expérimenté
- `A0011` Le vote papier est plus simple et plus fiable que le vote électronique

## Relations

- `E00001` `A0001` → **justification** → `A0012`
- `E00002` `A0001` → **justification** → `A0014`
- `E00003` `A0001` → **objection** → `A0015`
- `E00004` `A0001` → **justification** → `A0016`
- `E00005` `A0002` → **justification** → `A0017`
- `E00006` `A0002` → **objection** → `A0013`
- `E00007` `A0002` → **objection** → `A0018`
- `E00008` `A0002` → **justification** → `A0019`
- `E00009` `A0002` → **objection** → `A0020`
- `E00010` `A0002` → **justification** → `A0021`
- `E00011` `A0002` → **objection** → `A0022`
- `E00012` `A0002` → **justification** → `A0023`
- `E00013` `A0002` → **justification** → `A0024`
- `E00014` `A0002` → **justification** → `A0025`
- `E00015` `A0003` → **justification** → `A0026`
- `E00016` `A0003` → **objection** → `A0027`
- `E00017` `A0003` → **justification** → `A0028`
- `E00018` `A0003` → **objection** → `A0029`
- `E00019` `A0003` → **justification** → `A0030`
- `E00020` `A0003` → **objection** → `A0031`
- `E00021` `A0003` → **objection** → `A0032`
- `E00022` `A0003` → **objection** → `A0033`
- `E00023` `A0004` → **justification** → `A0026`
- `E00024` `A0004` → **objection** → `A0034`
- `E00025` `A0004` → **justification** → `A0035`
- `E00026` `A0006` → **justification** → `A0036`
- `E00027` `A0006` → **objection** → `A0014`
- `E00028` `A0006` → **justification** → `A0037`
- `E00029` `A0006` → **objection** → `A0038`
- `E00030` `A0006` → **justification** → `A0039`
- `E00031` `A0006` → **justification** → `A0040`
- `E00032` `A0006` → **justification** → `A0041`
- `E00033` `A0006` → **justification** → `A0042`
- `E00034` `A0007` → **justification** → `A0043`
- `E00035` `A0007` → **objection** → `A0044`
- `E00036` `A0007` → **justification** → `A0045`
- `E00037` `A0007` → **justification** → `A0046`
- `E00038` `A0007` → **justification** → `A0047`
- `E00039` `A0007` → **justification** → `A0048`
- `E00040` `A0008` → **justification** → `A0049`
- `E00041` `A0008` → **justification** → `A0050`
- `E00042` `A0008` → **justification** → `A0051`
- `E00043` `A0008` → **justification** → `A0052`
- `E00044` `A0009` → **justification** → `A0053`
- `E00045` `A0009` → **justification** → `A0054`
- `E00046` `A0010` → **objection** → `A0055`
- `E00047` `A0010` → **objection** → `A0056`
- `E00048` `A0010` → **objection** → `A0057`
- `E00049` `A0012` → **objection** → `A0058`
- `E00050` `A0012` → **objection** → `A0059`
- `E00051` `A0012` → **objection** → `A0060`
- `E00052` `A0013` → **objection** → `A0061`
- `E00053` `A0013` → **objection** → `A0062`
- `E00054` `A0014` → **objection** → `A0060`
- `E00055` `A0019` → **objection** → `A0063`
- `E00056` `A0019` → **objection** → `A0064`
- `E00057` `A0020` → **objection** → `A0065`
- `E00058` `A0020` → **objection** → `A0066`
- `E00059` `A0022` → **objection** → `A0068`
- `E00060` `A0023` → **objection** → `A0069`
- `E00061` `A0024` → **objection** → `A0070`
- `E00062` `A0025` → **objection** → `A0067`
- `E00063` `A0025` → **objection** → `A0071`
- `E00064` `A0025` → **objection** → `A0072`
- `E00065` `A0025` → **objection** → `A0073`
- `E00066` `A0025` → **objection** → `A0074`
- `E00067` `A0025` → **objection** → `A0075`
- `E00068` `A0026` → **objection** → `A0076`
- `E00069` `A0028` → **objection** → `A0077`
- `E00070` `A0028` → **objection** → `A0078`
- `E00071` `A0028` → **objection** → `A0079`
- `E00072` `A0030` → **objection** → `A0080`
- `E00073` `A0030` → **objection** → `A0081`
- `E00074` `A0035` → **objection** → `A0082`
- `E00075` `A0036` → **justification** → `A0083`
- `E00076` `A0038` → **objection** → `A0084`
- `E00077` `A0038` → **objection** → `A0085`
- `E00078` `A0039` → **objection** → `A0086`
- `E00079` `A0040` → **objection** → `A0087`
- `E00080` `A0040` → **objection** → `A0088`
- `E00081` `A0041` → **objection** → `A0090`
- `E00082` `A0043` → **objection** → `A0091`
- `E00083` `A0043` → **objection** → `A0089`
- `E00084` `A0044` → **objection** → `A0092`
- `E00085` `A0044` → **objection** → `A0093`
- `E00086` `A0044` → **objection** → `A0094`
- `E00087` `A0045` → **objection** → `A0095`
- `E00088` `A0059` → **objection** → `A0096`
- `E00089` `A0059` → **objection** → `A0097`
- `E00090` `A0086` → **objection** → `A0098`
- `E00091` `A0095` → **objection** → `A0099`
