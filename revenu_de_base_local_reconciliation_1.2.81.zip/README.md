# Réconciliation locale `revenu_de_base` après restauration historique — 1.2.81 / 0.4.85 / 2.16.14

Ce paquet **ne modifie ni la norme, ni le validateur, ni le kit**. Il est spécifique à :

- `debate_id = revenu_de_base`
- `work_id = EDIT-20260811-001`
- norme `1.2.81`
- validateur `0.4.85`
- kit `2.16.14`

Il traite uniquement la divergence créée par la publication indésirable des résumés réécrits et de la nouvelle introduction, après leur restauration distante par `revenu_de_base_remote_restore_original_summaries_intro_v3_1.2.81.zip`.

## Ce que vérifie le préflight

Le mode par défaut est **lecture seule**. Il :

1. vérifie le triplet exact `1.2.81 / 0.4.85 / 2.16.14` ;
2. vérifie le payload de restauration et son empreinte ;
3. vérifie `workflow.json`, `workspace.json` et le verrou français ;
4. reconstruit dans un dossier temporaire le verrou corrigé :
   - introduction historique exacte ;
   - 57 résumés historiques exacts ;
   - 46 absences historiques de `|résumé=` ;
5. exige que le verrou reconstruit ait exactement SHA-256 `59ee182dafd35835829f432cbec7a7a14b07f53a9c6acac64ce747dbb1f0f4ee` ;
6. rend temporairement les 104 pages françaises désirées avec le kit 2.16.14 ;
7. relit les 104 pages du wiki **sans écrire** et compare leur texte complet au rendu désiré ;
8. calcule le delta français restant paramètre par paramètre ;
9. vérifie si `.state/published` est devenu obsolète après la restauration ;
10. détecte tout paquet ou artefact anglais préparé depuis l'ancien verrou.

Commande :

```bash
rm -rf /tmp/revenu1281-local-reconcile
mkdir -p /tmp/revenu1281-local-reconcile
unzip -q revenu_de_base_local_reconciliation_1.2.81.zip -d /tmp/revenu1281-local-reconcile
./.venv/bin/python \
  /tmp/revenu1281-local-reconcile/reconcile_revenu_de_base_local_state_1281.py \
  .
```

Le rapport est écrit dans :

```text
.state/manual-repairs/revenu_de_base_local_reconciliation_1.2.81/inspection.json
```

Aucune écriture MediaWiki n'est implémentée dans ce script.

## Application locale

**Ne l'utiliser que si le préflight conclut :**

```text
NO_FRENCH_PUBLICATION_REMAINS_BEFORE_ENGLISH
```

et si `restore_receipt_valid=true`.

Alors :

```bash
./.venv/bin/python \
  /tmp/revenu1281-local-reconcile/reconcile_revenu_de_base_local_state_1281.py \
  . --apply-local
```

Cette étape :

- corrige uniquement `content-reviewed-copy/data/fr_content_lock.json` pour les 104 champs couverts par le payload propriétaire ;
- remet à jour l'empreinte de `content-reviewed-copy` et de `workspace.json` ;
- rafraîchit `.state/published/revenu_de_base/fr/latest.json` avec les révisions et empreintes **exactement relues** après restauration ;
- invalide/archive uniquement les artefacts anglais dérivés de l'ancien verrou, s'il y en a ;
- remplace dans le workflow l'interprétation du checkpoint de contenu par une attestation de réconciliation manuelle, sans republier le checkpoint ;
- conserve les anciens plans/reçus de checkpoint pour l'audit ;
- crée une sauvegarde locale avant modification et effectue un rollback transactionnel complet si un contrôle final échoue ;
- ne touche pas à `reviewed-copy/`, au graphe validé, aux titres validés, aux rubriques, mots-clés ou références déjà publiés ;
- ne réécrit pas les anciens fichiers de revue française qui documentent la revue fautive : ils restent conservés comme provenance/audit, tandis que le verrou effectif restauré et l’attestation de réconciliation les supersèdent pour les 104 champs concernés ;
- ne lance ni `workflow`, ni `review-import`, ni aucune écriture MediaWiki.

Le reçu est écrit dans :

```text
.state/manual-repairs/revenu_de_base_local_reconciliation_1.2.81/receipt.json
```

## Garde-fous

L'application locale est refusée si :

- le verrou n'est ni l'ancien verrou fautif exact ni le verrou restauré exact ;
- le reçu de restauration distante est absent/invalide ;
- une des 104 pages distantes ne correspond pas exactement au rendu français désiré ;
- une divergence distante non expliquée est détectée ;
- une traduction a déjà été finalisée/appliquée ;
- une revue autre que la revue anglaise est en attente ;
- une empreinte locale scellée est incohérente.

Ce paquet est une réparation d'état **spécifique au corpus**. Il ne corrige volontairement pas le défaut générique du kit concernant la préservation par défaut de l'introduction et des résumés historiques ; cette correction générique doit être faite plus tard, séparément, avec bump de version.

## Interprétation du résultat

Le script ne présume pas que le delta français est nul. Il le **prouve ou le réfute** par comparaison de texte complet sur les 104 pages actives couvertes par la restauration.

- `NO_FRENCH_PUBLICATION_REMAINS_BEFORE_ENGLISH` signifie que l'état distant courant est déjà exactement le rendu français désiré après restauration : aucune troisième publication française ne doit être lancée.
- `FRENCH_DELTA_REMAINS_OR_REMOTE_DIVERGENCE` signifie qu'au moins une page diffère ; `inspection.json` donne les pages et paramètres concernés, et `--apply-local` reste bloqué.

La réconciliation locale ne vaut pas correction générique de la politique de contenu historique. Avant de reprendre la traduction avec le workflow normal, le défaut générique de préservation des résumés et de l'introduction historiques doit être traité séparément comme demandé par le propriétaire.
