# Initialisation du corpus — Un revenu de base doit-il être instauré ?

Statut : `graph_draft`.

- Nœuds : 171
- Relations : 179
- Occurrences normatives : 191
- Pages sources importées : 172
- Normalisations ou replis consignés : 50

Les fichiers `imports/fr/` ne sont pas des pages de sortie validées.
