# Revue du graphe et des placements

Débat : `revenu_de_base`

Ce paquet a été préparé par Wikidéb’IA pour une intervention éditoriale externe.
Ne modifiez que les fichiers placés sous `editable/`. Les fichiers sous `context/` sont des sources en lecture seule.
Ne renommez, n'ajoutez et ne supprimez aucun fichier du ZIP.
Le fichier `REVIEW_PACKAGE.json` ne doit jamais être modifié.

## Fichiers à compléter

- `editable/reviews/graph_build_review.json`
- `editable/reviews/graph_placement_review.json`

Après la revue, rendez un ZIP conservant exactement la même structure. L'utilisateur lancera `./wikidebia review-import <debate_id> <zip>`.
