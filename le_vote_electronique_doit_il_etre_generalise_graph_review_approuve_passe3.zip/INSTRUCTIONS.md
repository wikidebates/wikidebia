# Revue du graphe et des placements

Débat : `le_vote_electronique_doit_il_etre_generalise`

Ce paquet a été préparé par Wikidéb’IA pour une intervention éditoriale externe.
Ne modifiez que les fichiers placés sous `editable/`. Les fichiers sous `context/` sont des sources en lecture seule.
Ne renommez, n'ajoutez et ne supprimez aucun fichier du ZIP.
Le fichier `REVIEW_PACKAGE.json` ne doit jamais être modifié.

Si la revue exige une modification structurelle, renseignez pour l'occurrence concernée l'objet `correction`.
Actions prises en charge : `remove`, `merge_redirect`, `move` et `relation_change`.
Pour `merge_redirect`, indiquez `target_node_id` : la page doublon deviendra `#REDIRECTION [[Titre de destination]]` et son lien sera retiré de la page mère.
Pour `remove`, indiquez `page_disposition=delete` : le lien sera retiré de la page mère avant suppression de la page.
Les résumés MediaWiki doivent être individualisés. Pour un doublon, le résumé de la page mère doit contenir le titre de destination sous la forme `[[Titre de destination]]`.
Une revue rejetée comportant ces décisions pourra être appliquée par `./wikidebia review-import <debate_id> <zip> --execute-graph-actions`.
Après application, Wikidéb’IA reconstruira le graphe et préparera une nouvelle revue complète avant toute promotion.

## Fichiers à compléter

- `editable/reviews/graph_build_review.json`
- `editable/reviews/graph_placement_review.json`

Après la revue, rendez un ZIP conservant exactement la même structure. L'utilisateur lancera `./wikidebia review-import <debate_id> <zip>`.
