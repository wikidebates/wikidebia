# Initialisation du corpus — Le vote électronique doit-il être généralisé ?

Statut : `graph_draft`.

- Nœuds : 99
- Relations : 91
- Occurrences normatives : 102
- Pages sources importées : 100
- Normalisations ou replis consignés : 8

Les fichiers `imports/fr/` ne sont pas des pages de sortie validées.
