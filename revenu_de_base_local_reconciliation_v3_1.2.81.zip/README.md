# Réconciliation locale `revenu_de_base` — correctif v3 de l’utilitaire — 1.2.81 / 0.4.85 / 2.16.14

Ce paquet **ne modifie ni la norme, ni le validateur, ni le kit**. Il corrige uniquement les garde-fous du script local de réconciliation du débat `revenu_de_base`.

## Défauts corrigés

### 1. Absence historique des résumés

La première version de l’utilitaire représentait les résumés historiquement absents par une chaîne vide. La v2 a corrigé ce point : le script reconstruit temporairement les variantes `null`, champ omis et chaîne vide, puis n’accepte que `null` ou champ omis si cette représentation reproduit exactement l’empreinte restaurée scellée :

```text
59ee182dafd35835829f432cbec7a7a14b07f53a9c6acac64ce747dbb1f0f4ee
```

La chaîne vide ne peut jamais être appliquée.

### 2. Confusion entre pages restaurées et pages du checkpoint français

La v2 exigeait à tort que le payload de restauration couvre toutes les pages du checkpoint français. Sur l’état réel, le rendu français contient **168 pages**, alors que la restauration manuelle concerne **104 pages/opérations** seulement : une introduction et 103 résumés.

La v3 distingue désormais les deux ensembles :

- les **168 pages françaises rendues** sont toutes lues sur le wiki et comparées intégralement au rendu français réconcilié ;
- les **104 pages couvertes par le payload** font en plus l’objet d’un contrôle exact de la valeur restaurée (`introduction` ou `résumé`) ;
- les 64 autres pages ne sont pas supposées avoir une opération de restauration, mais elles restent soumises à la comparaison intégrale de leur wikicode ;
- toute opération du payload visant une page absente du rendu, ou présentant un type/titre incohérent, bloque toujours le préflight.

Ainsi, la conclusion :

```text
NO_FRENCH_PUBLICATION_REMAINS_BEFORE_ENGLISH
```

n’est possible que si **168/168 pages** correspondent exactement au rendu réconcilié et si **104/104 restaurations** correspondent exactement au payload.

## Préflight uniquement

```bash
rm -rf /tmp/revenu1281-local-reconcile
mkdir -p /tmp/revenu1281-local-reconcile

unzip -q revenu_de_base_local_reconciliation_v3_1.2.81.zip \
  -d /tmp/revenu1281-local-reconcile

./.venv/bin/python \
  /tmp/revenu1281-local-reconcile/reconcile_revenu_de_base_local_state_1281.py \
  .
```

**Ne pas utiliser `--apply-local` tant que le préflight n’a pas conclu** `NO_FRENCH_PUBLICATION_REMAINS_BEFORE_ENGLISH` avec `restore_receipt_valid: true`.

Le rapport est écrit dans :

```text
.state/manual-repairs/revenu_de_base_local_reconciliation_1.2.81/inspection.json
```

Le préflight n’effectue aucune écriture MediaWiki. Il peut écrire uniquement son rapport local de diagnostic/inspection.

## Important

Ne pas relancer `./wikidebia workflow` à ce stade. La réconciliation locale doit d’abord être prouvée puis appliquée ; la correction générique du défaut de préservation historique du kit viendra ensuite, séparément.
