# Audit du prototype bilingue

Les dix paires couvrent les deux camps, trois profondeurs, les justifications, les objections et une réponse de troisième niveau. Les titres restent autonomes ; les ouvertures partent de mécanismes différents ; aucune phrase ne sert de patron à une autre page. Les images conservées (trappe, branches porteuses, portes latérales, dalle de béton) éclairent des mécanismes distincts et ne sont pas reprises dans le corpus. L'anglais a été réécrit idiomatiquement ; la logique et la portée demeurent équivalentes.
