# Réaudit documentaire des pages Débat et Debate

Date : 31 juillet 2026.

## Diagnostic initial

La page française contenait 19 notices et la page anglaise 18. Les neuf paramètres documentaires étaient techniquement remplis, mais la sélection restait trop proche du plancher automatique de deux notices par paramètre au regard de l'abondance de la littérature juridique, économique et sociale sur la protection de l'emploi.

## Enrichissement

Chaque page contient désormais :

- trois références bibliographiques pour, trois contre et trois de synthèse ;
- trois références sitographiques pour, trois contre et trois de synthèse ;
- deux références vidéographiques pour, deux contre et deux de synthèse.

Le total atteint 24 notices distinctement positionnées par langue. Les ajouts français renforcent le standard international de l'OIT, les analyses de sécurisation des parcours et la synthèse récente de l'OCDE. Les ajouts anglais approfondissent l'innovation, les effets de la réglementation, la répartition du revenu du travail, les coûts humains des restructurations et les comparaisons institutionnelles.

## Choix concernant la vidéographie

La vidéographie reste à deux références par position. L'audit n'a pas transformé cette famille en quota : les documents audiovisuels supplémentaires repérés n'apportaient pas une valeur documentaire suffisante ou une attribution assez solide pour justifier leur insertion.

## Conclusion

La documentation n'est plus une simple conformité au minimum. Les bibliographies et sitographies offrent trois angles substantiels par position, tandis que la vidéographie demeure volontairement plus resserrée et vérifiée.
