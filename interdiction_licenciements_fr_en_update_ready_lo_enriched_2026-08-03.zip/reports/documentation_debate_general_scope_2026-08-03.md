# Révision documentaire des pages de débat — interdiction générale des licenciements

## Périmètre

Les références ont été retenues uniquement lorsqu’elles portent sur le licenciement à l’initiative de l’employeur, la protection générale de l’emploi, le licenciement injustifié, l’emploi de gré à gré, les motifs valables, les procédures ou les effets transversaux de la réglementation. Les ressources limitées aux licenciements économiques, collectifs, « boursiers », à une restructuration ou à un secteur particulier ont été retirées des pages de débat.

## Volumes retenus

### Français
- Bibliographie: 6 pour, 6 contre, 6 neutres.
- Sitographie: 9 pour, 9 contre, 9 neutres.
- Vidéographie: 3 pour, 3 contre, 3 neutres.

### English
- Bibliographie: 6 pour, 6 contre, 6 neutres.
- Sitographie: 9 pour, 9 contre, 9 neutres.
- Vidéographie: 3 pour, 3 contre, 3 neutres.

**Total des références structurées sur les deux pages : 108.**

## Contrôle de portée

- Aucun titre retenu ne se limite aux licenciements boursiers.
- Aucun titre retenu ne se limite à un plan de sauvegarde de l’emploi ou à un licenciement collectif.
- Les textes comparatifs sur la protection de l’emploi couvrent les licenciements individuels ordinaires et les règles générales de rupture.
- Les vidéos, moins abondantes, ont été limitées aux contenus généraux sur le licenciement injustifié, le licenciement avec ou sans cause, la procédure ou les réformes générales.

## Références retirées des pages de débat pour portée trop étroite

- Rapports centrés sur les restructurations, plans de sauvegarde de l’emploi, mutations industrielles ou licenciements collectifs.
- Vidéos centrées sur une fermeture d’usine, une vague de licenciements, les salariés protégés ou les transitions collectives.
- Pages de code et statistiques traitant uniquement du licenciement économique ou du chômage sans éclairer la règle générale.

## Catalogue synthétique

### Français
#### Bibliographie — Pour
- Conseil de l'emploi, des revenus et de la cohésion sociale — La sécurité de l'emploi face aux défis des transformations économiques — https://www.vie-publique.fr/files/rapport/pdf/054000141.pdf
- Bureau international du Travail — Note sur la convention n° 158 et la recommandation n° 166 sur le licenciement — https://www.ilo.org/fr/media/137206/download
- Alain Supiot — Critique du droit du travail — https://www.puf.com/critique-du-droit-du-travail
- Alain Supiot — Au-delà de l'emploi : transformations du travail et devenir du droit du travail en Europe — https://editions.flammarion.com/au-dela-de-lemploi/9782081382862
- Bureau international du Travail — Protection contre le licenciement injustifié : étude d’ensemble sur la convention n° 158 et la recommandation n° 166 — https://www.ilo.org/fr/media/156686/download
- Michèle Bonnechère — Travail et emploi — https://journals.openedition.org/travailemploi/pdf/2324

#### Bibliographie — Contre
- Conseil d'orientation pour l'emploi — Rapport d'étape sur la sécurisation et la dynamisation des parcours professionnels — https://www.vie-publique.fr/files/rapport/pdf/094000031.pdf
- Pierre Cahuc, Francis Kramarz — De la précarité à la mobilité : vers une sécurité sociale professionnelle — https://www.vie-publique.fr/files/rapport/pdf/054000092.pdf
- Olivier Blanchard, Jean Tirole — Protection de l'emploi et procédures de licenciement — https://cae-eco.fr/static/pdf/044.pdf
- Pierre Cahuc — Pour une meilleure protection de l'emploi — https://www.econbiz.de/Record/pour-une-meilleure-protection-de-l-emploi-cahuc-pierre/10001905478
- Organisation de coopération et de développement économiques — Perspectives de l'emploi de l'OCDE 2004 — https://www.oecd.org/content/dam/oecd/fr/publications/reports/2004/07/oecd-employment-outlook-2004_g1gh4498/empl_outlook-2004-fr.pdf
- Gordon Betcherman — Réglementations de protection de l’emploi : règles d’embauche et de licenciement — https://documents1.worldbank.org/curated/en/589401468779650678/pdf/301300FRENCH0E1mployment0regulation.pdf

#### Bibliographie — Ni pour ni contre
- Organisation de coopération et de développement économiques — Perspectives de l'emploi de l'OCDE 2026 : Disparités géographiques en matière d'emploi et de revenus — https://www.oecd.org/fr/publications/perspectives-de-l-emploi-de-l-ocde-2026_f8a23d95-fr.html
- Xavier Berjot — Le licenciement : le guide pratique — https://www.lgdj.fr/le-licenciement-9782124653836.html
- Michel Miné — Le grand livre du droit du travail — https://www.editions-eyrolles.com/livre/le-grand-livre-du-droit-du-travail
- Thierry Kirat, Évelyne Serverin, Julie Valentin, Damien Sauze, Raphaël Dalmasso — Revue de l'OFCE — https://shs.hal.science/halshs-00365518/document
- Alain Supiot — Le droit du travail — https://www.quesaisje.com/le-droit-du-travail
- Camille Signoretto — Travail et emploi — https://dares.travail-emploi.gouv.fr/sites/default/files/pdf/142_travail_et_emploi_signoretto.pdf

#### Sitographie — Pour
- Organisation internationale du Travail — Protection de l'emploi — https://www.ilo.org/fr/protection-de-lemploi
- Organisation internationale du Travail — Convention n° 158 sur le licenciement, 1982 — https://normlex.ilo.org/dyn/nrmlx_fr/f?p=NORMLEXPUB:12100:0::NO::P12100_ILO_CODE:C158
- Organisation internationale du Travail — Recommandation n° 166 sur le licenciement, 1982 — https://normlex.ilo.org/dyn/nrmlx_fr/f?p=NORMLEXPUB:12100:0::NO::P12100_ILO_CODE:R166
- Union européenne — Charte des droits fondamentaux de l'Union européenne — https://eur-lex.europa.eu/legal-content/FR/TXT/HTML/?uri=CELEX:12012P/TXT
- Conseil de l'Europe — Charte sociale européenne révisée — https://rm.coe.int/168007cf94
- Comité des droits économiques, sociaux et culturels des Nations unies — Observation générale n° 18 : le droit au travail — https://digitallibrary.un.org/record/566942/files/E_C.12_GC_18-FR.pdf
- Organisation internationale du Travail — Motifs valables et interdits de licenciement — https://eplex.ilo.org/fr/valid-and-prohibited-grounds-for-dismissal
- Agence des droits fondamentaux de l’Union européenne — Article 30 — Protection en cas de licenciement injustifié — https://fra.europa.eu/fr/eu-charter/article/30-protection-en-cas-de-licenciement-injustifie
- Organisation internationale du Travail — Helpdesk du BIT : Questions-réponses sur les entreprises et la sécurité de l’emploi — https://www.ilo.org/fr/helpdesk-du-bit-questionsreponses-sur-les-entreprises-et-la-securite-de

#### Sitographie — Contre
- Organisation de coopération et de développement économiques — Évolutions récentes de la législation sur la protection de l'emploi — https://www.oecd.org/fr/publications/perspectives-de-l-emploi-de-l-ocde-2026_f8a23d95-fr/full-report/component-10.html
- Organisation de coopération et de développement économiques — Indicateurs de la législation sur la protection de l'emploi — https://www.oecd.org/fr/data/datasets/oecd-indicators-of-employment-protection.html
- Organisation de coopération et de développement économiques — Perspectives de l'emploi de l'OCDE 2020 — https://www.oecd.org/fr/publications/perspectives-de-l-emploi-de-l-ocde-2020_b1547de3-fr.html
- Organisation de coopération et de développement économiques — Des emplois de qualité pour tous dans un monde du travail en mutation — https://www.oecd.org/fr/publications/des-emplois-de-qualite-pour-tous-dans-un-monde-du-travail-en-mutation_4e6a92fa-fr/full-report/component-11.html
- Organisation de coopération et de développement économiques — La réglementation de l'emploi et les formes de travail dans les pays de l'OCDE — https://www.oecd.org/fr/social/marchedutravailcapitalhumainetinegalites/33942945.pdf
- Conseil constitutionnel — La constitutionnalisation du droit du travail : étude d’une dynamique contemporaine — https://www.conseil-constitutionnel.fr/publications/titre-vii/la-constitutionnalisation-du-droit-du-travail-etude-d-une-dynamique-contemporaine
- Jacques Barthélémy, Gilbert Cette — Refondation du droit social : concilier protection des travailleurs et efficacité économique — https://www.vie-publique.fr/rapport/30923-refondation-du-droit-social-concilier-protection-des-travailleurs-et-e
- Organisation de coopération et de développement économiques — Protection de l’emploi et salaires minimums — https://www.oecd.org/fr/themes/protection-de-l-emploi-et-salaires-minimums.html
- Banque mondiale — Réglementation du marché du travail : les difficultés propres aux pays en développement — https://blogs.worldbank.org/fr/voices/reglementation-du-marche-du-travail-les-difficultes-propres-aux-pays-en-developpement

#### Sitographie — Ni pour ni contre
- Ministère du Travail — Rupture du contrat de travail — https://travail-emploi.gouv.fr/la-rupture-du-contrat-de-travail
- République française — Titre III : Rupture du contrat de travail à durée indéterminée — https://www.legifrance.gouv.fr/codes/id/LEGISCTA000006145396/
- Direction générale du travail — Questions-réponses sur la rupture du contrat de travail — https://travail-emploi.gouv.fr/sites/travail-emploi/files/files-spip/pdf/questions-reponses_rupture_contrat_travail.pdf
- Organisation internationale du Travail — Procédures de licenciements individuels — https://eplex.ilo.org/fr/node/73250
- Organisation internationale du Travail — Voies de recours et procédure contentieuse en cas de litiges individuels — https://eplex.ilo.org/fr/redress
- Organisation internationale du Travail — Objet et méthodologie de la base sur la législation de protection de l’emploi — https://eplex.ilo.org/fr/about-us
- Organisation internationale du Travail — France : situation au regard de la convention n° 158 — https://normlex.ilo.org/dyn/nrmlx_fr/f?p=NORMLEXPUB:11300:0::NO::P11300_INSTRUMENT_ID:312303
- Ministère du Travail — Droit du travail — https://code.travail.gouv.fr/droit-du-travail
- Direction de l’animation de la recherche, des études et des statistiques — Gestion des ruptures et analyse des fins de CDI — https://dares.travail-emploi.gouv.fr/enquete-source/gestion-des-ruptures-et-analyse-des-fins-de-cdi

#### Vidéographie — Pour
- Canal-Droits de Droits et perspectives du droit — Réparation du licenciement sans cause réelle et sérieuse — https://www.youtube.com/watch?v=0qb4QYxcgoA
- Canal-Droits de Droits et perspectives du droit — Présentation de la recherche contentieuse sur les indemnités de licenciement sans cause réelle et sérieuse — https://www.youtube.com/watch?v=VlKnQ8NKP2A
- Combien obtenir en cas de licenciement abusif ? — https://www.youtube.com/watch?v=GGp0lxwxqjY

#### Vidéographie — Contre
- M6 Info — Le Medef propose de créer un CDI pouvant être rompu sans motif — https://www.youtube.com/watch?v=EvrRvwdImcI
- Franceinfo — Réforme du Code du travail : les nouvelles règles des licenciements — https://www.dailymotion.com/video/x5z094f
- Barème « Macron » de licenciement et résiliation judiciaire du contrat — https://www.youtube.com/watch?v=S-kJ0wuaYag

#### Vidéographie — Ni pour ni contre
- Victor Leclaire - LégiPilot — Tout savoir sur le licenciement en 6 étapes et cas pratiques — https://www.youtube.com/watch?v=t-chY5lKbh8
- Le licenciement pour motif personnel : la procédure — https://www.youtube.com/watch?v=stIKqlpaAvc
- Le conseil de prud'hommes : comment cela fonctionne ? — https://www.youtube.com/watch?v=NPO2xsABVpA

### English
#### Bibliographie — Pour
- Jennie E. Brand — Annual Review of Sociology — https://pmc.ncbi.nlm.nih.gov/articles/PMC4553243/
- Guy Mundlak — International Labour Review — https://researchrepository.ilo.org/view/pdfCoverPage?download=true&filePid=13100788810002676&instCode=41ILO_INST
- Kate Andrias, Alexander Hertel-Fernandez — Ending At-Will Employment: A Guide for Just Cause Reform — https://rooseveltinstitute.org/wp-content/uploads/2021/01/RI_AtWill_Report_202101.pdf
- Janice R. Bellace — University of Michigan Journal of Law Reform — https://core.ac.uk/download/pdf/232713179.pdf
- Clyde W. Summers — University of Pennsylvania Journal of Labor and Employment Law — https://scholarship.law.upenn.edu/cgi/viewcontent.cgi?article=1000&context=jbl
- Hugh Collins — Justice in Dismissal: The Law of Termination of Employment — https://academic.oup.com/book/7530

#### Bibliographie — Contre
- John T. Addison, Paulino Teixeira — The Economy of Employment Protection — https://docs.iza.org/dp381.pdf
- World Bank, International Labour Organization — Balancing Regulations to Promote Jobs: From Employment Contracts to Unemployment Benefits — https://thedocs.worldbank.org/en/doc/725221530045131932-0160022017/render/Mar1011am101596REPLACEMENTWPPUBLIC12915Box394816BBalancingregulationstopromotejobsFINALwebversion.pdf
- David Alzate, Eliana Carranza, Joana Duran-Franch, Truman Packard, Celina Proffen — How Regulations Impact the Labor Market: A Review of the Literatures on Product and Labor Market Regulations — https://docs.iza.org/dp17536.pdf
- Richard A. Epstein — University of Chicago Law Review — https://chicagounbound.uchicago.edu/cgi/viewcontent.cgi?article=2290&context=journal_articles
- Edward P. Lazear — Quarterly Journal of Economics — https://www.nber.org/papers/w1177
- Juan C. Botero, Simeon Djankov, Rafael La Porta, Florencio López-de-Silanes, Andrei Shleifer — Quarterly Journal of Economics — https://shleifer.scholars.harvard.edu/publications/regulation-labor

#### Bibliographie — Ni pour ni contre
- Organisation for Economic Co-operation and Development — OECD Employment Outlook 2026 — https://www.oecd.org/en/publications/oecd-employment-outlook-2026_7e710f54-en.html
- International Labour Office — Note on Convention No. 158 and Recommendation No. 166 concerning termination of employment — https://www.ilo.org/media/137211/download
- Alexander Muravyev — Employment protection legislation in transition and emerging markets — https://wol.iza.org/uploads/articles/63/pdfs/employment-protection-legislation-and-labor-market-outcomes-in-transition-and-emerging-market-economies.pdf
- International Labour Organization — Employment protection legislation: Summary indicators in the area of terminating regular contracts — https://eplex.ilo.org/sites/default/files/2023-11/wcms_357390.pdf
- Stewart J. Schwab — Michigan Law Review — https://scholarship.law.cornell.edu/facpub/522/
- David Cabrelli — Employment Law: A Very Short Introduction — https://academic.oup.com/book/40199

#### Sitographie — Pour
- International Labour Organization — Termination of Employment Convention, 1982 (No. 158) — https://normlex.ilo.org/dyn/nrmlx_en/f?p=NORMLEXPUB:12100:0::NO::P12100_ILO_CODE:C158
- International Labour Organization — Termination of Employment Recommendation, 1982 (No. 166) — https://normlex.ilo.org/dyn/nrmlx_en/f?p=NORMLEXPUB:12100:0::NO::P12100_ILO_CODE:R166
- United Nations Committee on Economic, Social and Cultural Rights — General Comment No. 18: The Right to Work — https://digitallibrary.un.org/record/566942/files/E_C.12_GC_18-EN.pdf
- European Union — Charter of Fundamental Rights of the European Union — https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:12012P/TXT
- Council of Europe — European Social Charter (Revised) — https://rm.coe.int/168007cf93
- International Labour Organization — Employment protection — https://www.ilo.org/employment-protection
- International Labour Organization — Valid and prohibited grounds for dismissal — https://eplex.ilo.org/en/valid-and-prohibited-grounds-for-dismissal
- European Union Agency for Fundamental Rights — Article 30 — Protection in the event of unjustified dismissal — https://fra.europa.eu/en/eu-charter/article/30-protection-event-unjustified-dismissal
- International Labour Organization — ILO Helpdesk: Questions and answers on business and employment security — https://www.ilo.org/ilo-helpdesk-questions-and-answers-business-and-employment-security

#### Sitographie — Contre
- Organisation for Economic Co-operation and Development — OECD Indicators of Employment Protection — https://www.oecd.org/en/data/datasets/oecd-indicators-of-employment-protection.html
- Organisation for Economic Co-operation and Development — Recent trends in employment protection legislation — https://www.oecd.org/en/publications/oecd-employment-outlook-2026_7e710f54-en/full-report/component-10.html
- World Bank — Employment Regulation: Rules for Hiring and Termination — https://openknowledge.worldbank.org/entities/publication/cfa5c2dd-9dd6-5ceb-b14d-acfef347cdf2
- Organisation for Economic Co-operation and Development — Good Jobs for All in a Changing World of Work — https://www.oecd.org/en/publications/good-jobs-for-all-in-a-changing-world-of-work_9789264308817-en/full-report/component-11.html
- Cato Institute — Labor and Employment Law — https://www.cato.org/cato-handbook-policymakers/cato-handbook-policymakers-9th-edition-2022/labor-employment-law
- Cato Institute — Private Sector Labor Regulation — https://www.cato.org/publications/facilitating-personal-improvement-private-sector-labor-regulation
- The High Cost of Just Cause — https://www.econlib.org/econlog/the-high-cost-of-just-cause
- Organisation for Economic Co-operation and Development — Employment protection and minimum wages — https://www.oecd.org/en/topics/sub-issues/employment-protection-and-minimum-wages.html
- World Bank — Getting Labor Market Regulations Right — https://blogs.worldbank.org/en/jobs/getting-labor-market-regulations-right

#### Sitographie — Ni pour ni contre
- What dismissal is — https://www.acas.org.uk/dismissals
- Government of the United Kingdom — Dismissal: your rights — https://www.gov.uk/dismissal
- Fair Work Ombudsman — Ending employment — https://www.fairwork.gov.au/ending-employment
- Fair Work Ombudsman — Dismissal — https://www.fairwork.gov.au/ending-employment/dismissal
- At-will employment — https://www.law.cornell.edu/wex/at-will_employment
- International Labour Organization — Procedures for individual dismissal — https://eplex.ilo.org/en/node/73250
- International Labour Organization — Redress and judicial procedure in case of individual disputes — https://eplex.ilo.org/en/redress
- Eurofound — Individual employment relations — France — https://www.eurofound.europa.eu/en/countries/france/individual-employment-relations
- International Labour Organization — Termination of employment instruments — https://www.ilo.org/sites/default/files/wcmsp5/groups/public/%40ed_norm/%40normes/documents/meetingdocument/wcms_153602.pdf

#### Vidéographie — Pour
- Labor Notes — Robert M. Schwartz: An Introduction to Just Cause — https://www.youtube.com/watch?v=Nj5nqDkO9Jg
- Just Cause and Due Process — https://www.youtube.com/watch?v=6m-8DZsQLtA
- Branigan Robertson — At-Will Employment Explained by a Lawyer — https://www.youtube.com/watch?v=8C_eFrBNp2E

#### Vidéographie — Contre
- MacDonald & Associates — Just (Be)cause: Terminations for Just Cause Dismissal — https://www.youtube.com/watch?v=PPBC-4piA1Y
- Everything You Need to Know About Termination — https://www.youtube.com/watch?v=Kp8D9o6IWP0
- You're Fired! The Webinar — https://www.youtube.com/watch?v=hdRFjpI-NJM

#### Vidéographie — Ni pour ni contre
- Fair Work Commission — Unfair dismissal — https://www.youtube.com/playlist?list=PLmGoVTOii6BFTcoWl_u0slaT5yH8uPL_v
- VinciWorks — The Employment Rights Act explained: Understanding every major change — https://www.youtube.com/watch?v=V2JBSbDThf0
- Termination Notice and Termination Pay Mini-Overview — https://www.youtube.com/watch?v=qnnOA0fPBBs
