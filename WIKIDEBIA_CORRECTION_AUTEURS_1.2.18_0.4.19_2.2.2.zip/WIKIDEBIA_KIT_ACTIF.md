# Wikidéb’IA — Kit actif 2.2.2
**Versions :** norme 1.2.18 — validateur 0.4.19 — kit 2.2.2

# Source incorporée : `CHANGELOG.md`

**SHA-256 :** `3c687f1757b8f98daacb4865cda23b2e6cbffbf4f02809804076ce6dfe3ca13c`

```md
# Changelog

## 2.2.2 — 1er août 2026

- suppression de la question interactive de `./wikidebia publish` ;
- transmission automatique de l’empreinte du plan signé ;
- préflight bloquant pour les articles Wikipédia absents ou vides ;
- préflight bloquant pour `débats-connexes` / `related-debates` ;
- préflight bloquant pour les tableaux JSON dans `auteurs` / `authors` ;
- alignement sur la norme 1.2.18 et le validateur 0.4.19.

## 2.2.2 — 31 juillet 2026

- `./wikidebia update IDENTIFIANT` devient la commande de reprise d’un débat déjà publié ;
- l’ancienne mise à niveau des composants devient `./wikidebia upgrade` ;
- état publié et reçus signés par débat et langue ;
- opérations `create`, `skip`, `update`, `move`, `redirect`, `delete`, `manual_review` et `blocked` ;
- détection des modifications humaines avec triple comparaison et absence d’écrasement par défaut ;
- mises à jour avec `baserevid`, revérification de révision et plans signés ;
- retraits calculés depuis l’ancien état publié, protection contre les réutilisations inter-débats et vérification des marqueurs ;
- contrôle global des droits avant la première écriture, notamment `delete` ;
- ordre sûr avec vérification du nouveau graphe avant suppression, idempotence et reprise après interruption ;
- portées `--scope`, `--no-delete`, `--only-delete` et `--dry-run` ;
- quinze scénarios obligatoires plus un test d’inventaire distant signé.

## 2.1.17 — 31 juillet 2026

- restauration complète des exclusions Git sensibles ;
- retrait automatique de l’index des fichiers locaux déjà suivis, sans suppression du disque ;
- contrôle bloquant avant chaque `git add -A` ;
- diagnostic des règles `.gitignore`, des fichiers sensibles suivis et des chemins dangereux non ignorés ;
- push Git non interactif avec message d’authentification clair ;
- ajout de `./wikidebia github-sync` pour reprendre un push après authentification ;
- dépendances d’exécution bornées, dont Pywikibot 11.x.

## 2.1.17 — 31 juillet 2026

- création ou réparation automatique de `.venv/` par le lanceur ;
- installation automatique de Pywikibot et des dépendances d’exécution ;
- ajout de `requirements-runtime.txt` à la racine installée ;
- contrôle de l’environnement Python et des modules par `doctor` ;
- conservation de `.venv/` et de l’état d’installation hors de Git.

## 2.1.15 — 31 juillet 2026

- correction de la sélection automatique d’un ZIP unique dont le nom diffère du `debate_id` interne ;
- le nom du ZIP devient uniquement un sélecteur de fichier, tandis que `manifest.debate_id` reste l’identité autoritative du corpus ;
- prise en charge des anciennes archives portant des suffixes comme `_fr_en_release_ready_repaired_2026-07-31` ;
- affichage explicite du fichier sélectionné et de l’identifiant interne avant la planification ;
- maintien de la sélection exacte par nom de fichier lorsqu’il y a plusieurs ZIP.

## 2.1.13 — 30 juillet 2026

- remplacement de `incoming/debates/` par le dossier unique `incoming/` ;
- suppression de toute convention de nommage `release_ready` pour les ZIP de débats ;
- sélection automatique lorsque `incoming/` contient un seul ZIP ;
- sélection explicite par `./wikidebia publish IDENTIFIANT` lorsqu’il en contient plusieurs ;
- contrôle bloquant de la correspondance entre `<identifiant>.zip` et le `debate_id` du manifeste ;
- migration automatique des ZIP déjà présents dans l’ancien dossier `incoming/debates/`.

## 2.1.12 — 30 juillet 2026

- ajout de la commande portable `./wikidebia publish` qui extrait, valide, planifie, teste et publie un débat en une seule invocation ;
- portées `all`, `fr`, `en`, `fr-debate` et `en-debate` ;
- ordre Débat/Debate puis Argument imposé dans chaque langue ;
- ajout de `./wikidebia update` avec sauvegarde atomique dans `archives/`, vidage de `updates/`, tests et synchronisation Git ;
- déplacement automatique des secrets Pywikibot vers `private/pywikibot/` ;
- ajout de `./wikidebia github-init` et `./wikidebia doctor` ;
- chemins de configuration exclusivement relatifs et installation portable.


## 2.1.11 — 30 juillet 2026

- alignement sur la norme 1.2.11 et le validateur 0.4.11 ;
- aucune modification du protocole de publication 2.1.9 ;
- exemples et contrôles de version actualisés pour les notes d’introduction rédigées directement.

## 2.1.9 — 30 juillet 2026

- alignement sur la norme 1.2.9 et le validateur 0.4.9 ;
- publication française autorisée sans entrée anglaise dans le manifeste, lorsque le titre anglais est verrouillé dans le registre maître ;
- suppression de l’obligation d’inclure la page Débat française dans chaque plan de création ;
- ajout d’une configuration d’exemple française seule.

## 2.1.8 — 29 juillet 2026

- alignement sur la norme 1.2.8 et le validateur 0.4.8 ;
- contrôle préflight de l’ordre alphabétique des rubriques et sections ;
- contrôle de la majuscule initiale de `sujet` et `topic` ;
- refus des formes interrogatives dans `sujet-complet` et `complete-topic` ;
- maintien du test direct de la page Débat française canonique ;
- aucune exigence propre au kit sur le nombre d’appels `<ref>` ;
- 26 tests automatisés réussis.

## 2.1.4 — 2026-07-28

- alignement sur la norme 1.2.4 et le validateur 0.4.4 ;
- le contrôle éditorial du validateur inclut désormais la revue bilingue des introductions ;
- retrait des configurations propres aux corpus pilotes du kit générique ; elles restent dans les corpus concernés ;
- remplacement complet du test sur sous-page utilisateur par le mode `debate-test` ;
- création avec `createonly` de l’unique page Débat française canonique du plan ;
- reçu signé lié au plan, au fichier de débat, au titre canonique et à la révision distante ;
- revérification de la révision courante, du contenu, du résumé et de la balise avant toute autre écriture ;
- blocage si la page Débat existe déjà lors du plan ou si elle change après le test ;
- 21 tests automatisés réussis.

## 2.1.2 — 2026-07-28

- alignement sur la norme 1.2.2 et le validateur 0.4.2 ;
- portées `wikicode` et `editorial` obligatoires ;
- ancien mode de test sur sous-page utilisateur, remplacé par 2.1.4.
```

# Source incorporée : `GUIDE_PUBLICATION.md`

**SHA-256 :** `7aceef3d4602a0f615207ea505ad9bd95310644ae45f50729a032179336c0e28`

```md
# Guide de publication et de reprise Wikidéb’IA 2.2.2

## Nouveau débat

1. Déposer l’archive dans `incoming/`.
2. Exécuter `./wikidebia publish [SÉLECTEUR] --scope all`.
3. Conserver les reçus et états écrits sous `.state/`.

## Débat déjà publié

1. Installer le nouveau corpus sous `corpus/<debate_id>` ou déposer son ZIP dans `incoming/`.
2. Exécuter `./wikidebia update <debate_id> --dry-run`.
3. Examiner `manual_review` et `blocked`; aucune opération distante n’est faite en mode sec.
4. Vérifier l’empreinte du plan.
5. Exécuter `./wikidebia update <debate_id>` et confirmer exactement cette empreinte.
6. Contrôler le reçu final et les nouveaux états publiés signés.

Pour publier d’abord les créations et mises à jour : `--no-delete`. Pour retirer ensuite seulement les pages attestées et sûres : `--only-delete`.

## Conflits

Une révision ou une empreinte distante différente de l’état attendu produit `manual_review` lors de la planification ou un conflit bloquant lors de l’exécution. Il faut alors intégrer, adopter ou fusionner explicitement la modification humaine, puis produire un nouveau plan.

## Mise à niveau des composants

La commande est `./wikidebia upgrade`, et non plus `update`.


## Correctifs 2.2.2

La publication ordinaire ne pose plus la question `Publier le débat … ? [o/N]`. Après validation, le gestionnaire transmet automatiquement le SHA-256 du plan au moteur. Avant cela, il bloque toute page Débat/Debate sans article Wikipédia, tout paramètre de débats connexes et toute valeur auteurs sérialisée comme tableau JSON et tout séparateur d’auteurs différent de la virgule suivie d’une espace.
```

# Source incorporée : `KIT_MANIFEST.json`

**SHA-256 :** `827c27c15b9add7d2601ddf0093b3569fcaffd4f176dc2a713e8bf57dfd40815`

```json
{
  "kit": "wikidebia-generic-publisher",
  "version": "2.2.2",
  "validator_version": "0.4.19",
  "scope": [
    "publish_archive",
    "github_init",
    "doctor",
    "inspect",
    "plan",
    "debate_test",
    "full_page",
    "parameter_update",
    "remote_debate_update",
    "component_upgrade",
    "remote_delete",
    "remote_move",
    "remote_redirect",
    "manual_review"
  ],
  "debate_specific_code": false,
  "change_tag": "chatgpt",
  "safety": [
    "signed_plan",
    "required_full_validator_scopes",
    "createonly",
    "baserevid",
    "exact_revision_verification",
    "stop_on_collision",
    "direct_interlanguage_preflight",
    "english_debate_structure_preflight",
    "no_references_tag_preflight",
    "french_parenthetical_dash_preflight",
    "signed_canonical_debate_test_receipt",
    "remote_canonical_debate_reverification",
    "introduction_review_validator_gate",
    "no_corpus_specific_configs_in_generic_kit",
    "alphabetical_classification_preflight",
    "debate_topic_capitalization_preflight",
    "complete_topic_heading_fit_preflight",
    "french_only_manifest_registry_fallback",
    "argument_only_plan_without_debate_receipt",
    "adjacent_template_compaction_preflight",
    "safe_zip_extraction",
    "staged_update_tests",
    "atomic_component_backup",
    "private_pywikibot_credentials",
    "portable_relative_paths",
    "git_runtime_exclusions",
    "runtime_requirements_hash_marker_outside_git",
    "broken_virtual_environment_recreation",
    "complete_sensitive_gitignore",
    "pre_add_git_security_gate",
    "automatic_untrack_of_local_sensitive_files",
    "noninteractive_git_push",
    "github_sync_command",
    "bounded_runtime_dependencies",
    "signed_published_state",
    "signed_final_receipt",
    "human_edit_protection",
    "prewrite_effective_rights_gate",
    "delete_ownership_attestation",
    "delete_marker_recheck",
    "cross_debate_reuse_block",
    "remote_revision_recheck",
    "graph_verification_before_delete",
    "idempotent_restart",
    "sequential_language_sessions",
    "read_only_signed_remote_inventory_fallback",
    "mandatory_wikipedia_article_preflight",
    "no_related_debates_preflight",
    "json_author_array_preflight",
    "noninteractive_publish_with_signed_plan"
  ],
  "publication_profiles": [
    "norm_1_2_direct_interlanguage",
    "legacy"
  ],
  "features": [
    "publication_scopes_all_fr_en_fr_debate_en_debate",
    "debate_before_arguments_in_each_language",
    "canonical_french_debate_is_first_test_write_when_created",
    "french_pages_can_precede_english_page_generation",
    "locked_registry_title_fallback_for_missing_english_manifest_rows",
    "one_command_component_update",
    "previous_components_and_incoming_archived",
    "updates_directory_emptied_after_success",
    "github_commit_and_push_when_origin_exists",
    "private_pywikibot_directory",
    "no_persistent_absolute_project_path",
    "debate_specific_configs_external_to_kit",
    "repository_local_git_identity_fallback",
    "one_command_debate_zip_publication",
    "single_zip_auto_selection_from_incoming",
    "multiple_zip_selection_by_debate_identifier",
    "legacy_incoming_debates_migration",
    "archive_filename_is_selection_label_only",
    "manifest_debate_id_is_authoritative",
    "historical_manifest_versions_are_immutable_provenance",
    "compatible_prior_norms_publish_with_current_validator",
    "automatic_virtual_environment_creation",
    "automatic_runtime_dependency_installation",
    "pywikibot_bootstrap_after_clean_clone",
    "runtime_environment_doctor_checks",
    "git_security_doctor_checks",
    "github_authentication_recovery_command",
    "one_command_remote_debate_update",
    "create_skip_update_move_redirect_delete_manual_review_blocked_plan",
    "update_scope_fr_en",
    "update_no_delete",
    "update_only_delete",
    "update_dry_run",
    "component_upgrade_command",
    "published_state_revision_ledger",
    "explicit_merge_and_rename_migrations"
  ],
  "normative_revision": "1.2.18",
  "stable_archive_name": "wikidebia-kit.zip",
  "version_source": "VERSIONS.json"
}
```

# Source incorporée : `MIGRATION_2.1.11.md`

**SHA-256 :** `a095c953cff89ab7ed0b9442a3de6a08f9ce646f8fe448557a057c726070dedd`

```md
# Migration vers le kit 2.1.11

- Mettre `kit_version` à `2.1.11`.
- Exiger le validateur `0.4.11` et la norme `1.2.11`.
- Utiliser les configurations `creation_bilingue_1.2.11.example.json` ou `creation_francaise_1.2.11.example.json`.
- Corriger dans toutes les pages la séquence `}}` + saut de ligne + `{{` en `}}{{` avant de construire le plan.
- Le protocole de publication française indépendante reste identique à celui du kit 2.1.10.
```

# Source incorporée : `MIGRATION_2.1.12.md`

**SHA-256 :** `1747ff8835079765940c9e09adcb7faaf316937d8fb06904715c4c46799f11b4`

```md
# Migration vers le kit 2.1.12

1. Installer le lanceur racine `wikidebia` et le modèle `.gitignore` fournis dans `root_template/`.
2. Déplacer `user-config.py` et `user-password.cfg` vers `private/pywikibot/`.
3. Déposer les débats dans `incoming/debates/` et les mises à jour dans `updates/`.
4. Utiliser `./wikidebia publish --scope …` pour publier ; la page Débat/Debate est traitée avant les arguments dans chaque langue.
5. Utiliser `./wikidebia update` pour installer les composants, archiver les versions précédentes, vider `updates/` et synchroniser Git.
6. Initialiser une fois le dépôt distant avec `./wikidebia github-init URL_DU_DEPOT`.

Les chemins absolus ne doivent figurer dans aucun fichier suivi ou rapport persistant.
```

# Source incorporée : `MIGRATION_2.1.13.md`

**SHA-256 :** `2c672d1a1ae1bf966937a2a579f77e7121a649e60117310bd7992c9149d950b6`

```md
# Migration vers le kit 2.1.13

1. Remplacer le kit 2.1.12 par le kit 2.1.13.
2. Utiliser `incoming/` comme dossier unique des ZIP de débats ; le sous-dossier `incoming/debates/` n’est plus utilisé.
3. Renommer chaque archive en `<debate_id>.zip`. Aucun suffixe `release_ready` n’est demandé.
4. Lorsque `incoming/` contient un seul ZIP, lancer `./wikidebia publish`. Lorsqu’il en contient plusieurs, lancer `./wikidebia publish IDENTIFIANT`.
5. Ne pas inclure `.zip` dans l’identifiant. Le kit vérifie que le nom du fichier correspond exactement au `debate_id` interne.

Lors de `./wikidebia update`, les ZIP présents dans l’ancien dossier `incoming/debates/` sont déplacés automatiquement vers `incoming/`. Une collision de noms avec des contenus différents bloque la migration et conserve une copie dans l’archive de mise à jour.
```

# Source incorporée : `MIGRATION_2.1.14.md`

**SHA-256 :** `2c58d10a62fdad75477c6f232ff09f7e11834bee6f8d58f67f5ac61b9061facb`

```md
# Migration vers le kit 2.1.15

1. Remplacer le kit 2.1.13 par le kit 2.1.15.
2. Conserver les ZIP de débats directement dans `incoming/`.
3. Lorsqu’un seul ZIP est présent, `./wikidebia publish` le sélectionne quel que soit son nom.
4. Lorsqu’il y en a plusieurs, l’argument de commande sélectionne exactement le nom du ZIP sans `.zip`.
5. Le champ `manifest.debate_id` est l’identité autoritative du débat et détermine le dossier `corpus/<debate_id>` ainsi que la configuration de publication ; il n’a pas à être identique au nom du ZIP.

Cette correction rend compatibles les archives historiques portant des suffixes descriptifs ou une date, sans diminuer les contrôles sur le manifeste interne, l’extraction sûre et la validation du corpus.
```

# Source incorporée : `MIGRATION_2.1.15.md`

**SHA-256 :** `0d1915d699d09dd03f895a8df9411dae5fe36a6eb5570a5afe6b513e79090be7`

```md
# Migration vers le kit 2.1.15

1. Remplacer le kit 2.1.14 par le kit 2.1.15.
2. Ne pas modifier les champs historiques `normative_versions` du manifeste d’un corpus déjà produit.
3. Le kit exécute le validateur installé 0.4.15 et exige un rapport positif de cette version.
4. Le corpus peut déclarer une norme antérieure explicitement compatible, par exemple 1.2.10, et conserver le validateur qui a servi à sa production, par exemple 0.4.10.
5. La publication reste bloquée si le validateur installé refuse le corpus, si sa version réelle diverge, ou si le plan et les empreintes ne correspondent pas.
```

# Source incorporée : `MIGRATION_2.1.16.md`

**SHA-256 :** `8ce23f3d0416f8a7465b72717b60500f00521cf0b7055647a06df8c3643eb744`

```md
# Migration vers le kit 2.1.17

1. Remplacer le kit 2.1.15 par le kit 2.1.17 avec `./wikidebia update`.
2. Le lanceur crée automatiquement `.venv/` lorsqu’il est absent ou inutilisable.
3. Il installe automatiquement les dépendances déclarées dans `requirements-runtime.txt`, notamment Pywikibot.
4. L’empreinte des exigences installées est conservée uniquement dans `.state/`, dossier exclu de Git.
5. `./wikidebia doctor` contrôle désormais l’interpréteur virtuel et les modules nécessaires.
6. Aucun environnement virtuel, cache, mot de passe ou cookie n’est ajouté au dépôt Git.
```

# Source incorporée : `MIGRATION_2.1.17.md`

**SHA-256 :** `2b323d892a31d503b18999c75e0172355d64793e118f2237e68ee805ba7c12a2`

```md
# Migration vers le kit 2.1.17

1. Depuis le kit 2.1.16, déposer l’archive complète dans `updates/` et lancer exceptionnellement `./wikidebia update --no-git` afin que l’ancien gestionnaire ne crée aucun commit avant l’installation du garde-fou 2.1.17.
2. Le modèle `.gitignore` sécurisé est restauré avant tout commit.
3. Les fichiers locaux sensibles déjà suivis sont retirés de l’index avec conservation de leur copie locale.
4. Un push ne demande plus de nom d’utilisateur ou de mot de passe dans le terminal. En l’absence d’authentification, le commit reste local et un message indique d’utiliser GitHub CLI.
5. Après `gh auth login` et `gh auth setup-git`, lancer `./wikidebia github-sync`. Cette commande nettoie l’index, crée le commit de mise à jour resté en attente, puis pousse la branche.
6. La suppression d’un secret de l’historique public reste une opération séparée avec `git filter-repo`.
```

# Source incorporée : `MIGRATION_2.2.0.md`

**SHA-256 :** `276554410c7a8864c2153bac6757732a294779a23e409976113db065e98b87c3`

```md
# Migration vers le kit 2.2.0

1. Installer la norme 1.2.16, le validateur 0.4.17 et le kit 2.2.0.
2. Utiliser `./wikidebia upgrade` pour les futures mises à niveau de composants.
3. Réserver `./wikidebia update IDENTIFIANT` aux reprises de débats publiés.
4. Les publications effectuées par 2.2.0 créent automatiquement les états signés nécessaires aux reprises futures.
5. Pour un débat publié antérieurement, fournir un ancien manifeste installé/archivé ou un inventaire distant signé explicitement rattaché au débat.
6. Ne jamais reconstituer les retraits depuis le seul nouveau manifeste.
```

# Source incorporée : `MIGRATION_2.2.1.md`

**SHA-256 :** `44d0d09ae12477335ac2745f2601111794bb0d5f1802bb1b064ac2f9cfffb243`

```md
# Migration vers le kit 2.2.1

- installer la norme 1.2.17 et le validateur 0.4.18 ;
- corriger les pages sans article Wikipédia ;
- retirer les paramètres de débats connexes ;
- convertir les auteurs JSON en texte MediaWiki ;
- lancer `./wikidebia publish` sans `--yes` : la commande ne demande plus de confirmation.
```

# Source incorporée : `MIGRATION_2.2.2.md`

**SHA-256 :** `fa8fa0805afa8529e3b9fc5f66552e8e15163097ee84535adac2c052801ef72a`

```md
# Migration du kit 2.2.2

Le kit 2.2.2 conserve toutes les fonctions de 2.2.1 et ajoute un précontrôle du séparateur des auteurs pour les corpus 1.2.18. La forme canonique est `Auteur 1, Auteur 2`. Le plan signé, les contrôles de concurrence, la reprise idempotente et la publication sans invite interactive sont inchangés.
```

# Source incorporée : `PACKAGE_MANIFEST_SHA256.json`

**SHA-256 :** `a338475b2d89baed57e3341ed6cf180b69faac390cee99ff8464ee22cb79f27c`

```json
{
  "artifact": "wikidebia-kit",
  "version": "2.2.2",
  "normative_revision": "1.2.18",
  "stable_archive_name": "wikidebia-kit.zip",
  "version_source": "VERSIONS.json",
  "self_excluded": [
    "PACKAGE_MANIFEST_SHA256.json",
    "PACKAGE_RECEIPT.json"
  ],
  "declared_file_count": 35,
  "declared_test_count": 83,
  "files": [
    {
      "path": "CHANGELOG.md",
      "size_bytes": 6319,
      "sha256": "3c687f1757b8f98daacb4865cda23b2e6cbffbf4f02809804076ce6dfe3ca13c"
    },
    {
      "path": "GUIDE_PUBLICATION.md",
      "size_bytes": 1695,
      "sha256": "7aceef3d4602a0f615207ea505ad9bd95310644ae45f50729a032179336c0e28"
    },
    {
      "path": "KIT_MANIFEST.json",
      "size_bytes": 4151,
      "sha256": "827c27c15b9add7d2601ddf0093b3569fcaffd4f176dc2a713e8bf57dfd40815"
    },
    {
      "path": "MIGRATION_2.1.11.md",
      "size_bytes": 445,
      "sha256": "a095c953cff89ab7ed0b9442a3de6a08f9ce646f8fe448557a057c726070dedd"
    },
    {
      "path": "MIGRATION_2.1.12.md",
      "size_bytes": 751,
      "sha256": "1747ff8835079765940c9e09adcb7faaf316937d8fb06904715c4c46799f11b4"
    },
    {
      "path": "MIGRATION_2.1.13.md",
      "size_bytes": 854,
      "sha256": "2c672d1a1ae1bf966937a2a579f77e7121a649e60117310bd7992c9149d950b6"
    },
    {
      "path": "MIGRATION_2.1.14.md",
      "size_bytes": 769,
      "sha256": "2c58d10a62fdad75477c6f232ff09f7e11834bee6f8d58f67f5ac61b9061facb"
    },
    {
      "path": "MIGRATION_2.1.15.md",
      "size_bytes": 616,
      "sha256": "0d1915d699d09dd03f895a8df9411dae5fe36a6eb5570a5afe6b513e79090be7"
    },
    {
      "path": "MIGRATION_2.1.16.md",
      "size_bytes": 604,
      "sha256": "8ce23f3d0416f8a7465b72717b60500f00521cf0b7055647a06df8c3643eb744"
    },
    {
      "path": "MIGRATION_2.1.17.md",
      "size_bytes": 945,
      "sha256": "2b323d892a31d503b18999c75e0172355d64793e118f2237e68ee805ba7c12a2"
    },
    {
      "path": "MIGRATION_2.2.0.md",
      "size_bytes": 611,
      "sha256": "276554410c7a8864c2153bac6757732a294779a23e409976113db065e98b87c3"
    },
    {
      "path": "MIGRATION_2.2.1.md",
      "size_bytes": 321,
      "sha256": "44d0d09ae12477335ac2745f2601111794bb0d5f1802bb1b064ac2f9cfffb243"
    },
    {
      "path": "MIGRATION_2.2.2.md",
      "size_bytes": 330,
      "sha256": "fa8fa0805afa8529e3b9fc5f66552e8e15163097ee84535adac2c052801ef72a"
    },
    {
      "path": "README.md",
      "size_bytes": 543,
      "sha256": "0fbfc3e3efe0177c75b97dd972b32d02427222557ef3d7a99670438b092d34d1"
    },
    {
      "path": "TEST_REPORT.txt",
      "size_bytes": 488,
      "sha256": "7a5cb89e619ccd33b5bc0c5075ff1f198a497e72647cad54cffa5db535aa1148"
    },
    {
      "path": "VERSIONS.json",
      "size_bytes": 66,
      "sha256": "e82c5205e7a70cb9a8a4138d37ffff0e8c75c37bfcedc90b7364c56e6cf71643"
    },
    {
      "path": "config.example.json",
      "size_bytes": 1703,
      "sha256": "73eec0e98d5649aa93f9471ab0558ca278610dcdc864d3c21d75219444a7c8ac"
    },
    {
      "path": "config.schema.json",
      "size_bytes": 1494,
      "sha256": "f6ee3e01dc1cf9c02cd48665499a3f5897b1e67954cf1f5e7ca36eefb9d7c57a"
    },
    {
      "path": "configs/creation_bilingue_1.2.18.example.json",
      "size_bytes": 1703,
      "sha256": "73eec0e98d5649aa93f9471ab0558ca278610dcdc864d3c21d75219444a7c8ac"
    },
    {
      "path": "configs/creation_francaise_1.2.18.example.json",
      "size_bytes": 1612,
      "sha256": "e5e3264913970213102c727cd1ec89e32d8b278fe9cbad8959d45037d9872769"
    },
    {
      "path": "families/wikidebates_family.py",
      "size_bytes": 529,
      "sha256": "115b15c09a098b8947a60dce938f510ceafbe104113a1c2c21f3a6e8ce7df90e"
    },
    {
      "path": "pyproject.toml",
      "size_bytes": 141,
      "sha256": "1e982d4e734c9108974b9341a5fd0622b2655e02e47266d318b15ce2ba2e1930"
    },
    {
      "path": "root_template/.github/workflows/validate.yml",
      "size_bytes": 469,
      "sha256": "7575853ace066321cfd4cd09ea619187765bc61de1e5f073801316f57b5a8dc3"
    },
    {
      "path": "root_template/.gitignore",
      "size_bytes": 479,
      "sha256": "f65c4cc117e24af00a9c79bc8b9e187acb943bfd1da5a20e6f39f9111bbff515"
    },
    {
      "path": "root_template/README.md",
      "size_bytes": 440,
      "sha256": "a5ae4d65ac1e1991ed08666f24036cbcb2189c4d80614163872db21797e27787"
    },
    {
      "path": "root_template/config/wikidebia.example.json",
      "size_bytes": 312,
      "sha256": "85db4a8cd517534487129e9484b520a8d705e58dc03f15f3866b5aab96d8b8c3"
    },
    {
      "path": "root_template/requirements-runtime.txt",
      "size_bytes": 128,
      "sha256": "2a36eb307ac0dac6791353c12d546ee35918cef71f0ebfd8a6923baa18670e02"
    },
    {
      "path": "root_template/wikidebia",
      "size_bytes": 2131,
      "sha256": "27a8b3e2ace41d9319bfe803f850f3c16a7970e78fe28e0539c1202308b9f348"
    },
    {
      "path": "scripts/wikidebia_manage.py",
      "size_bytes": 51505,
      "sha256": "1bd2847d266b300d969edd68b2074d9e13a1f0e1d1f414dd7971c0b6e04d47ef"
    },
    {
      "path": "scripts/wikidebia_publish.py",
      "size_bytes": 75927,
      "sha256": "4d0a0b915a82144ecf8691b86860d598c59bead1d2036c57c256dcac196b7c8e"
    },
    {
      "path": "scripts/wikidebia_update.py",
      "size_bytes": 58750,
      "sha256": "73490a6b3ad8b9253142bcb8b821ec4736309eaa04ee4d2d3cad57178b741b6e"
    },
    {
      "path": "tests/test_versions_file.py",
      "size_bytes": 1052,
      "sha256": "8e57fffa870005788a63f7af4b2f830231d2e8eceed11eac5750e00b69e8b498"
    },
    {
      "path": "tests/test_wikidebia_manage.py",
      "size_bytes": 14733,
      "sha256": "0597f39adf34cc3927f126435984264ec19d8a87d924c43f2a024a69b1560375"
    },
    {
      "path": "tests/test_wikidebia_publish.py",
      "size_bytes": 36816,
      "sha256": "35cbd1cd3d2ac90ce98da455f85193976f67071ae222b470923bebf81badb180"
    },
    {
      "path": "tests/test_wikidebia_remote_update.py",
      "size_bytes": 14473,
      "sha256": "a564627832a4f5ac5280b009c241ad6d3775023ce05e5f581fd8aa66275df9d9"
    }
  ]
}
```

# Source incorporée : `PACKAGE_RECEIPT.json`

**SHA-256 :** `ebb7c0ea8cf9ddd0a37a90519a1bae5b57d1e765565ff2253635c9d37fc74760`

```json
{
  "receipt_version": "wikidebia-package-receipt-1.0",
  "artifact": "wikidebia-kit",
  "version": "2.2.2",
  "normative_revision": "1.2.18",
  "package_manifest_sha256": "a338475b2d89baed57e3341ed6cf180b69faac390cee99ff8464ee22cb79f27c",
  "declared_file_count": 35,
  "declared_test_count": 83,
  "generated_at": "2026-08-01T13:08:00+02:00",
  "receipt_sha256": "ba3b01ed0a58bdec62556a4fd9b7f4408988f32b94e582484333087ee3b11de1"
}
```

# Source incorporée : `README.md`

**SHA-256 :** `0fbfc3e3efe0177c75b97dd972b32d02427222557ef3d7a99670438b092d34d1`

```md
# Kit Wikidéb’IA 2.2.2

Le kit publie et reprend les corpus Wikidéb’IA avec plans signés. La version 2.2.2, alignée sur la norme 1.2.18 et le validateur 0.4.19, conserve les quatre barrières 2.2.1 et impose en plus la forme canonique `Auteur 1, Auteur 2` pour plusieurs auteurs.

``​`bash
./wikidebia publish
./wikidebia update IDENTIFIANT --dry-run
./wikidebia upgrade
``​`

`publish` calcule et transmet automatiquement l’empreinte du plan ; `update` conserve sa confirmation explicite car il peut déplacer ou supprimer des pages.
```

# Source incorporée : `TEST_REPORT.txt`

**SHA-256 :** `7a5cb89e619ccd33b5bc0c5075ff1f198a497e72647cad54cffa5db535aa1148`

```txt
Wikidéb’IA Kit 2.2.2
Norme : 1.2.18
Validateur requis : 0.4.19
Tests pytest : 83 réussis, 0 échec
Scénarios de reprise obligatoires : 15/15 réussis
Tests de séparateur : virgule correcte acceptée ; point-virgule, virgule mal espacée et virgule pleine chasse refusés
Exécution de la suite par fichiers et groupes indépendants pour éviter une limite de durée de l’environnement de test
Aucune connexion ni écriture MediaWiki réelle pendant les tests.
Résultat : RÉUSSI
```

# Source incorporée : `VERSIONS.json`

**SHA-256 :** `e82c5205e7a70cb9a8a4138d37ffff0e8c75c37bfcedc90b7364c56e6cf71643`

```json
{
  "norm": "1.2.18",
  "validator": "0.4.19",
  "kit": "2.2.2"
}
```

# Source incorporée : `config.example.json`

**SHA-256 :** `73eec0e98d5649aa93f9471ab0558ca278610dcdc864d3c21d75219444a7c8ac`

```json
{
  "kit_version": "2.2.2",
  "project_root": ".",
  "family": "wikidebates",
  "family_file": "kit/families/wikidebates_family.py",
  "pywikibot_dir": "private/pywikibot",
  "sites": {
    "fr": {
      "code": "fr",
      "expected_user": "ChatGPT"
    },
    "en": {
      "code": "en",
      "expected_user": "ChatGPT"
    }
  },
  "change_tags": [
    "chatgpt"
  ],
  "verification_attempts": 8,
  "verification_delay_seconds": 2,
  "write_delay_seconds": 0.5,
  "debate_id": "identifiant_du_debat",
  "corpus_root": "corpus/identifiant_du_debat",
  "logs_dir": "logs/identifiant_du_debat_operation",
  "validator": {
    "command": [
      ".venv/bin/python",
      "validator/scripts/wikidebia_validate.py",
      "validate"
    ],
    "required_version": "0.4.19",
    "scopes": [
      "schema",
      "coherence",
      "graph",
      "files",
      "batches",
      "sources",
      "wikicode",
      "bilingual",
      "editorial",
      "workflow"
    ],
    "max_warnings": 0,
    "fingerprint_path": "validator"
  },
  "manifest_requirements": {},
  "operation": {
    "id": "create_bilingual_direct_interlanguage",
    "kind": "full_page",
    "languages": [
      "fr",
      "en"
    ],
    "page_types": [],
    "language_order": [
      "fr",
      "en"
    ],
    "page_type_order": [
      "debate",
      "argument"
    ],
    "source_path_field": "file_path",
    "create_missing": true,
    "update_existing": false,
    "edit_summaries": {
      "fr": "Contenu généré par ChatGPT 5.6",
      "en": "Content generated by ChatGPT 5.6"
    },
    "remote_title_overrides": {
      "fr": {},
      "en": {}
    }
  },
  "publication_profile": "norm_1_2_direct_interlanguage"
}
```

# Source incorporée : `config.schema.json`

**SHA-256 :** `f6ee3e01dc1cf9c02cd48665499a3f5897b1e67954cf1f5e7ca36eefb9d7c57a`

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Configuration du kit générique Wikidéb'IA",
  "type": "object",
  "required": [
    "kit_version",
    "debate_id",
    "corpus_root",
    "validator",
    "family",
    "sites",
    "logs_dir",
    "operation",
    "publication_profile"
  ],
  "properties": {
    "kit_version": {
      "const": "2.2.2"
    },
    "debate_id": {
      "type": "string",
      "minLength": 1
    },
    "corpus_root": {
      "type": "string",
      "minLength": 1
    },
    "validator": {
      "type": "object",
      "required": [
        "command",
        "required_version",
        "fingerprint_path"
      ],
      "properties": {
        "required_version": {
          "const": "0.4.19"
        },
        "command": {
          "type": "array",
          "minItems": 1,
          "items": {
            "type": "string"
          }
        },
        "fingerprint_path": {
          "type": "string"
        }
      }
    },
    "change_tags": {
      "const": [
        "chatgpt"
      ]
    },
    "operation": {
      "type": "object",
      "required": [
        "id",
        "kind",
        "languages",
        "edit_summaries"
      ],
      "properties": {
        "kind": {
          "enum": [
            "full_page",
            "parameter_update"
          ]
        }
      }
    },
    "publication_profile": {
      "enum": [
        "norm_1_2_direct_interlanguage",
        "legacy"
      ]
    }
  }
}
```

# Source incorporée : `configs/creation_bilingue_1.2.18.example.json`

**SHA-256 :** `73eec0e98d5649aa93f9471ab0558ca278610dcdc864d3c21d75219444a7c8ac`

```json
{
  "kit_version": "2.2.2",
  "project_root": ".",
  "family": "wikidebates",
  "family_file": "kit/families/wikidebates_family.py",
  "pywikibot_dir": "private/pywikibot",
  "sites": {
    "fr": {
      "code": "fr",
      "expected_user": "ChatGPT"
    },
    "en": {
      "code": "en",
      "expected_user": "ChatGPT"
    }
  },
  "change_tags": [
    "chatgpt"
  ],
  "verification_attempts": 8,
  "verification_delay_seconds": 2,
  "write_delay_seconds": 0.5,
  "debate_id": "identifiant_du_debat",
  "corpus_root": "corpus/identifiant_du_debat",
  "logs_dir": "logs/identifiant_du_debat_operation",
  "validator": {
    "command": [
      ".venv/bin/python",
      "validator/scripts/wikidebia_validate.py",
      "validate"
    ],
    "required_version": "0.4.19",
    "scopes": [
      "schema",
      "coherence",
      "graph",
      "files",
      "batches",
      "sources",
      "wikicode",
      "bilingual",
      "editorial",
      "workflow"
    ],
    "max_warnings": 0,
    "fingerprint_path": "validator"
  },
  "manifest_requirements": {},
  "operation": {
    "id": "create_bilingual_direct_interlanguage",
    "kind": "full_page",
    "languages": [
      "fr",
      "en"
    ],
    "page_types": [],
    "language_order": [
      "fr",
      "en"
    ],
    "page_type_order": [
      "debate",
      "argument"
    ],
    "source_path_field": "file_path",
    "create_missing": true,
    "update_existing": false,
    "edit_summaries": {
      "fr": "Contenu généré par ChatGPT 5.6",
      "en": "Content generated by ChatGPT 5.6"
    },
    "remote_title_overrides": {
      "fr": {},
      "en": {}
    }
  },
  "publication_profile": "norm_1_2_direct_interlanguage"
}
```

# Source incorporée : `configs/creation_francaise_1.2.18.example.json`

**SHA-256 :** `e5e3264913970213102c727cd1ec89e32d8b278fe9cbad8959d45037d9872769`

```json
{
  "kit_version": "2.2.2",
  "project_root": ".",
  "family": "wikidebates",
  "family_file": "kit/families/wikidebates_family.py",
  "pywikibot_dir": "private/pywikibot",
  "sites": {
    "fr": {
      "code": "fr",
      "expected_user": "ChatGPT"
    },
    "en": {
      "code": "en",
      "expected_user": "ChatGPT"
    }
  },
  "change_tags": [
    "chatgpt"
  ],
  "verification_attempts": 8,
  "verification_delay_seconds": 2,
  "write_delay_seconds": 0.5,
  "debate_id": "identifiant_du_debat",
  "corpus_root": "corpus/identifiant_du_debat",
  "logs_dir": "logs/identifiant_du_debat_operation",
  "validator": {
    "command": [
      ".venv/bin/python",
      "validator/scripts/wikidebia_validate.py",
      "validate"
    ],
    "required_version": "0.4.19",
    "scopes": [
      "schema",
      "coherence",
      "graph",
      "files",
      "batches",
      "sources",
      "wikicode",
      "bilingual",
      "editorial",
      "workflow"
    ],
    "max_warnings": 0,
    "fingerprint_path": "validator"
  },
  "manifest_requirements": {},
  "operation": {
    "id": "create_french_direct_interlanguage",
    "kind": "full_page",
    "languages": [
      "fr"
    ],
    "page_types": [],
    "language_order": [
      "fr"
    ],
    "page_type_order": [
      "debate",
      "argument"
    ],
    "source_path_field": "file_path",
    "create_missing": true,
    "update_existing": false,
    "edit_summaries": {
      "fr": "Contenu généré par ChatGPT 5.6"
    },
    "remote_title_overrides": {
      "fr": {}
    }
  },
  "publication_profile": "norm_1_2_direct_interlanguage"
}
```

# Source incorporée : `families/wikidebates_family.py`

**SHA-256 :** `115b15c09a098b8947a60dce938f510ceafbe104113a1c2c21f3a6e8ce7df90e`

```py
"""Pywikibot family for the French and English Wikidebates sites."""

from pywikibot import family


class Family(family.Family):
    """Wikidebates family."""

    name = "wikidebates"
    langs = {
        "fr": "fr.wikidebates.org",
        "en": "en.wikidebates.org",
    }

    def protocol(self, code: str) -> str:
        """Use HTTPS for every Wikidebates site."""
        return "https"

    def scriptpath(self, code: str) -> str:
        """Return the MediaWiki script path used by Wikidebates."""
        return "/w"
```

# Source incorporée : `pyproject.toml`

**SHA-256 :** `1e982d4e734c9108974b9341a5fd0622b2655e02e47266d318b15ce2ba2e1930`

```toml
[project]
name = "wikidebia-generic-publisher"
version = "2.2.2"
requires-python = ">=3.10"

[tool.pytest.ini_options]
testpaths = ["tests"]
```

# Source incorporée : `root_template/README.md`

**SHA-256 :** `a5ae4d65ac1e1991ed08666f24036cbcb2189c4d80614163872db21797e27787`

```md
# Installation Wikidéb’IA

- `./wikidebia publish [SÉLECTEUR]` : publication initiale ;
- `./wikidebia update IDENTIFIANT [--dry-run|--no-delete|--only-delete]` : reprise distante contrôlée ;
- `./wikidebia upgrade` : mise à niveau des composants ;
- `./wikidebia doctor` : diagnostic local.

Les secrets Pywikibot résident dans `private/pywikibot/`. Les corpus, plans, reçus, états, journaux et archives ne sont pas versionnés.
```

# Source incorporée : `root_template/config/wikidebia.example.json`

**SHA-256 :** `85db4a8cd517534487129e9484b520a8d705e58dc03f15f3866b5aab96d8b8c3`

```json
{
  "expected_users": {
    "fr": "ChatGPT",
    "en": "ChatGPT"
  },
  "edit_summaries": {
    "fr": "Contenu généré par ChatGPT 5.6",
    "en": "Content generated by ChatGPT 5.6"
  },
  "family": "wikidebates",
  "verification_attempts": 8,
  "verification_delay_seconds": 2,
  "write_delay_seconds": 0.5
}
```

# Source incorporée : `root_template/requirements-runtime.txt`

**SHA-256 :** `2a36eb307ac0dac6791353c12d546ee35918cef71f0ebfd8a6923baa18670e02`

```txt
# Dépendances nécessaires aux commandes ./wikidebia
jsonschema>=4.18,<5
referencing>=0.30,<1
pytest>=8,<9
pywikibot>=11.5,<12
```

# Source incorporée : `scripts/wikidebia_manage.py`

**SHA-256 :** `1bd2847d266b300d969edd68b2074d9e13a1f0e1d1f414dd7971c0b6e04d47ef`

```py
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Iterable

NORM_VERSION = "1.2.18"
VALIDATOR_VERSION = "0.4.19"
KIT_VERSION = "2.2.2"
SCOPES = ("all", "fr", "en", "fr-debate", "en-debate")
COMPONENTS = {
    "wikidebia-normes": "norms",
    "wikidebia-validator": "validator",
    "wikidebia-kit": "kit",
}
TRACKED_ROOT_FILES = (
    "wikidebia",
    ".gitignore",
    "README.md",
    "WIKIDEBIA_NORMES_ACTIVES.md",
    "WIKIDEBIA_VALIDATEUR_ACTIF.md",
    "WIKIDEBIA_RECUS_ARCHIVES.json",
    "requirements-runtime.txt",
)

REQUIRED_GITIGNORE_RULES = (
    "/private/", "/corpus/", "/archives/", "/updates/", "/incoming/",
    "/logs/", "/plans/", "/.state/", "/.venv/",
    "/config/wikidebia.local.json", "/configs/", "/.gitconfig-wikidebia",
    "/user-config.py", "/user-password.cfg", "/apicache/",
    "*.lwp", "throttle.ctrl", "__pycache__/", ".pytest_cache/",
    "*.py[cod]", "*.egg-info/",
)
FORBIDDEN_GIT_PREFIXES = (
    "private/", "corpus/", "archives/", "updates/", "incoming/",
    "logs/", "plans/", ".state/", ".venv/", "configs/", "apicache/",
)
FORBIDDEN_GIT_EXACT = {
    "config/wikidebia.local.json", ".gitconfig-wikidebia",
    "user-config.py", "user-password.cfg", "throttle.ctrl",
}


class ManagementError(RuntimeError):
    pass


def timestamp() -> str:
    return dt.datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_tree(path: Path) -> str:
    digest = hashlib.sha256()
    for item in sorted(candidate for candidate in path.rglob("*") if candidate.is_file()):
        relative = item.relative_to(path).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(bytes.fromhex(sha256_file(item)))
    return digest.hexdigest()


def json_load(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ManagementError(f"JSON illisible : {path.name}") from exc
    if not isinstance(value, dict):
        raise ManagementError(f"Objet JSON attendu : {path.name}")
    return value


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def _safe_member(name: str) -> bool:
    pure = PurePosixPath(name)
    if pure.is_absolute() or ".." in pure.parts:
        return False
    if re.match(r"^[A-Za-z]:", name):
        return False
    return True


def safe_extract(archive: Path, destination: Path) -> None:
    try:
        with zipfile.ZipFile(archive) as bundle:
            seen: set[str] = set()
            for info in bundle.infolist():
                if not _safe_member(info.filename):
                    raise ManagementError(f"Chemin dangereux dans {archive.name} : {info.filename}")
                normalized = PurePosixPath(info.filename).as_posix()
                if normalized in seen:
                    raise ManagementError(f"Entrée ZIP dupliquée : {info.filename}")
                seen.add(normalized)
                mode = (info.external_attr >> 16) & 0o170000
                if mode == stat.S_IFLNK:
                    raise ManagementError(f"Lien symbolique interdit dans {archive.name}")
            bundle.extractall(destination)
    except zipfile.BadZipFile as exc:
        raise ManagementError(f"Archive ZIP invalide : {archive.name}") from exc


def inspect_component_zip(archive: Path) -> dict[str, Any]:
    try:
        with zipfile.ZipFile(archive) as bundle:
            names = {PurePosixPath(info.filename).as_posix() for info in bundle.infolist() if not info.is_dir()}
            if "PACKAGE_MANIFEST_SHA256.json" not in names:
                raise ManagementError(f"Manifeste interne absent : {archive.name}")
            manifest = json.loads(bundle.read("PACKAGE_MANIFEST_SHA256.json").decode("utf-8"))
            artifact = str(manifest.get("artifact") or "")
            if artifact not in COMPONENTS:
                raise ManagementError(f"Type de composant inconnu dans {archive.name} : {artifact}")
            declared = {str(row["path"]): row for row in manifest.get("files", [])}
            expected = set(declared) | {"PACKAGE_MANIFEST_SHA256.json"}
            if names != expected:
                missing = sorted(expected - names)
                extra = sorted(names - expected)
                raise ManagementError(
                    f"Inventaire divergent dans {archive.name}; absents={missing[:3]}, supplémentaires={extra[:3]}"
                )
            for relative, row in declared.items():
                payload = bundle.read(relative)
                if len(payload) != int(row.get("size_bytes", -1)):
                    raise ManagementError(f"Taille divergente : {archive.name}:{relative}")
                if hashlib.sha256(payload).hexdigest() != row.get("sha256"):
                    raise ManagementError(f"SHA-256 divergent : {archive.name}:{relative}")
            versions = json.loads(bundle.read("VERSIONS.json").decode("utf-8"))
            return {"artifact": artifact, "manifest": manifest, "versions": versions}
    except (zipfile.BadZipFile, KeyError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ManagementError(f"Composant illisible : {archive.name}") from exc


def _iter_input_zips(updates: Path, explicit: Path | None) -> list[Path]:
    if explicit is not None:
        return [explicit.resolve()]
    return sorted(path for path in updates.iterdir() if path.is_file() and path.suffix.casefold() == ".zip")


def collect_update_payload(root: Path, explicit: Path | None = None) -> tuple[dict[str, Path], list[Path], Path]:
    updates = root / "updates"
    updates.mkdir(parents=True, exist_ok=True)
    candidates = _iter_input_zips(updates, explicit)
    if not candidates:
        raise ManagementError("Aucune archive ZIP trouvée dans updates/")

    state_dir = root / ".state"
    state_dir.mkdir(parents=True, exist_ok=True)
    workspace = Path(tempfile.mkdtemp(prefix="wikidebia-update-", dir=state_dir))
    source_files = list(candidates)
    component_candidates = candidates
    if len(candidates) == 1:
        with zipfile.ZipFile(candidates[0]) as bundle:
            names = {PurePosixPath(info.filename).name for info in bundle.infolist() if not info.is_dir()}
        if {"wikidebia-normes.zip", "wikidebia-validator.zip", "wikidebia-kit.zip"}.issubset(names):
            safe_extract(candidates[0], workspace / "bundle")
            component_candidates = sorted((workspace / "bundle").rglob("*.zip"))

    components: dict[str, Path] = {}
    for candidate in component_candidates:
        try:
            metadata = inspect_component_zip(candidate)
        except ManagementError:
            continue
        artifact = metadata["artifact"]
        if artifact in components:
            raise ManagementError(f"Plusieurs archives candidates pour {artifact}")
        components[artifact] = candidate
    missing = sorted(set(COMPONENTS) - set(components))
    if missing:
        raise ManagementError("Composants de mise à jour absents : " + ", ".join(missing))
    return components, source_files, workspace


def _version_tuple(value: str) -> tuple[int, ...]:
    try:
        return tuple(int(part) for part in value.split("."))
    except ValueError as exc:
        raise ManagementError(f"Version invalide : {value}") from exc


def current_versions(root: Path) -> dict[str, str]:
    for component in ("norms", "validator", "kit"):
        path = root / component / "VERSIONS.json"
        if path.is_file():
            return {str(key): str(value) for key, value in json_load(path).items()}
    return {}


def verify_version_set(components: dict[str, Path], root: Path, allow_downgrade: bool) -> dict[str, str]:
    versions_by_artifact = {
        artifact: {str(key): str(value) for key, value in inspect_component_zip(path)["versions"].items()}
        for artifact, path in components.items()
    }
    unique = {json.dumps(value, sort_keys=True) for value in versions_by_artifact.values()}
    if len(unique) != 1:
        raise ManagementError("Les trois composants ne déclarent pas les mêmes versions")
    versions = next(iter(versions_by_artifact.values()))
    required = {"norm", "validator", "kit"}
    if set(versions) != required:
        raise ManagementError("VERSIONS.json doit contenir norm, validator et kit")
    previous = current_versions(root)
    if previous and not allow_downgrade:
        for key in required:
            if _version_tuple(versions[key]) < _version_tuple(previous.get(key, "0")):
                raise ManagementError(f"Rétrogradation refusée pour {key}: {previous[key]} -> {versions[key]}")
    return versions


def run(
    command: list[str],
    *,
    cwd: Path,
    capture: bool = False,
    check: bool = True,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    process_env = os.environ.copy()
    if env:
        process_env.update(env)
    result = subprocess.run(
        command,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
        check=False,
        env=process_env,
    )
    if check and result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        raise ManagementError(f"Commande échouée ({result.returncode}) : {' '.join(command)}\n{detail}")
    return result


def python_command(root: Path) -> str:
    candidate = root / ".venv" / "bin" / "python"
    return str(candidate) if candidate.is_file() else sys.executable


def runtime_requirements_sha(root: Path) -> str | None:
    path = root / "requirements-runtime.txt"
    return sha256_file(path) if path.is_file() else None


def runtime_environment_report(root: Path) -> dict[str, Any]:
    python = root / ".venv" / "bin" / "python"
    required = ("jsonschema", "referencing", "pytest", "pywikibot")
    report: dict[str, Any] = {
        "python": ".venv/bin/python",
        "python_available": False,
        "requirements_file": "requirements-runtime.txt",
        "requirements_sha256": runtime_requirements_sha(root),
        "modules": {},
        "missing_modules": list(required),
    }
    if not python.is_file():
        return report
    probe = r"""
import importlib.util
import json
import sys
from importlib.metadata import PackageNotFoundError, version
modules = ("jsonschema", "referencing", "pytest", "pywikibot")
packages = {}
missing = []
for name in modules:
    if importlib.util.find_spec(name) is None:
        missing.append(name)
        continue
    try:
        packages[name] = version(name)
    except PackageNotFoundError:
        packages[name] = "présent"
print(json.dumps({"python_version": sys.version.split()[0], "modules": packages, "missing_modules": missing}))
"""
    result = run([str(python), "-c", probe], cwd=root, capture=True, check=False)
    if result.returncode != 0:
        report["probe_error"] = (result.stderr or result.stdout or "échec inconnu").strip()
        return report
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError:
        report["probe_error"] = "sortie de diagnostic Python illisible"
        return report
    report.update(payload)
    report["python_available"] = True
    return report


def write_runtime_marker_if_ready(root: Path) -> None:
    report = runtime_environment_report(root)
    expected = report.get("requirements_sha256")
    if not report.get("python_available") or report.get("missing_modules") or not expected:
        return
    marker = root / ".state" / "runtime-requirements.sha256"
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(str(expected) + "\n", encoding="utf-8", newline="\n")


def extract_components(components: dict[str, Path], workspace: Path) -> dict[str, Path]:
    extracted: dict[str, Path] = {}
    for artifact, archive in components.items():
        destination = workspace / "staged" / COMPONENTS[artifact]
        destination.mkdir(parents=True, exist_ok=True)
        safe_extract(archive, destination)
        extracted[COMPONENTS[artifact]] = destination
    return extracted


def compare_normative_trees(norms: Path, validator: Path) -> None:
    source = norms / "normative_reference"
    embedded = validator / "normative_reference"
    if not source.is_dir() or not embedded.is_dir():
        raise ManagementError("Copie normative absente des composants")
    if sha256_tree(source) != sha256_tree(embedded):
        raise ManagementError("La copie normative du validateur diverge du paquet des normes")


def test_staged_components(root: Path, staged: dict[str, Path]) -> None:
    py = python_command(root)
    compare_normative_trees(staged["norms"], staged["validator"])
    run([py, "scripts/self_audit.py"], cwd=staged["validator"])
    run([py, "-m", "pytest", "-q"], cwd=staged["validator"], env={"PYTHONPATH": "src"})
    run([py, "-m", "pytest", "-q"], cwd=staged["kit"])


def aggregate_package(package: Path, title: str, versions: dict[str, str]) -> str:
    manifest = json_load(package / "PACKAGE_MANIFEST_SHA256.json")
    lines = [
        f"# {title}",
        "",
        f"**Norme active :** {versions['norm']}  ",
        f"**Validateur :** {versions['validator']}  ",
        f"**Kit :** {versions['kit']}",
        "",
    ]
    for row in manifest.get("files", []):
        relative = str(row["path"])
        path = package / relative
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        suffix = path.suffix.casefold()
        language = {".json": "json", ".py": "python", ".toml": "toml", ".sh": "bash"}.get(suffix, "")
        lines.extend(
            [
                f"# Source incorporée : `{relative}`",
                "",
                f"**SHA-256 :** `{row['sha256']}`",
                "",
                f"``​`{language}",
                text.rstrip("\n"),
                "``​`",
                "",
            ]
        )
    return "\n".join(lines).rstrip() + "\n"


def generate_readable_sources(root: Path, staged: dict[str, Path], versions: dict[str, str], component_archives: dict[str, Path]) -> dict[str, Path]:
    output = root / ".state" / "generated-update"
    output.mkdir(parents=True, exist_ok=True)
    norms_md = output / "WIKIDEBIA_NORMES_ACTIVES.md"
    validator_md = output / "WIKIDEBIA_VALIDATEUR_ACTIF.md"
    norms_md.write_text(aggregate_package(staged["norms"], f"Wikidéb’IA — Normes actives {versions['norm']}", versions), encoding="utf-8", newline="\n")
    validator_md.write_text(aggregate_package(staged["validator"], f"Wikidéb’IA — Validateur actif {versions['validator']}", versions), encoding="utf-8", newline="\n")
    artifacts = []
    stable = {
        "wikidebia-normes": "wikidebia-normes.zip",
        "wikidebia-validator": "wikidebia-validator.zip",
        "wikidebia-kit": "wikidebia-kit.zip",
    }
    for artifact in ("wikidebia-normes", "wikidebia-validator", "wikidebia-kit"):
        path = component_archives[artifact]
        artifacts.append({"path": stable[artifact], "size_bytes": path.stat().st_size, "sha256": sha256_file(path)})
    for path in (norms_md, validator_md):
        artifacts.append({"path": path.name, "size_bytes": path.stat().st_size, "sha256": sha256_file(path)})
    receipt = output / "WIKIDEBIA_RECUS_ARCHIVES.json"
    write_json(
        receipt,
        {
            "release": f"WIKIDEBIA_{versions['norm']}",
            "generated_date": dt.date.today().isoformat(),
            "versions": versions,
            "artifacts": artifacts,
        },
    )
    return {path.name: path for path in (norms_md, validator_md, receipt)}


def migrate_private_files(root: Path, backup: Path) -> None:
    private = root / "private" / "pywikibot"
    private.mkdir(parents=True, exist_ok=True)
    for name in ("user-config.py", "user-password.cfg"):
        source = root / name
        target = private / name
        if not source.exists():
            continue
        if target.exists():
            destination = backup / "legacy-secrets" / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(source), destination)
        else:
            shutil.move(str(source), target)
            target.chmod(0o600)


def migrate_legacy_debate_inbox(root: Path, backup: Path) -> None:
    legacy = root / "incoming" / "debates"
    if not legacy.exists():
        return
    if not legacy.is_dir():
        raise ManagementError("incoming/debates existe mais n’est pas un dossier")
    entries = sorted(legacy.iterdir())
    unsupported = [item.name for item in entries if not item.is_file() or item.suffix.casefold() != ".zip"]
    if unsupported:
        raise ManagementError(
            "Migration de incoming/debates bloquée par des entrées non ZIP : " + ", ".join(unsupported)
        )
    incoming = root / "incoming"
    incoming.mkdir(parents=True, exist_ok=True)
    for source in entries:
        target = incoming / source.name
        if target.exists() and sha256_file(target) != sha256_file(source):
            collision = backup / "legacy-incoming-collisions" / source.name
            collision.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, collision)
            raise ManagementError(
                f"Collision pendant la migration de {source.name}; copie conservée dans {collision.relative_to(root)}"
            )
    for source in entries:
        target = incoming / source.name
        if target.exists():
            source.unlink()
        else:
            shutil.move(str(source), target)
    legacy.rmdir()


def backup_root_template_files(root: Path, backup: Path) -> None:
    targets = [root / name for name in ("wikidebia", ".gitignore", "README.md", "requirements-runtime.txt")]
    targets.extend([root / "config" / "wikidebia.example.json", root / ".github"])
    for target in targets:
        if not target.exists() and not target.is_symlink():
            continue
        relative = target.relative_to(root)
        destination = backup / "previous-root" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if target.is_dir():
            shutil.copytree(target, destination, dirs_exist_ok=True)
        else:
            shutil.copy2(target, destination)


def install_root_template(root: Path, kit: Path) -> None:
    template = kit / "root_template"
    if not template.is_dir():
        raise ManagementError("Le nouveau kit ne contient pas root_template/")
    for source in sorted(template.rglob("*")):
        relative = source.relative_to(template)
        target = root / relative
        if source.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        if relative.as_posix() == "config/wikidebia.local.json":
            continue
        shutil.copy2(source, target)
    launcher = root / "wikidebia"
    if launcher.is_file():
        launcher.chmod(launcher.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP)


def _replace_path(source: Path, target: Path, backup_root: Path) -> None:
    if target.exists() or target.is_symlink():
        destination = backup_root / "previous" / target.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(target), destination)
    shutil.move(str(source), target)


def assert_portable_sources(root: Path) -> None:
    needle = str(root.resolve())
    candidates: list[Path] = []
    for dirname in ("norms", "validator", "kit"):
        base = root / dirname
        if base.is_dir():
            candidates.extend(path for path in base.rglob("*") if path.is_file())
    for name in TRACKED_ROOT_FILES:
        path = root / name
        if path.is_file():
            candidates.append(path)
    for base in (root / "config", root / ".github"):
        if base.is_dir():
            candidates.extend(path for path in base.rglob("*") if path.is_file())
    for path in candidates:
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        if needle in text:
            raise ManagementError(f"Chemin absolu du projet conservé dans {path.relative_to(root)}")


def _normalized_git_path(value: str) -> str:
    path = value.replace("\\", "/")
    while path.startswith("./"):
        path = path[2:]
    return PurePosixPath(path).as_posix()


def forbidden_git_path(value: str) -> bool:
    path = _normalized_git_path(value)
    return (
        path in FORBIDDEN_GIT_EXACT
        or path.casefold().endswith(".lwp")
        or any(path == prefix.rstrip("/") or path.startswith(prefix) for prefix in FORBIDDEN_GIT_PREFIXES)
    )


def gitignore_missing_rules(root: Path) -> list[str]:
    path = root / ".gitignore"
    if not path.is_file():
        return list(REQUIRED_GITIGNORE_RULES)
    active = {line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip() and not line.lstrip().startswith("#")}
    return [rule for rule in REQUIRED_GITIGNORE_RULES if rule not in active]


def git_is_repo(root: Path) -> bool:
    return (root / ".git").is_dir()


def git_tracked_forbidden_paths(root: Path) -> list[str]:
    if not git_is_repo(root):
        return []
    result = run(["git", "ls-files", "-z"], cwd=root, capture=True, check=False)
    if result.returncode != 0:
        return []
    return sorted(path for path in result.stdout.split("\0") if path and forbidden_git_path(path))


def git_unignored_forbidden_paths(root: Path) -> list[str]:
    if not git_is_repo(root):
        return []
    result = run(
        ["git", "ls-files", "--others", "--exclude-standard", "-z"],
        cwd=root,
        capture=True,
        check=False,
    )
    if result.returncode != 0:
        return []
    return sorted(path for path in result.stdout.split("\0") if path and forbidden_git_path(path))


def git_security_issues(root: Path) -> list[str]:
    issues: list[str] = []
    missing = gitignore_missing_rules(root)
    if missing:
        issues.append("Règles .gitignore manquantes : " + ", ".join(missing))
    tracked = git_tracked_forbidden_paths(root)
    if tracked:
        issues.append("Fichiers locaux ou sensibles encore suivis par Git : " + ", ".join(tracked))
    unignored = git_unignored_forbidden_paths(root)
    if unignored:
        issues.append("Fichiers locaux ou sensibles non ignorés : " + ", ".join(unignored))
    return issues


def prepare_git_security(root: Path) -> None:
    missing = gitignore_missing_rules(root)
    if missing:
        raise ManagementError("Règles de sécurité absentes du .gitignore : " + ", ".join(missing))
    tracked = git_tracked_forbidden_paths(root)
    if tracked:
        for offset in range(0, len(tracked), 100):
            run(
                ["git", "rm", "-r", "--cached", "--ignore-unmatch", "--", *tracked[offset:offset + 100]],
                cwd=root,
            )
        print("Fichiers locaux retirés de l’index Git sans suppression locale : " + ", ".join(tracked), file=sys.stderr)
    remaining = git_security_issues(root)
    if remaining:
        raise ManagementError("Contrôle de sécurité Git échoué : " + " | ".join(remaining))


def git_has_origin(root: Path) -> bool:
    if not git_is_repo(root):
        return False
    result = run(["git", "remote", "get-url", "origin"], cwd=root, capture=True, check=False)
    return result.returncode == 0 and bool(result.stdout.strip())


def ensure_git_identity(root: Path) -> None:
    defaults = {
        "user.name": "Wikidéb’IA",
        "user.email": "wikidebia@localhost",
    }
    for key, default in defaults.items():
        result = run(["git", "config", "--get", key], cwd=root, capture=True, check=False)
        if result.returncode != 0 or not result.stdout.strip():
            run(["git", "config", "--local", key, default], cwd=root)


def git_push_current_branch(root: Path, *, strict: bool) -> bool:
    if not git_has_origin(root):
        message = (
            "Aucun remote origin n’est configuré. Utilisez ./wikidebia github-init URL_DU_DEPOT."
        )
        if strict:
            raise ManagementError(message)
        print("Dépôt Git mis à jour localement. " + message, file=sys.stderr)
        return False
    branch = run(["git", "branch", "--show-current"], cwd=root, capture=True).stdout.strip() or "main"
    result = run(
        ["git", "push", "-u", "origin", branch],
        cwd=root,
        capture=True,
        check=False,
        env={"GIT_TERMINAL_PROMPT": "0"},
    )
    if result.returncode == 0:
        return True
    detail = (result.stderr or result.stdout or "échec d’authentification inconnu").strip()
    message = (
        "Push GitHub non effectué. Le commit reste local. Authentifiez GitHub CLI avec "
        "`gh auth login -h github.com -p https`, puis exécutez `gh auth setup-git --hostname github.com` "
        "et `./wikidebia github-sync`. Détail Git : " + detail
    )
    if strict:
        raise ManagementError(message)
    print("AVERTISSEMENT : " + message, file=sys.stderr)
    return False


def git_commit_and_push(root: Path, message: str, *, push: bool) -> bool:
    if not git_is_repo(root):
        run(["git", "init", "-b", "main"], cwd=root)
    ensure_git_identity(root)
    prepare_git_security(root)
    run(["git", "add", "-A"], cwd=root)
    tracked_after_add = git_tracked_forbidden_paths(root)
    if tracked_after_add:
        raise ManagementError("git add a tenté de suivre des fichiers interdits : " + ", ".join(tracked_after_add))
    status = run(["git", "status", "--porcelain"], cwd=root, capture=True).stdout.strip()
    if status:
        run(["git", "commit", "-m", message], cwd=root)
    return git_push_current_branch(root, strict=False) if push else False


def update_sources(root: Path, archive: Path | None, *, allow_downgrade: bool, no_push: bool, no_git: bool) -> dict[str, str]:
    components, input_files, workspace = collect_update_payload(root, archive)
    try:
        versions = verify_version_set(components, root, allow_downgrade)
        staged = extract_components(components, workspace)
        test_staged_components(root, staged)
        generated = generate_readable_sources(root, staged, versions, components)

        backup = root / "archives" / "updates" / f"{timestamp()}-{versions['norm']}"
        backup.mkdir(parents=True, exist_ok=True)
        migrate_private_files(root, backup)
        migrate_legacy_debate_inbox(root, backup)
        backup_root_template_files(root, backup)

        installed: list[str] = []
        try:
            for name in ("norms", "validator", "kit"):
                _replace_path(staged[name], root / name, backup)
                installed.append(name)
        except Exception:
            for name in reversed(installed):
                current = root / name
                if current.exists():
                    shutil.rmtree(current)
                previous = backup / "previous" / name
                if previous.exists():
                    shutil.move(str(previous), current)
            raise
        install_root_template(root, root / "kit")
        write_runtime_marker_if_ready(root)
        for name, source in generated.items():
            target = root / name
            if target.exists():
                destination = backup / "previous" / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(target), destination)
            shutil.copy2(source, target)

        incoming_archive = backup / "incoming"
        incoming_archive.mkdir(parents=True, exist_ok=True)
        updates_dir = root / "updates"
        for item in list(updates_dir.iterdir()):
            shutil.move(str(item), incoming_archive / item.name)
        for item in input_files:
            if item.parent != updates_dir and item.exists():
                shutil.copy2(item, incoming_archive / item.name)

        assert_portable_sources(root)
        if not no_git:
            git_commit_and_push(
                root,
                f"Mise à jour Wikidéb’IA {versions['norm']} / {versions['validator']} / {versions['kit']}",
                push=not no_push,
            )
        return versions
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def load_local_settings(root: Path) -> dict[str, Any]:
    path = root / "config" / "wikidebia.local.json"
    if not path.is_file():
        return {}
    return json_load(path)


def ensure_credentials(root: Path) -> Path:
    private = root / "private" / "pywikibot"
    private.mkdir(parents=True, exist_ok=True)
    for name in ("user-config.py", "user-password.cfg"):
        legacy = root / name
        target = private / name
        if legacy.is_file() and not target.exists():
            shutil.move(str(legacy), target)
            target.chmod(0o600)
    if not (private / "user-config.py").is_file():
        raise ManagementError("private/pywikibot/user-config.py est absent")
    return private


def find_debate_archive(root: Path, debate_identifier: str | None) -> Path:
    incoming = root / "incoming"
    incoming.mkdir(parents=True, exist_ok=True)
    candidates = sorted(path for path in incoming.iterdir() if path.is_file() and path.suffix.casefold() == ".zip")

    if debate_identifier is not None:
        identifier = debate_identifier.strip()
        if identifier.casefold().endswith(".zip"):
            raise ManagementError("Indiquez l’identifiant du débat sans l’extension .zip")
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", identifier):
            raise ManagementError("Identifiant de débat invalide; caractères admis : lettres, chiffres, _, - et .")
        archive = incoming / f"{identifier}.zip"
        if not archive.is_file():
            available = ", ".join(path.stem for path in candidates) or "aucun"
            raise ManagementError(f"Archive introuvable : incoming/{identifier}.zip; identifiants disponibles : {available}")
        return archive

    if len(candidates) == 1:
        return candidates[0]
    if not candidates:
        raise ManagementError("Aucune archive ZIP trouvée dans incoming/")
    available = ", ".join(path.stem for path in candidates)
    raise ManagementError(
        "Plusieurs archives ZIP sont présentes dans incoming/. "
        f"Relancez avec ./wikidebia publish IDENTIFIANT. Identifiants disponibles : {available}"
    )


def locate_package_root(extracted: Path) -> Path:
    manifests = sorted(extracted.rglob("manifest.json"))
    if len(manifests) != 1:
        raise ManagementError(f"Le ZIP de débat doit contenir exactement un manifest.json; trouvé : {len(manifests)}")
    return manifests[0].parent


def install_debate_corpus(root: Path, archive: Path) -> tuple[str, Path]:
    stage = root / ".state" / "debates" / f"{timestamp()}-{sha256_file(archive)[:12]}"
    stage.mkdir(parents=True, exist_ok=True)
    safe_extract(archive, stage)
    package_root = locate_package_root(stage)
    manifest = json_load(package_root / "manifest.json")
    debate_id = str(manifest.get("debate_id") or "").strip()
    if not debate_id or not re.fullmatch(r"[A-Za-z0-9_.-]+", debate_id):
        raise ManagementError("debate_id absent ou impropre à un nom de dossier")
    # Le nom du ZIP sert uniquement à sélectionner l’archive. Le manifeste reste
    # l’autorité pour l’identité du débat, notamment pour les anciennes archives
    # dont le nom contient des suffixes descriptifs ou une date.
    target = root / "corpus" / debate_id
    if target.is_dir() and sha256_tree(target) == sha256_tree(package_root):
        shutil.rmtree(stage, ignore_errors=True)
        return debate_id, target
    if target.exists():
        backup = root / "archives" / "debates" / f"{timestamp()}-{debate_id}" / "previous-corpus"
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(target), backup)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(package_root, target)
    shutil.rmtree(stage, ignore_errors=True)
    return debate_id, target


def scope_values(scope: str) -> tuple[list[str], list[str]]:
    mapping = {
        "all": (["fr", "en"], []),
        "fr": (["fr"], []),
        "en": (["en"], []),
        "fr-debate": (["fr"], ["debate"]),
        "en-debate": (["en"], ["debate"]),
    }
    return mapping[scope]


def publication_config(root: Path, debate_id: str, scope: str, run_dir: Path) -> Path:
    settings = load_local_settings(root)
    languages, page_types = scope_values(scope)
    users = settings.get("expected_users") or {"fr": "ChatGPT", "en": "ChatGPT"}
    summaries = settings.get("edit_summaries") or {
        "fr": "Contenu généré par ChatGPT 5.6",
        "en": "Content generated by ChatGPT 5.6",
    }
    sites = {language: {"code": language, "expected_user": str(users.get(language) or "ChatGPT")} for language in languages}
    config = {
        "kit_version": KIT_VERSION,
        "project_root": ".",
        "family": str(settings.get("family") or "wikidebates"),
        "family_file": "kit/families/wikidebates_family.py",
        "pywikibot_dir": "private/pywikibot",
        "sites": sites,
        "change_tags": ["chatgpt"],
        "verification_attempts": int(settings.get("verification_attempts", 8)),
        "verification_delay_seconds": float(settings.get("verification_delay_seconds", 2)),
        "write_delay_seconds": float(settings.get("write_delay_seconds", 0.5)),
        "debate_id": debate_id,
        "corpus_root": f"corpus/{debate_id}",
        "logs_dir": f"logs/{debate_id}/{run_dir.name}",
        "validator": {
            "command": [".venv/bin/python", "validator/scripts/wikidebia_validate.py", "validate"],
            "required_version": VALIDATOR_VERSION,
            "scopes": ["schema", "coherence", "graph", "files", "batches", "sources", "wikicode", "bilingual", "editorial", "workflow"],
            "max_warnings": 0,
            "fingerprint_path": "validator",
        },
        # Les versions déclarées par le corpus sont une provenance historique.
        # La sécurité repose sur le validateur installé, sa version réelle et son
        # rapport positif, non sur une réécriture du manifeste au fil des mises à jour.
        "manifest_requirements": {},
        "operation": {
            "id": f"publish_{scope.replace('-', '_')}",
            "kind": "full_page",
            "languages": languages,
            "page_types": page_types,
            "language_order": languages,
            "page_type_order": ["debate", "argument"],
            "source_path_field": "file_path",
            "create_missing": True,
            "update_existing": False,
            "edit_summaries": {language: str(summaries[language]) for language in languages},
            "remote_title_overrides": {language: {} for language in languages},
        },
        "publication_profile": "norm_1_2_direct_interlanguage",
    }
    path = run_dir / "config.json"
    write_json(path, config)
    return path


def publisher_command(root: Path, config: Path, *args: str) -> list[str]:
    return [python_command(root), "kit/scripts/wikidebia_publish.py", "--config", str(config.relative_to(root)), *args]


def publish_debate(root: Path, debate_identifier: str | None, scope: str, assume_yes: bool, keep_zip: bool) -> dict[str, int]:
    ensure_credentials(root)
    archive = find_debate_archive(root, debate_identifier)
    debate_id, _ = install_debate_corpus(root, archive)
    try:
        archive_display = archive.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        archive_display = archive.name
    print(f"Archive sélectionnée : {archive_display}")
    print(f"Identifiant interne du débat : {debate_id}")
    run_dir = root / "plans" / debate_id / timestamp()
    run_dir.mkdir(parents=True, exist_ok=True)
    config = publication_config(root, debate_id, scope, run_dir)
    plan_path = run_dir / "plan.json"
    run(publisher_command(root, config, "--mode", "plan", "--plan-output", str(plan_path.relative_to(root))), cwd=root)
    plan = json_load(plan_path)
    if plan.get("blockers"):
        raise ManagementError(f"Le plan contient {len(plan['blockers'])} bloqueur(s); voir {plan_path.relative_to(root)}")
    counts = plan.get("counts") or {}
    print(json.dumps(counts, ensure_ascii=False, indent=2))
    # Le plan signé est transmis automatiquement au moteur ; aucune invite interactive n’est utilisée.

    receipt_path = run_dir / "debate-test-receipt.json"
    french_create = any(
        row.get("language") == "fr" and row.get("page_type") == "debate" and row.get("operation") == "create"
        for row in plan.get("actions", [])
    )
    if french_create:
        run(
            publisher_command(
                root,
                config,
                "--mode", "debate-test",
                "--execute",
                "--plan-input", str(plan_path.relative_to(root)),
                "--confirm-plan-sha256", str(plan["plan_sha256"]),
                "--debate-test-receipt-output", str(receipt_path.relative_to(root)),
            ),
            cwd=root,
        )

    publish_args = [
        "--mode", "publish",
        "--execute",
        "--plan-input", str(plan_path.relative_to(root)),
        "--confirm-plan-sha256", str(plan["plan_sha256"]),
    ]
    if french_create:
        publish_args.extend(["--debate-test-receipt", str(receipt_path.relative_to(root))])
    result = run(publisher_command(root, config, *publish_args), cwd=root, capture=True)
    output = (result.stdout or "").strip().splitlines()
    published = json.loads(output[-1]) if output else {}
    if french_create:
        published["created"] = int(published.get("created", 0)) + 1
        published["skipped"] = max(0, int(published.get("skipped", 0)) - 1)
    if not keep_zip:
        destination = root / "archives" / "debates" / f"{timestamp()}-{debate_id}" / archive.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        if archive.resolve().is_relative_to(root.resolve()):
            shutil.move(str(archive), destination)
        else:
            shutil.copy2(archive, destination)
    return {str(key): int(value) for key, value in published.items()}



def remote_update_config(root: Path, debate_id: str, scope: str, run_dir: Path) -> Path:
    settings = load_local_settings(root)
    languages = ["fr", "en"] if scope == "all" else [scope]
    users = settings.get("expected_users") or {"fr": "ChatGPT", "en": "ChatGPT"}
    sites = {language: {"code": language, "expected_user": str(users.get(language) or "ChatGPT")} for language in languages}
    config = {
        "kit_version": KIT_VERSION,
        "project_root": ".",
        "family": str(settings.get("family") or "wikidebates"),
        "family_file": "kit/families/wikidebates_family.py",
        "pywikibot_dir": "private/pywikibot",
        "sites": sites,
        "languages": languages,
        "debate_id": debate_id,
        "corpus_root": f"corpus/{debate_id}",
        "logs_dir": f"logs/{debate_id}/{run_dir.name}",
        "published_state_dir": ".state/published",
        "receipts_dir": ".state/receipts",
        "validator": {
            "command": [".venv/bin/python", "validator/scripts/wikidebia_validate.py", "validate"],
            "required_version": VALIDATOR_VERSION,
            "scopes": ["schema", "coherence", "graph", "files", "batches", "sources", "wikicode", "bilingual", "editorial", "workflow"],
        },
        "edit_summaries": {
            "fr": "Mise à jour du corpus Wikidéb’IA {debate_id}, version {corpus_version}",
            "en": "Update of Wikidéb’IA corpus {debate_id}, version {corpus_version}",
        },
    }
    path = run_dir / "config.json"
    write_json(path, config)
    return path


def remote_update_command(root: Path, config: Path, *args: str) -> list[str]:
    return [python_command(root), "kit/scripts/wikidebia_update.py", "--config", str(config.relative_to(root)), *args]


def _prepare_update_corpus(root: Path, debate_identifier: str | None) -> tuple[str, Path | None]:
    incoming = root / "incoming"
    archive: Path | None = None
    if debate_identifier:
        exact = incoming / f"{debate_identifier}.zip"
        if exact.is_file():
            archive = exact
        elif (root / "corpus" / debate_identifier / "manifest.json").is_file():
            return debate_identifier, None
        else:
            try:
                archive = find_debate_archive(root, debate_identifier)
            except ManagementError:
                raise ManagementError(f"Corpus installé ou archive introuvable pour {debate_identifier}")
    else:
        zips = sorted(incoming.glob("*.zip")) if incoming.is_dir() else []
        if len(zips) == 1:
            archive = zips[0]
        else:
            raise ManagementError("Indiquez l’identifiant du débat à reprendre")
    debate_id, _ = install_debate_corpus(root, archive)
    return debate_id, archive


def update_debate(root: Path, debate_identifier: str | None, scope: str, assume_yes: bool, no_delete: bool, only_delete: bool, dry_run: bool, keep_zip: bool) -> dict[str, Any]:
    ensure_credentials(root)
    if no_delete and only_delete:
        raise ManagementError("--no-delete et --only-delete sont incompatibles")
    debate_id, archive = _prepare_update_corpus(root, debate_identifier)
    run_dir = root / "plans" / debate_id / timestamp()
    run_dir.mkdir(parents=True, exist_ok=True)
    config = remote_update_config(root, debate_id, scope, run_dir)
    plan_path = run_dir / "update-plan.json"
    flags: list[str] = []
    if no_delete:
        flags.append("--no-delete")
    if only_delete:
        flags.append("--only-delete")
    result = run(remote_update_command(root, config, "--mode", "plan", "--plan-output", str(plan_path.relative_to(root)), *flags), cwd=root, capture=True, check=False)
    if result.returncode not in {0, 3}:
        raise ManagementError((result.stderr or result.stdout or "Plan de reprise impossible").strip())
    plan = json_load(plan_path)
    print(json.dumps(plan.get("counts") or {}, ensure_ascii=False, indent=2))
    if dry_run:
        return {"status": "dry_run", "plan": str(plan_path.relative_to(root)), "plan_sha256": plan["plan_sha256"], "counts": plan.get("counts") or {}}
    if (plan.get("operations") or {}).get("blocked"):
        raise ManagementError(f"Le plan contient {len(plan['operations']['blocked'])} opération(s) bloquée(s); voir {plan_path.relative_to(root)}")
    if not assume_yes:
        answer = input(f"Confirmer le plan {plan['plan_sha256']} pour la reprise de {debate_id} ? [o/N] ").strip().casefold()
        if answer not in {"o", "oui", "y", "yes"}:
            raise ManagementError("Mise à jour annulée")
    execute = run(remote_update_command(root, config, "--mode", "execute", "--plan-input", str(plan_path.relative_to(root)), "--confirm-plan-sha256", str(plan["plan_sha256"]), *flags), cwd=root, capture=True)
    lines = (execute.stdout or "").strip().splitlines()
    counts = json.loads(lines[-1]) if lines else {}
    if archive is not None and not keep_zip:
        destination = root / "archives" / "debates" / f"{timestamp()}-{debate_id}" / archive.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(archive), destination)
    return {"status": "executed", "plan": str(plan_path.relative_to(root)), "plan_sha256": plan["plan_sha256"], "counts": counts}

def github_init(root: Path, remote: str, private: bool) -> None:
    if not git_is_repo(root):
        run(["git", "init", "-b", "main"], cwd=root)
    if git_has_origin(root):
        current = run(["git", "remote", "get-url", "origin"], cwd=root, capture=True).stdout.strip()
        if current != remote:
            raise ManagementError(f"origin existe déjà et pointe vers {current}")
    else:
        run(["git", "remote", "add", "origin", remote], cwd=root)
    # Le caractère privé/public est défini lors de la création du dépôt distant.
    _ = private
    assert_portable_sources(root)
    git_commit_and_push(root, "Initialisation du dépôt Wikidéb’IA", push=False)
    git_push_current_branch(root, strict=True)


def github_sync(root: Path) -> None:
    if not git_is_repo(root):
        raise ManagementError("Le dossier n’est pas un dépôt Git")
    assert_portable_sources(root)
    # Cette commande sert aussi à terminer une mise à jour installée avec --no-git :
    # elle nettoie l’index, ajoute les sources sûres et crée le commit avant le push.
    git_commit_and_push(root, "Synchronisation sécurisée Wikidéb’IA", push=False)
    git_push_current_branch(root, strict=True)


def doctor(root: Path) -> dict[str, Any]:
    issues: list[str] = []
    versions = current_versions(root)
    if not versions:
        issues.append("VERSIONS.json introuvable")
    if (root / "user-config.py").exists() or (root / "user-password.cfg").exists():
        issues.append("Secrets Pywikibot encore présents à la racine")
    if not (root / "private" / "pywikibot" / "user-config.py").is_file():
        issues.append("private/pywikibot/user-config.py absent")
    runtime = runtime_environment_report(root)
    if not runtime.get("requirements_sha256"):
        issues.append("requirements-runtime.txt absent")
    if not runtime.get("python_available"):
        issues.append(".venv/bin/python absent ou inutilisable")
    missing = runtime.get("missing_modules") or []
    if missing:
        issues.append("Modules Python manquants dans .venv : " + ", ".join(str(item) for item in missing))
    if runtime.get("probe_error"):
        issues.append("Diagnostic de .venv impossible : " + str(runtime["probe_error"]))
    try:
        assert_portable_sources(root)
    except ManagementError as exc:
        issues.append(str(exc))
    issues.extend(git_security_issues(root))
    updates = root / "updates"
    update_count = len(list(updates.iterdir())) if updates.is_dir() else 0
    return {
        "versions": versions,
        "runtime_environment": runtime,
        "git_repository": git_is_repo(root),
        "git_origin": git_has_origin(root),
        "updates_entries": update_count,
        "issues": issues,
        "status": "passed" if not issues else "failed",
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="wikidebia", description="Gestion portable de Wikidéb’IA")
    parser.add_argument("--root", type=Path, default=Path.cwd(), help=argparse.SUPPRESS)
    sub = parser.add_subparsers(dest="command", required=True)

    publish = sub.add_parser("publish", help="Valider, planifier et publier un ZIP de débat")
    publish.add_argument("debate_identifier", nargs="?", help="Nom du ZIP sans .zip; facultatif si incoming/ contient un seul ZIP. Le debate_id interne peut être différent.")
    publish.add_argument("--scope", choices=SCOPES, default="all")
    publish.add_argument("--yes", action="store_true", help=argparse.SUPPRESS)
    publish.add_argument("--keep-zip", action="store_true", help="Ne pas archiver le ZIP après succès")

    update = sub.add_parser("update", help="Reprendre un débat déjà publié avec créations, mises à jour et retraits contrôlés")
    update.add_argument("debate_identifier", nargs="?", help="Identifiant du débat installé ou nom du ZIP sans .zip")
    update.add_argument("--scope", choices=("all", "fr", "en"), default="all")
    update.add_argument("--yes", action="store_true", help="Confirmer automatiquement l’empreinte du plan")
    update.add_argument("--no-delete", action="store_true", help="Exécuter la reprise sans suppressions finales")
    update.add_argument("--only-delete", action="store_true", help="N’exécuter que les retraits sûrs et redirections de fusion")
    update.add_argument("--dry-run", action="store_true", help="Produire seulement le plan signé")
    update.add_argument("--keep-zip", action="store_true", help="Ne pas archiver le ZIP après succès")

    upgrade = sub.add_parser("upgrade", help="Installer les composants déposés dans updates/")
    upgrade.add_argument("archive", nargs="?", type=Path, help="Archive complète facultative")
    upgrade.add_argument("--allow-downgrade", action="store_true")
    upgrade.add_argument("--no-push", action="store_true", help="Créer le commit sans pousser vers origin")
    upgrade.add_argument("--no-git", action="store_true", help="Ne pas créer de commit Git")

    github = sub.add_parser("github-init", help="Initialiser le dépôt et pousser vers GitHub")
    github.add_argument("remote", help="URL Git du dépôt, par exemple git@github.com:COMPTE/wikidebia.git")
    github.add_argument("--private", action="store_true", help="Documentation uniquement; la visibilité se règle sur GitHub")
    sub.add_parser("github-sync", help="Pousser les commits locaux vers origin après authentification")

    sub.add_parser("doctor", help="Contrôler l'installation portable")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    root = args.root.expanduser().resolve()
    if args.command == "publish":
        result = publish_debate(root, args.debate_identifier, args.scope, args.yes, args.keep_zip)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 0
    if args.command == "update":
        result = update_debate(root, args.debate_identifier, args.scope, args.yes, args.no_delete, args.only_delete, args.dry_run, args.keep_zip)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 0
    if args.command == "upgrade":
        versions = update_sources(
            root,
            args.archive,
            allow_downgrade=args.allow_downgrade,
            no_push=args.no_push,
            no_git=args.no_git,
        )
        print(json.dumps(versions, ensure_ascii=False, sort_keys=True))
        return 0
    if args.command == "github-init":
        github_init(root, args.remote, args.private)
        print("Dépôt GitHub initialisé et synchronisé.")
        return 0
    if args.command == "github-sync":
        github_sync(root)
        print("Dépôt GitHub synchronisé.")
        return 0
    report = doctor(root)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "passed" else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except ManagementError as exc:
        print(f"WIKIDEBIA BLOQUÉ : {exc}", file=sys.stderr)
        raise SystemExit(2)
```

# Source incorporée : `scripts/wikidebia_publish.py`

**SHA-256 :** `4d0a0b915a82144ecf8691b86860d598c59bead1d2036c57c256dcac196b7c8e`

```py
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import unicodedata
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Protocol

KIT_VERSION = "2.2.2"
REQUIRED_VALIDATOR_VERSION = "0.4.19"
DIRECT_INTERLANGUAGE_PROFILE = "norm_1_2_direct_interlanguage"
REQUIRED_DIRECT_SCOPES = {"schema", "coherence", "graph", "files", "batches", "sources", "wikicode", "bilingual", "editorial", "workflow"}
PAIRED_EM_DASH_RE = re.compile(r"\s—\s[^—\n]{1,500}?\s—(?=\s|[.,;:!?])")
SPLIT_ADJACENT_TEMPLATES_RE = re.compile(r"}}[ \t\r\n]+\{\{")
LEGACY_PROFILE = "legacy"
DEFAULT_FAMILY_DIR = Path(__file__).resolve().parent.parent / "families"


class PublicationError(RuntimeError):
    pass


class IdentityError(PublicationError):
    pass


class RevisionConflict(PublicationError):
    pass


class CollisionError(PublicationError):
    pass


def normalize_wikicode(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n").rstrip("\n")

def _alphabetical_key(value: str) -> str:
    folded = unicodedata.normalize("NFKD", value.casefold())
    return "".join(c for c in folded if not unicodedata.combining(c))


def alphabetical_values(value: str) -> list[str]:
    items = [item.strip() for item in value.split(",") if item.strip()]
    return sorted(items, key=_alphabetical_key)


def _first_alpha_is_upper(value: str) -> bool:
    first = next((c for c in value.strip() if c.isalpha()), "")
    return bool(first and first.isupper())


def _complete_topic_is_interrogative(value: str, language: str) -> bool:
    clean = value.strip()
    if not clean or "?" in clean:
        return True
    if language == "fr":
        return bool(re.match(r"^(?:si\b|faut[- ]?il\b|est[- ]?ce\s+que\b|doit[- ]?on\b|peut[- ]?on\b)", clean, flags=re.I))
    return bool(re.match(r"^(?:whether\b|if\b|should\b|can\b|could\b|is\b|are\b|do\b|does\b|must\b)", clean, flags=re.I))


def sha_text(text: str) -> str:
    return hashlib.sha256(normalize_wikicode(text).encode("utf-8")).hexdigest()


def sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def portable(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.name


def sha_object(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def sha_tree(path: Path) -> str:
    path = path.resolve()
    if path.is_file():
        return sha_file(path)
    if not path.is_dir():
        raise PublicationError(f"Chemin à empreinter introuvable : {path}")
    digest = hashlib.sha256()
    for item in sorted(candidate for candidate in path.rglob("*") if candidate.is_file()):
        relative = item.relative_to(path).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        digest.update(bytes.fromhex(sha_file(item)))
    return digest.hexdigest()


def dotted_get(value: Any, dotted_path: str) -> Any:
    current = value
    for part in dotted_path.split("."):
        if not isinstance(current, dict) or part not in current:
            raise PublicationError(f"Champ introuvable : {dotted_path}")
        current = current[part]
    return current


def recursive_find_version(value: Any) -> str | None:
    if isinstance(value, dict):
        for key in ("validator_version", "version"):
            candidate = value.get(key)
            if isinstance(candidate, str) and candidate:
                return candidate
        for child in value.values():
            found = recursive_find_version(child)
            if found:
                return found
    elif isinstance(value, list):
        for child in value:
            found = recursive_find_version(child)
            if found:
                return found
    return None


@dataclass(frozen=True)
class ParameterSpan:
    name: str
    value_start: int
    value_end: int


def _main_template_parameter_spans(text: str) -> list[ParameterSpan]:
    start = text.find("{{")
    if start < 0:
        raise PublicationError("Aucun modèle principal trouvé")
    template_depth = 0
    link_depth = 0
    in_comment = False
    pipes: list[int] = []
    main_close: int | None = None
    index = start
    while index < len(text):
        if in_comment:
            end = text.find("-->", index)
            if end < 0:
                raise PublicationError("Commentaire HTML non fermé")
            index = end + 3
            in_comment = False
            continue
        if text.startswith("<!--", index):
            in_comment = True
            index += 4
            continue
        if text.startswith("[[", index):
            link_depth += 1
            index += 2
            continue
        if text.startswith("]]", index) and link_depth:
            link_depth -= 1
            index += 2
            continue
        if text.startswith("{{", index):
            template_depth += 1
            index += 2
            continue
        if text.startswith("}}", index):
            if template_depth == 1:
                main_close = index
                break
            if template_depth > 1:
                template_depth -= 1
                index += 2
                continue
            raise PublicationError("Fermeture de modèle inattendue")
        if text[index] == "|" and template_depth == 1 and link_depth == 0:
            pipes.append(index)
        index += 1
    if main_close is None:
        raise PublicationError("Modèle principal non fermé")
    boundaries = pipes + [main_close]
    spans: list[ParameterSpan] = []
    for position, pipe in enumerate(pipes):
        segment_end = boundaries[position + 1]
        segment = text[pipe + 1 : segment_end]
        equal = segment.find("=")
        if equal < 0:
            continue
        name = segment[:equal].strip()
        if not name:
            continue
        spans.append(
            ParameterSpan(
                name=name,
                value_start=pipe + 1 + equal + 1,
                value_end=segment_end,
            )
        )
    return spans



def _main_template_close_index(text: str) -> int:
    """Retourne la position du }} fermant le modèle principal."""
    start = text.find("{{")
    if start < 0:
        raise PublicationError("Aucun modèle principal trouvé")

    template_depth = 0
    link_depth = 0
    in_comment = False
    index = start

    while index < len(text):
        if in_comment:
            end = text.find("-->", index)
            if end < 0:
                raise PublicationError("Commentaire HTML non fermé")
            index = end + 3
            in_comment = False
            continue

        if text.startswith("<!--", index):
            in_comment = True
            index += 4
            continue

        if text.startswith("[[", index):
            link_depth += 1
            index += 2
            continue

        if text.startswith("]]", index) and link_depth:
            link_depth -= 1
            index += 2
            continue

        if text.startswith("{{", index):
            template_depth += 1
            index += 2
            continue

        if text.startswith("}}", index):
            if template_depth == 1:
                return index

            if template_depth > 1:
                template_depth -= 1
                index += 2
                continue

            raise PublicationError(
                "Fermeture de modèle inattendue"
            )

        index += 1

    raise PublicationError("Modèle principal non fermé")


def extract_parameter(text: str, parameter: str) -> str:
    matches = [
        span
        for span in _main_template_parameter_spans(text)
        if span.name == parameter
    ]

    if len(matches) != 1:
        raise PublicationError(
            f"Le paramètre |{parameter}= doit apparaître exactement "
            f"une fois ; trouvé : {len(matches)}"
        )

    span = matches[0]

    return text[
        span.value_start:span.value_end
    ].rstrip(" \t\r\n")


def replace_parameter(
    text: str,
    parameter: str,
    value: str,
    *,
    insert_if_missing: bool = False,
) -> str:
    matches = [
        span
        for span in _main_template_parameter_spans(text)
        if span.name == parameter
    ]

    if len(matches) == 0 and insert_if_missing:
        close = _main_template_close_index(text)
        clean = value.rstrip(" \t\r\n")

        if close > 0 and text[close - 1] in "\r\n":
            insertion = f"|{parameter}={clean}\n"
        else:
            insertion = f"\n|{parameter}={clean}\n"

        return text[:close] + insertion + text[close:]

    if len(matches) != 1:
        raise PublicationError(
            f"Le paramètre |{parameter}= doit apparaître exactement "
            f"une fois ; trouvé : {len(matches)}"
        )

    span = matches[0]
    old_value = text[span.value_start:span.value_end]
    suffix = old_value[
        len(old_value.rstrip(" \t\r\n")):
    ]
    clean = value.rstrip(" \t\r\n")

    return (
        text[:span.value_start]
        + clean
        + suffix
        + text[span.value_end:]
    )

@dataclass
class PageAction:
    operation_id: str
    kind: str
    language: str
    page_id: str
    page_type: str
    title: str
    source_path: str
    parameter: str | None
    local_file_sha256: str
    local_target_sha256: str
    remote_revision_id: int | None
    remote_sha256: str | None
    remote_target_sha256: str | None
    desired_sha256: str | None
    classification: str
    operation: str
    note: str | None = None


class Adapter(Protocol):
    def open_language(self, language: str, expected_user: str) -> None: ...
    def close_language(self) -> None: ...
    def assert_identity(self, expected_user: str) -> None: ...
    def available_change_tags(self) -> set[str]: ...
    def read_page(self, title: str) -> tuple[bool, int | None, str]: ...
    def read_revision(self, title: str, revision_id: int) -> dict[str, Any] | None: ...
    def write_page(
        self,
        *,
        title: str,
        text: str,
        summary: str,
        tags: list[str],
        expected_user: str,
        create_only: bool,
        base_revision_id: int | None,
    ) -> int: ...


class PywikibotAdapter:
    def __init__(
        self,
        family: str,
        codes: dict[str, str],
        pywikibot_dir: str | Path,
        family_file: str | Path | None = None,
    ) -> None:
        self.family = family
        self.codes = codes
        self.pywikibot_dir = Path(pywikibot_dir).expanduser().resolve()
        self.family_file = (
            Path(family_file).expanduser().resolve()
            if family_file
            else (DEFAULT_FAMILY_DIR / f"{family}_family.py").resolve()
        )
        self.site: Any | None = None

    def _prepare_environment(self) -> None:
        if not self.pywikibot_dir.is_dir():
            raise PublicationError(f"Dossier Pywikibot introuvable : {self.pywikibot_dir}")
        if not (self.pywikibot_dir / "user-config.py").is_file():
            raise PublicationError(f"user-config.py absent dans : {self.pywikibot_dir}")
        os.environ["PYWIKIBOT_DIR"] = str(self.pywikibot_dir)

    def _register_family(self, pywikibot: Any) -> None:
        family_files = getattr(getattr(pywikibot, "config", None), "family_files", None)
        if family_files is None:
            raise PublicationError("Configuration des familles Pywikibot indisponible")
        if self.family not in family_files:
            if not self.family_file.is_file():
                raise PublicationError(f"Fichier de famille introuvable : {self.family_file}")
            family_files[self.family] = str(self.family_file)

    def open_language(self, language: str, expected_user: str) -> None:
        self._prepare_environment()
        import pywikibot
        self._register_family(pywikibot)
        self.site = pywikibot.Site(code=self.codes[language], fam=self.family)
        if self.site.user() is not None:
            self.site.logout()
        self.site.login()
        self.assert_identity(expected_user)

    def close_language(self) -> None:
        try:
            if self.site is not None and self.site.user() is not None:
                self.site.logout()
        finally:
            self.site = None

    def assert_identity(self, expected_user: str) -> None:
        actual = None if self.site is None else self.site.user()
        if actual != expected_user:
            raise IdentityError(f"Compte actif inattendu : {actual!r}")

    def available_change_tags(self) -> set[str]:
        if self.site is None:
            raise PublicationError("Site non ouvert")
        tags: set[str] = set()
        continuation: dict[str, Any] = {}
        while True:
            data = self.site.simple_request(
                action="query",
                list="tags",
                tglimit="max",
                tgprop="active|defined",
                **continuation,
            ).submit()
            for row in ((data.get("query") or {}).get("tags") or []):
                if row.get("name") and ("active" in row or row.get("active") is True):
                    tags.add(str(row["name"]))
            if not data.get("continue"):
                break
            continuation = data["continue"]
        return tags

    def read_page(self, title: str) -> tuple[bool, int | None, str]:
        if self.site is None:
            raise PublicationError("Site non ouvert")
        import pywikibot
        page = pywikibot.Page(self.site, title)
        if not page.exists():
            return False, None, ""
        return True, int(page.latest_revision_id), page.text

    def read_revision(self, title: str, revision_id: int) -> dict[str, Any] | None:
        if self.site is None:
            raise PublicationError("Site non ouvert")
        data = self.site.simple_request(
            action="query",
            prop="revisions",
            revids=int(revision_id),
            rvprop="ids|content|comment|tags",
            rvslots="main",
        ).submit()
        for page in ((data.get("query") or {}).get("pages") or {}).values():
            revisions = page.get("revisions") or []
            if not revisions:
                continue
            revision = revisions[0]
            slot = (revision.get("slots") or {}).get("main") or {}
            return {
                "revision_id": int(revision.get("revid", revision_id)),
                "text": slot.get("content", slot.get("*", revision.get("*", ""))),
                "summary": revision.get("comment", "") or "",
                "tags": list(revision.get("tags") or []),
            }
        return None

    def write_page(
        self,
        *,
        title: str,
        text: str,
        summary: str,
        tags: list[str],
        expected_user: str,
        create_only: bool,
        base_revision_id: int | None,
    ) -> int:
        if self.site is None:
            raise PublicationError("Site non ouvert")
        self.assert_identity(expected_user)
        parameters: dict[str, Any] = {
            "action": "edit",
            "title": title,
            "text": text,
            "summary": summary,
            "bot": 1,
            "assert": "user",
            "assertuser": expected_user,
            "md5": hashlib.md5(text.encode("utf-8")).hexdigest(),
        }
        if tags:
            parameters["tags"] = "|".join(tags)
        if create_only:
            parameters["createonly"] = 1
        else:
            if base_revision_id is None:
                raise RevisionConflict("baserevid absent pour une modification")
            parameters["baserevid"] = int(base_revision_id)
            parameters["nocreate"] = 1
        parameters["token"] = self.site.tokens["csrf"]
        data = self.site.simple_request(**parameters).submit()
        return int(data["edit"]["newrevid"])


class GenericPublisher:
    def __init__(self, config: dict[str, Any], adapter: Adapter, config_path: Path) -> None:
        self.config = config
        self.adapter = adapter
        self.config_path = config_path.resolve()
        self.project_root = Path(config.get("project_root") or Path.cwd()).expanduser().resolve()
        self.root = self._resolve(config["corpus_root"])
        self.manifest_path = self.root / str(config.get("manifest_file", "manifest.json"))
        if not self.manifest_path.is_file():
            raise PublicationError(f"Manifest introuvable : {self.manifest_path}")
        self.manifest = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        self.operation = dict(config["operation"])
        self.publication_profile = str(config.get("publication_profile") or LEGACY_PROFILE)
        self.languages = tuple(self.operation.get("languages") or config.get("languages") or ())
        self.tags = list(config.get("change_tags") or ["chatgpt"])
        logs_dir = self._resolve(config["logs_dir"])
        operation_id = str(self.operation.get("id") or self.operation.get("kind") or "publication")
        self.log_path = logs_dir / f"{operation_id}.jsonl"
        self._tag_cache: dict[str, set[str]] = {}
        self._registry_cache: dict[str, Any] | None | bool = False
        self._validate_configuration()

    def _resolve(self, value: str | Path) -> Path:
        path = Path(value).expanduser()
        return path.resolve() if path.is_absolute() else (self.project_root / path).resolve()

    def _validate_configuration(self) -> None:
        if str(self.config.get("kit_version") or "") not in {KIT_VERSION, "2"}:
            raise PublicationError(f"kit_version doit être {KIT_VERSION}")
        if self.manifest.get("debate_id") != self.config.get("debate_id"):
            raise PublicationError("debate_id divergent entre la configuration et le manifeste")
        validator = self.config.get("validator") or {}
        if validator.get("required_version") != REQUIRED_VALIDATOR_VERSION:
            raise PublicationError(
                f"Le validateur requis doit être exactement {REQUIRED_VALIDATOR_VERSION}"
            )
        if self.publication_profile == DIRECT_INTERLANGUAGE_PROFILE:
            scopes = {str(value) for value in (validator.get("scopes") or [])}
            missing_scopes = sorted(REQUIRED_DIRECT_SCOPES - scopes)
            if missing_scopes:
                raise PublicationError(
                    "Portées obligatoires du validateur absentes : " + ", ".join(missing_scopes)
                )
        if self.tags != ["chatgpt"]:
            raise PublicationError("La balise obligatoire doit être exactement : chatgpt")
        if not self.languages:
            raise PublicationError("Aucune langue sélectionnée")
        sites = self.config.get("sites") or {}
        summaries = self.operation.get("edit_summaries") or {}
        for language in self.languages:
            site = sites.get(language) or {}
            if not str(site.get("code") or "").strip():
                raise PublicationError(f"Code de site absent pour {language}")
            if not str(site.get("expected_user") or "").strip():
                raise PublicationError(f"expected_user absent pour {language}")
            if not str(summaries.get(language) or "").strip():
                raise PublicationError(f"Résumé de modification absent pour {language}")
        if self.publication_profile not in {DIRECT_INTERLANGUAGE_PROFILE, LEGACY_PROFILE}:
            raise PublicationError(
                "publication_profile doit être norm_1_2_direct_interlanguage ou legacy"
            )
        kind = self.operation.get("kind")
        if kind not in {"full_page", "parameter_update"}:
            raise PublicationError("operation.kind doit être full_page ou parameter_update")
        if kind == "full_page":
            configured_order = list(self.operation.get("page_type_order") or [])
            if "debate" in configured_order and "argument" in configured_order:
                if configured_order.index("debate") > configured_order.index("argument"):
                    raise PublicationError(
                        "page_type_order doit placer debate avant argument dans chaque langue"
                    )
        if kind == "parameter_update":
            parameters = self.operation.get("parameters") or {}
            for language in self.languages:
                if not str(parameters.get(language) or "").strip():
                    raise PublicationError(f"Paramètre cible absent pour {language}")
            if self.operation.get("create_missing") is True:
                raise PublicationError("parameter_update ne peut pas créer une page absente")
            if (
                self.publication_profile == DIRECT_INTERLANGUAGE_PROFILE
                and any(str(parameters.get(language) or "") == "interlangue" for language in self.languages)
            ):
                raise PublicationError(
                    "Le profil 1.2.18 intègre interlangue dans la création complète; "
                    "une opération parameter_update interlangue est interdite."
                )
        requirements = self.config.get("manifest_requirements") or {}
        for field, expected in requirements.items():
            actual = dotted_get(self.manifest, field)
            if actual != expected:
                raise PublicationError(
                    f"Exigence de manifeste divergente pour {field} : {actual!r} au lieu de {expected!r}"
                )

    def _prepare_logging(self) -> None:
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        probe = self.log_path.parent / ".wikidebia_write_probe"
        try:
            probe.write_text("ok\n", encoding="utf-8")
            probe.unlink()
        except OSError as exc:
            raise PublicationError(f"Répertoire de journaux inaccessible : {exc}") from exc

    def _log(self, event: dict[str, Any]) -> None:
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        with self.log_path.open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")

    def _site(self, language: str) -> tuple[str, str]:
        site = self.config["sites"][language]
        return str(site["code"]), str(site["expected_user"])

    def _summary(self, language: str) -> str:
        return str(self.operation["edit_summaries"][language])

    def _parameter(self, language: str) -> str | None:
        if self.operation["kind"] != "parameter_update":
            return None
        return str(self.operation["parameters"][language])

    def _change_tag_gate(self, language: str) -> None:
        if language not in self._tag_cache:
            self._tag_cache[language] = self.adapter.available_change_tags()
        missing = [tag for tag in self.tags if tag not in self._tag_cache[language]]
        if missing:
            raise PublicationError(
                f"Balise(s) inactive(s) sur {language} : {', '.join(missing)}"
            )

    def _selected_pages(self) -> list[dict[str, Any]]:
        page_types = set(self.operation.get("page_types") or [])
        excluded = set(self.operation.get("exclude_page_types") or [])
        selected = []
        for row in self.manifest.get("pages", []):
            if row.get("language") not in self.languages:
                continue
            if page_types and row.get("page_type") not in page_types:
                continue
            if row.get("page_type") in excluded:
                continue
            selected.append(row)
        if not selected:
            raise PublicationError("Aucune page du manifeste ne correspond à l'opération")
        identities = [(row.get("language"), row.get("page_id")) for row in selected]
        if len(identities) != len(set(identities)):
            raise PublicationError("Identifiants de pages dupliqués dans la sélection")
        language_order = {
            value: index
            for index, value in enumerate(self.operation.get("language_order") or self.languages)
        }
        configured_type_order = list(self.operation.get("page_type_order") or [])
        if self.operation.get("kind") == "full_page":
            # Invariant de publication : la page Débat/Debate précède toujours
            # toutes les pages Argument de la même langue.
            type_order = {"debate": 0, "argument": 1}
        else:
            type_order = {value: index for index, value in enumerate(configured_type_order)}
        selected.sort(
            key=lambda row: (
                language_order.get(row.get("language"), 9999),
                type_order.get(row.get("page_type"), 9999),
                str(row.get("page_id", "")),
                str(row.get("canonical_title", "")),
            )
        )
        expected = self.operation.get("expected_counts") or {}
        if expected:
            for language, count in expected.items():
                actual = sum(1 for row in selected if row.get("language") == language)
                if actual != int(count):
                    raise PublicationError(
                        f"Nombre de pages {language} inattendu : {actual} au lieu de {count}"
                    )
        return selected

    def _source_path(self, row: dict[str, Any]) -> Path:
        template = self.operation.get("source_path_template")
        if template:
            relative = str(template).format(**row)
        else:
            field = str(self.operation.get("source_path_field") or "file_path")
            relative = row.get(field)
            if not relative:
                raise PublicationError(
                    f"Chemin source absent pour {row.get('language')}/{row.get('page_id')}"
                )
        return self.root / str(relative)

    def _remote_title(self, row: dict[str, Any]) -> str:
        overrides = self.operation.get("remote_title_overrides") or self.config.get("remote_title_overrides") or {}
        by_language = overrides.get(row["language"], {})
        return str(by_language.get(row["page_id"], row["canonical_title"]))

    def _manifest_page(self, language: str, page_id: str) -> dict[str, Any] | None:
        for row in self.manifest.get("pages", []):
            if row.get("language") == language and str(row.get("page_id")) == page_id:
                return row
        return None

    def _registry(self) -> dict[str, Any] | None:
        """Charge le registre maître une seule fois, s'il est déclaré par le manifeste."""
        if self._registry_cache is not False:
            return self._registry_cache if isinstance(self._registry_cache, dict) else None
        relative = str(((self.manifest.get("core_files") or {}).get("registry")) or "").strip()
        if not relative:
            self._registry_cache = None
            return None
        path = self.root / relative
        if not path.is_file():
            raise PublicationError(f"Registre maître introuvable : {path}")
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise PublicationError(f"Registre maître illisible : {path}") from exc
        if not isinstance(data, dict):
            raise PublicationError(f"Registre maître invalide : {path}")
        self._registry_cache = data
        return data

    def _locked_english_title(self, page_id: str, page_type: str) -> str:
        """Résout la cible anglaise sans exiger que la page anglaise soit dans le manifeste."""
        english = self._manifest_page("en", page_id)
        if english is not None:
            title = str(english.get("canonical_title") or "").strip()
            if not title:
                raise PublicationError(
                    f"Titre canonique anglais absent du manifeste : {page_id}"
                )
            return title

        registry = self._registry()
        record: dict[str, Any] | None = None
        if registry is not None and page_type == "debate":
            debate = registry.get("debate") or {}
            if str(debate.get("id") or "") in {"", page_id, str(self.manifest.get("debate_id") or "")}:
                candidate = ((debate.get("pages") or {}).get("en") or {})
                if isinstance(candidate, dict):
                    record = candidate
        elif registry is not None and page_type == "argument":
            for node in ((registry.get("graph") or {}).get("nodes") or []):
                if isinstance(node, dict) and str(node.get("id") or "") == page_id:
                    candidate = node.get("en") or {}
                    if isinstance(candidate, dict):
                        record = candidate
                    break

        if record is None:
            raise PublicationError(
                "Cible anglaise introuvable : aucune page anglaise dans le manifeste "
                f"et aucune entrée correspondante dans le registre maître pour {page_id}"
            )
        status = str(record.get("title_status") or "").strip()
        title = str(record.get("canonical_title") or "").strip()
        if status != "locked" or not title:
            raise PublicationError(
                f"Titre canonique anglais non verrouillé dans le registre maître : {page_id}"
            )
        return title

    def _validate_norm_120_page(self, row: dict[str, Any], text: str) -> None:
        language = str(row.get("language") or "")
        page_id = str(row.get("page_id") or "")
        page_type = str(row.get("page_type") or "")
        if SPLIT_ADJACENT_TEMPLATES_RE.search(text):
            raise PublicationError(
                "Deux modèles MediaWiki adjacents doivent être accolés sous la forme }}{{ : " + f"{language}/{page_id}"
            )
        if re.search(r"<\s*references\b", text, flags=re.IGNORECASE):
            raise PublicationError(
                f"Balise <references /> interdite en norme 1.2.11 : {language}/{page_id}"
            )
        names = [span.name for span in _main_template_parameter_spans(text)]
        json_author = re.search(r"(?m)^\s*\|\s*(?:auteurs|authors)\s*=\s*\[", text)
        if json_author:
            raise PublicationError(
                f"Un champ auteurs/authors contient un tableau JSON au lieu de texte MediaWiki : {language}/{page_id}"
            )
        norm = str(((self.manifest.get("normative_versions") or {}).get("consolidated_norm") or ""))
        try:
            norm_tuple = tuple(int(part) for part in norm.split("."))
        except ValueError:
            norm_tuple = ()
        if norm_tuple >= (1, 2, 18):
            for match in re.finditer(r"(?m)^\s*\|\s*(?:auteurs|authors)\s*=\s*(.*?)\s*$", text):
                author_value = match.group(1).strip()
                malformed_separator = (
                    ";" in author_value
                    or "，" in author_value
                    or bool(re.search(r"\s+,|,(?! )|, {2,}|,$", author_value))
                )
                if malformed_separator:
                    raise PublicationError(
                        "Plusieurs auteurs doivent être séparés exactement par une virgule suivie d’une espace : "
                        f"{language}/{page_id}"
                    )
        section_param = "rubriques" if language == "fr" else "sections"
        if section_param in names:
            actual_sections = [item.strip() for item in extract_parameter(text, section_param).split(",") if item.strip()]
            expected_sections = alphabetical_values(extract_parameter(text, section_param))
            if actual_sections != expected_sections:
                raise PublicationError(
                    f"{section_param} doit être rangé par ordre alphabétique : {language}/{page_id}"
                )
        if language == "en":
            if "interlangue" in names:
                raise PublicationError(f"Lien interlangue interdit en anglais : {page_id}")
            if page_type == "debate":
                if "type" in names:
                    raise PublicationError("Le paramètre anglais |type= est interdit en norme 1.2.11")
                if names.count("topic") != 1 or names.count("complete-topic") != 1:
                    raise PublicationError(
                        "La page Debate anglaise doit contenir exactement |topic= et |complete-topic="
                    )
        if page_type == "debate":
            wikipedia_parameter = "articles-Wikipédia" if language == "fr" else "wikipedia-articles"
            wikipedia_model = "Article Wikipédia" if language == "fr" else "Wikipedia article"
            related_parameter = "débats-connexes" if language == "fr" else "related-debates"
            if names.count(wikipedia_parameter) != 1:
                raise PublicationError(
                    f"La page de débat doit contenir exactement un |{wikipedia_parameter}= non vide : {language}/{page_id}"
                )
            wikipedia_value = extract_parameter(text, wikipedia_parameter)
            article_pattern = rf"\{{\{{\s*{re.escape(wikipedia_model)}\b(?:(?!\}}\}}).)*\|\s*page\s*=\s*[^|{{}}\r\n]+(?:(?!\}}\}}).)*\}}\}}"
            if not wikipedia_value.strip() or not re.search(article_pattern, wikipedia_value, flags=re.IGNORECASE | re.DOTALL):
                raise PublicationError(
                    f"|{wikipedia_parameter}= doit contenir au moins un sous-modèle {wikipedia_model} avec un titre vérifié : {language}/{page_id}"
                )
            if related_parameter in names:
                raise PublicationError(
                    f"Le paramètre |{related_parameter}= ne doit pas être publié : {language}/{page_id}"
                )
            topic_param = "sujet" if language == "fr" else "topic"
            complete_param = "sujet-complet" if language == "fr" else "complete-topic"
            topic_value = extract_parameter(text, topic_param) if topic_param in names else ""
            complete_value = extract_parameter(text, complete_param) if complete_param in names else ""
            if not _first_alpha_is_upper(topic_value):
                raise PublicationError(f"{topic_param} doit commencer par une majuscule : {language}/{page_id}")
            if _complete_topic_is_interrogative(complete_value, language):
                raise PublicationError(
                    f"{complete_param} doit compléter l’en-tête sous une forme non interrogative : {language}/{page_id}"
                )
        if language == "en":
            return
        if language != "fr":
            return
        prose = ""
        if page_type == "argument" and "résumé" in names:
            prose = extract_parameter(text, "résumé")
        elif page_type == "debate" and "introduction" in names:
            prose = extract_parameter(text, "introduction")
        prose_without_refs = re.sub(r"<ref\b[^>]*>.*?</ref>", "", prose, flags=re.IGNORECASE | re.DOTALL)
        if PAIRED_EM_DASH_RE.search(prose_without_refs):
            raise PublicationError(
                f"Incise française entre tirets cadratins interdite; utiliser des parenthèses : {page_id}"
            )
        if names.count("interlangue") != 1:
            raise PublicationError(
                f"La page française doit contenir exactement un |interlangue= : {page_id}"
            )
        value = extract_parameter(text, "interlangue")
        if not re.search(r"\{\{\s*Lien interlangue\b", value):
            raise PublicationError(
                f"Le lien français doit utiliser {{{{Lien interlangue}}}} : {page_id}"
            )
        target = self._locked_english_title(page_id, page_type)
        target_value = extract_parameter(value, "page")
        language_value = extract_parameter(value, "langue")
        if language_value.strip() != "en" or target_value.strip() != target:
            raise PublicationError(
                f"Cible interlangue divergente pour {page_id} : {target_value!r} au lieu de {target!r}"
            )

    def _validate_local_files(self) -> None:
        parameter_kind = self.operation["kind"] == "parameter_update"
        for row in self._selected_pages():
            path = self._source_path(row)
            if not path.is_file():
                raise PublicationError(f"Fichier local absent : {path}")
            declared = row.get("sha256")
            if declared and sha_file(path) != declared and not self.operation.get("allow_source_sha_mismatch", False):
                raise PublicationError(f"Empreinte locale divergente : {path}")
            text = path.read_text(encoding="utf-8")
            if self.publication_profile == DIRECT_INTERLANGUAGE_PROFILE:
                self._validate_norm_120_page(row, text)
            if parameter_kind:
                value = extract_parameter(text, str(self._parameter(row["language"])))
                if not value.strip():
                    raise PublicationError(
                        f"Paramètre local vide : {row['language']}/{row['page_id']}"
                    )

    def _validator_command(self) -> list[str]:
        validator = self.config["validator"]
        command = [str(item) for item in validator["command"]]
        if not command:
            raise PublicationError("Commande du validateur vide")
        scopes = list(validator.get("scopes") or [])
        if "validate" in command:
            index = command.index("validate")
            command = command[: index + 1] + [str(self.root)] + command[index + 1 :]
        else:
            command.append(str(self.root))
        for scope in scopes:
            command.extend(["--scope", str(scope)])
        command.extend(["--format", "json"])
        return command

    def _validate_structural_scopes(self) -> dict[str, Any]:
        validator = self.config["validator"]
        result = subprocess.run(
            self._validator_command(),
            cwd=self.project_root,
            text=True,
            capture_output=True,
            check=False,
        )
        if result.returncode != 0:
            raise PublicationError("Validation structurelle refusée :\n" + result.stdout + result.stderr)
        try:
            report = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise PublicationError("Sortie JSON du validateur illisible") from exc
        version = recursive_find_version(report)
        if version != REQUIRED_VALIDATOR_VERSION:
            raise PublicationError(
                f"Version réelle du validateur divergente : {version!r}; attendu : {REQUIRED_VALIDATOR_VERSION}"
            )
        summary = report.get("summary") or {}
        errors = int(summary.get("errors", 0))
        warnings = int(summary.get("warnings", 0))
        if report.get("result") != "passed" or errors != 0:
            raise PublicationError("Validation structurelle non positive")
        max_warnings = int(validator.get("max_warnings", 0))
        if warnings > max_warnings:
            raise PublicationError(
                f"Trop d'avertissements du validateur : {warnings} > {max_warnings}"
            )
        for field, expected in (validator.get("expected_metrics") or {}).items():
            actual = dotted_get(report, field)
            if actual != expected:
                raise PublicationError(
                    f"Métrique divergente pour {field} : {actual!r} au lieu de {expected!r}"
                )
        return report

    def _validate_local(self) -> dict[str, Any]:
        self._validate_local_files()
        return self._validate_structural_scopes()

    def _package_fingerprints(self) -> dict[str, str]:
        validator_path = self._resolve(self.config["validator"]["fingerprint_path"])
        selected = []
        for row in self._selected_pages():
            path = self._source_path(row)
            selected.append(
                {
                    "language": row["language"],
                    "page_id": row["page_id"],
                    "page_type": row.get("page_type"),
                    "source_path": str(path.relative_to(self.root)),
                    "sha256": sha_file(path),
                }
            )
        return {
            "manifest_sha256": sha_file(self.manifest_path),
            "selected_sources_fingerprint": sha_object(selected),
            "validator_fingerprint": sha_tree(validator_path),
            "kit_script_sha256": sha_file(Path(__file__).resolve()),
            "config_sha256": sha_file(self.config_path),
        }

    def inspect(self) -> dict[str, Any]:
        report = self._validate_local()
        counts: dict[str, dict[str, int]] = {}
        for row in self._selected_pages():
            language = str(row["language"])
            page_type = str(row.get("page_type") or "unknown")
            language_counts = counts.setdefault(language, {})
            language_counts[page_type] = language_counts.get(page_type, 0) + 1
        return {
            "kit_version": KIT_VERSION,
            "debate_id": self.config["debate_id"],
            "operation": self.operation["id"],
            "kind": self.operation["kind"],
            "validator_version": recursive_find_version(report),
            "counts": counts,
        }

    def build_plan(self) -> dict[str, Any]:
        report = self._validate_local()
        actions: list[dict[str, Any]] = []
        blockers: list[dict[str, Any]] = []
        selected = self._selected_pages()
        for language in self.languages:
            rows = [row for row in selected if row["language"] == language]
            if not rows:
                continue
            _, user = self._site(language)
            self.adapter.open_language(language, user)
            try:
                self.adapter.assert_identity(user)
                self._change_tag_gate(language)
                for row in rows:
                    action = self._plan_row(row)
                    action_dict = asdict(action)
                    actions.append(action_dict)
                    if action.operation == "block":
                        blockers.append(
                            {
                                "language": action.language,
                                "page_id": action.page_id,
                                "page_type": action.page_type,
                                "title": action.title,
                                "classification": action.classification,
                                "note": action.note,
                            }
                        )
            finally:
                self.adapter.close_language()
        counts: dict[str, dict[str, int]] = {}
        for language in self.languages:
            language_actions = [item for item in actions if item["language"] == language]
            counts[language] = {
                operation: sum(1 for item in language_actions if item["operation"] == operation)
                for operation in ("create", "update", "skip", "block")
            }
            counts[language]["total"] = len(language_actions)
        plan: dict[str, Any] = {
            "plan_version": "wikidebia-publication-plan-2.2.2",
            "publication_profile": self.publication_profile,
            "kit_version": KIT_VERSION,
            "debate_id": self.config["debate_id"],
            "operation_id": self.operation["id"],
            "operation_kind": self.operation["kind"],
            "required_validator_version": REQUIRED_VALIDATOR_VERSION,
            "validator_report_sha256": sha_object(report),
            "package_fingerprints": self._package_fingerprints(),
            "change_tags": self.tags,
            "edit_summaries": self.operation["edit_summaries"],
            "actions": actions,
            "blockers": blockers,
            "counts": counts,
        }
        plan["plan_sha256"] = sha_object(plan)
        return plan

    def _plan_row(self, row: dict[str, Any]) -> PageAction:
        language = str(row["language"])
        page_id = str(row["page_id"])
        page_type = str(row.get("page_type") or "unknown")
        source_path = self._source_path(row)
        local_text = source_path.read_text(encoding="utf-8")
        parameter = self._parameter(language)
        local_target = local_text if parameter is None else extract_parameter(local_text, parameter)
        title = self._remote_title(row)
        exists, revision_id, remote_text = self.adapter.read_page(title)
        common = dict(
            operation_id=str(self.operation["id"]),
            kind=str(self.operation["kind"]),
            language=language,
            page_id=page_id,
            page_type=page_type,
            title=title,
            source_path=str(source_path.relative_to(self.root)),
            parameter=parameter,
            local_file_sha256=sha_file(source_path),
            local_target_sha256=sha_text(local_target),
        )
        if not exists:
            if self.operation["kind"] == "full_page" and self.operation.get("create_missing", True):
                return PageAction(
                    **common,
                    remote_revision_id=None,
                    remote_sha256=None,
                    remote_target_sha256=None,
                    desired_sha256=sha_text(local_text),
                    classification="remote_absent",
                    operation="create",
                )
            return PageAction(
                **common,
                remote_revision_id=None,
                remote_sha256=None,
                remote_target_sha256=None,
                desired_sha256=None,
                classification="remote_absent",
                operation="block",
                note="La page distante est absente et l'opération ne l'autorise pas.",
            )
        if revision_id is None:
            raise PublicationError(f"Révision distante absente : {title}")
        try:
            if self.operation["kind"] == "full_page":
                remote_target = remote_text
                desired_text = local_text
            else:
                assert parameter is not None
                insert_missing = bool(
                    self.operation.get("insert_missing_parameter", False)
                )

                matches = [
                    span
                    for span in _main_template_parameter_spans(remote_text)
                    if span.name == parameter
                ]

                if len(matches) == 0 and insert_missing:
                    remote_target = ""
                else:
                    remote_target = extract_parameter(
                        remote_text,
                        parameter,
                    )

                desired_text = replace_parameter(
                    remote_text,
                    parameter,
                    local_target,
                    insert_if_missing=insert_missing,
                )
        except PublicationError as exc:
            return PageAction(
                **common,
                remote_revision_id=revision_id,
                remote_sha256=sha_text(remote_text),
                remote_target_sha256=None,
                desired_sha256=None,
                classification="remote_content_invalid",
                operation="block",
                note=str(exc),
            )
        if normalize_wikicode(remote_text) == normalize_wikicode(desired_text):
            operation = "skip"
            classification = "already_equivalent"
        elif self.operation["kind"] == "parameter_update" or self.operation.get("update_existing", False):
            operation = "update"
            classification = "content_differs"
        else:
            operation = "block"
            classification = "existing_page_collision"
        note = None
        if operation == "block":
            note = "La page existe avec un contenu différent et update_existing=false."
        return PageAction(
            **common,
            remote_revision_id=revision_id,
            remote_sha256=sha_text(remote_text),
            remote_target_sha256=sha_text(remote_target),
            desired_sha256=sha_text(desired_text),
            classification=classification,
            operation=operation,
            note=note,
        )

    def _verify_plan(self, plan: dict[str, Any], confirmation: str) -> None:
        copy = dict(plan)
        claimed = copy.pop("plan_sha256", None)
        if not claimed or claimed != sha_object(copy) or confirmation != claimed:
            raise PublicationError("SHA-256 du plan divergent")
        if plan.get("kit_version") != KIT_VERSION:
            raise PublicationError("Version du kit divergente")
        if plan.get("required_validator_version") != REQUIRED_VALIDATOR_VERSION:
            raise PublicationError("Version du validateur divergente dans le plan")
        if plan.get("publication_profile") != self.publication_profile:
            raise PublicationError("Profil de publication divergent dans le plan")
        if plan.get("debate_id") != self.config.get("debate_id"):
            raise PublicationError("Plan rattaché à un autre débat")
        if plan.get("operation_id") != self.operation.get("id"):
            raise PublicationError("Plan rattaché à une autre opération")
        if plan.get("package_fingerprints") != self._package_fingerprints():
            raise PublicationError("Corpus, configuration, validateur ou kit modifié depuis le plan")
        if plan.get("change_tags") != self.tags:
            raise PublicationError("Balises divergentes du plan")
        if plan.get("edit_summaries") != self.operation.get("edit_summaries"):
            raise PublicationError("Résumés de modification divergents du plan")
        if plan.get("blockers"):
            raise CollisionError("Le plan contient des bloqueurs")

    def _desired_text(self, action: dict[str, Any], remote_text: str) -> tuple[str, str]:
        source_path = self.root / action["source_path"]
        if sha_file(source_path) != action["local_file_sha256"]:
            raise PublicationError(f"Fichier local modifié depuis le plan : {action['source_path']}")
        local_text = source_path.read_text(encoding="utf-8")
        parameter = action.get("parameter")
        local_target = local_text if not parameter else extract_parameter(local_text, str(parameter))
        if sha_text(local_target) != action["local_target_sha256"]:
            raise PublicationError(f"Cible locale modifiée depuis le plan : {action['page_id']}")
        desired = (
            local_text
            if not parameter
            else replace_parameter(
                remote_text,
                str(parameter),
                local_target,
                insert_if_missing=bool(
                    self.operation.get(
                        "insert_missing_parameter",
                        False,
                    )
                ),
            )
        )
        return desired, local_target

    def _verify_written_revision(
        self,
        *,
        title: str,
        revision_id: int,
        desired_text: str,
        summary: str,
    ) -> dict[str, Any]:
        attempts = max(1, int(self.config.get("verification_attempts", 8)))
        delay = max(0.0, float(self.config.get("verification_delay_seconds", 2)))
        observed: dict[str, Any] | None = None
        for index in range(attempts):
            observed = self.adapter.read_revision(title, revision_id)
            if (
                observed
                and sha_text(str(observed.get("text", ""))) == sha_text(desired_text)
                and observed.get("summary") == summary
                and all(tag in (observed.get("tags") or []) for tag in self.tags)
            ):
                return observed
            if index + 1 < attempts and delay:
                time.sleep(delay)
        self._log(
            {
                "event": "verification_failure",
                "title": title,
                "revision_id": revision_id,
                "expected_content_sha256": sha_text(desired_text),
                "expected_summary": summary,
                "expected_tags": self.tags,
                "observed": observed,
            }
        )
        raise RevisionConflict(f"Échec de vérification de la révision {revision_id} pour {title}")

    def create_debate_test_receipt(
        self,
        *,
        plan: dict[str, Any],
        confirmation: str,
    ) -> dict[str, Any]:
        """Crée et vérifie la page Débat française canonique liée au plan signé."""
        self._verify_plan(plan, confirmation)
        self._validate_local()
        self._prepare_logging()
        if self.publication_profile != DIRECT_INTERLANGUAGE_PROFILE:
            raise PublicationError("Le test de la page Débat est réservé au profil 1.2.18")
        if self.operation.get("kind") != "full_page":
            raise PublicationError("Le test de la page Débat exige une opération full_page")
        actions = [
            action
            for action in plan.get("actions", [])
            if action.get("language") == "fr" and action.get("page_type") == "debate"
        ]
        if len(actions) != 1:
            raise PublicationError(
                "Le plan doit contenir exactement une page Débat française canonique"
            )
        action = actions[0]
        if action.get("operation") != "create" or action.get("classification") != "remote_absent":
            raise CollisionError(
                "Le test canonique exige que la page Débat française soit absente dans le plan"
            )
        current_language = "fr"
        title = str(action["title"])
        _, user = self._site(current_language)
        summary = self._summary(current_language)
        source_path = self.root / str(action["source_path"])
        if sha_file(source_path) != action["local_file_sha256"]:
            raise PublicationError("Fichier local modifié depuis le plan")
        desired_text = source_path.read_text(encoding="utf-8")
        self.adapter.open_language(current_language, user)
        try:
            self.adapter.assert_identity(user)
            self._change_tag_gate(current_language)
            exists, _, _ = self.adapter.read_page(title)
            if exists:
                raise CollisionError("La page Débat française existe déjà depuis la simulation")
            revision_id = self.adapter.write_page(
                title=title, text=desired_text, summary=summary, tags=self.tags,
                expected_user=user, create_only=True, base_revision_id=None,
            )
            self._verify_written_revision(
                title=title, revision_id=revision_id, desired_text=desired_text, summary=summary
            )
        finally:
            self.adapter.close_language()
        receipt: dict[str, Any] = {
            "receipt_version": "wikidebia-debate-test-receipt-1",
            "status": "passed",
            "kit_version": KIT_VERSION,
            "validator_version": REQUIRED_VALIDATOR_VERSION,
            "plan_sha256": plan["plan_sha256"],
            "package_fingerprints": plan["package_fingerprints"],
            "debate_id": self.config["debate_id"],
            "operation_id": self.operation["id"],
            "language": current_language,
            "page_id": action["page_id"],
            "page_type": "debate",
            "canonical_title": title,
            "source_path": action["source_path"],
            "local_file_sha256": action["local_file_sha256"],
            "desired_sha256": action["desired_sha256"],
            "content_sha256": sha_text(desired_text),
            "revision_id": revision_id,
            "expected_user": user,
            "summary": summary,
            "tags": self.tags,
        }
        receipt["receipt_sha256"] = sha_object(receipt)
        self._log({"event": "canonical_debate_test_verified", **receipt})
        return receipt

    def _verify_debate_test_receipt(self, plan: dict[str, Any], receipt: dict[str, Any] | None) -> None:
        if (
            self.publication_profile != DIRECT_INTERLANGUAGE_PROFILE
            or self.operation.get("kind") != "full_page"
        ):
            return
        french_debate_actions = [
            action
            for action in plan.get("actions", [])
            if action.get("language") == "fr"
            and action.get("page_type") == "debate"
            and action.get("operation") == "create"
        ]
        # Le reçu canonique n'est requis que lorsqu'une page Débat française doit
        # réellement être créée. Une page déjà strictement équivalente est un skip
        # sûr et ne doit pas empêcher la commande intégrée de reprendre.
        if not french_debate_actions:
            return
        if not isinstance(receipt, dict):
            raise PublicationError("Le profil 1.2.18 exige --debate-test-receipt")
        copy = dict(receipt)
        claimed = copy.pop("receipt_sha256", None)
        if not claimed or claimed != sha_object(copy):
            raise PublicationError("Empreinte du reçu de test de la page Débat divergente")
        checks = {
            "receipt_version": "wikidebia-debate-test-receipt-1",
            "status": "passed",
            "kit_version": KIT_VERSION,
            "validator_version": REQUIRED_VALIDATOR_VERSION,
            "plan_sha256": plan.get("plan_sha256"),
            "package_fingerprints": plan.get("package_fingerprints"),
            "debate_id": self.config.get("debate_id"),
            "operation_id": self.operation.get("id"),
            "language": "fr",
            "page_type": "debate",
            "tags": self.tags,
        }
        for field, expected in checks.items():
            if receipt.get(field) != expected:
                raise PublicationError(f"Reçu de test de la page Débat divergent : {field}")
        title = str(receipt.get("canonical_title") or "")
        language = "fr"
        matching_actions = [
            action
            for action in plan.get("actions", [])
            if action.get("language") == language
            and action.get("page_type") == "debate"
            and action.get("page_id") == receipt.get("page_id")
            and action.get("title") == title
        ]
        if len(matching_actions) != 1:
            raise PublicationError("La page Débat du reçu ne correspond pas au plan")
        action = matching_actions[0]
        if action.get("operation") != "create" or action.get("classification") != "remote_absent":
            raise PublicationError("L'action Débat du reçu n'est pas une création distante absente")
        action_checks = {
            "source_path": action.get("source_path"),
            "local_file_sha256": action.get("local_file_sha256"),
            "desired_sha256": action.get("desired_sha256"),
            "content_sha256": action.get("desired_sha256"),
            "summary": self._summary(language),
        }
        for field, expected in action_checks.items():
            if receipt.get(field) != expected:
                raise PublicationError(f"Reçu de test de la page Débat divergent : {field}")
        _, user = self._site(language)
        if receipt.get("expected_user") != user:
            raise PublicationError("Identité attendue divergente dans le reçu")
        revision_id = int(receipt.get("revision_id") or 0)
        if revision_id <= 0:
            raise PublicationError("Identifiant de révision invalide dans le reçu Débat")
        self.adapter.open_language(language, user)
        try:
            self.adapter.assert_identity(user)
            self._change_tag_gate(language)
            exists, latest_revision_id, latest_text = self.adapter.read_page(title)
            if not exists or latest_revision_id != revision_id:
                raise RevisionConflict(
                    "La page Débat testée n'est plus à la révision attestée"
                )
            if sha_text(latest_text) != receipt.get("content_sha256"):
                raise RevisionConflict("Le contenu courant de la page Débat testée diverge")
            observed = self.adapter.read_revision(title, revision_id)
            if not observed:
                raise RevisionConflict("Révision du test de la page Débat introuvable")
            if sha_text(str(observed.get("text", ""))) != receipt.get("content_sha256"):
                raise RevisionConflict("Contenu du test de la page Débat divergent")
            if observed.get("summary") != receipt.get("summary"):
                raise RevisionConflict("Résumé du test de la page Débat divergent")
            if any(tag not in (observed.get("tags") or []) for tag in self.tags):
                raise RevisionConflict("Balise du test de la page Débat divergente")
        finally:
            self.adapter.close_language()

    def _corpus_version(self) -> str:
        for value in (
            self.manifest.get("release_version"),
            (self.manifest.get("release") or {}).get("version") if isinstance(self.manifest.get("release"), dict) else None,
            self.manifest.get("generated_date"),
        ):
            if isinstance(value, str) and value.strip():
                return value.strip()
        return "manifest-" + sha_file(self.manifest_path)[:16]

    def _save_published_state(self, language: str, actions: list[dict[str, Any]], plan: dict[str, Any]) -> None:
        base_value = self.config.get("published_state_dir") or ".state/published"
        base = self._resolve(base_value) / str(self.config["debate_id"]) / language
        latest = base / "latest.json"
        previous_pages: dict[str, dict[str, Any]] = {}
        if latest.is_file():
            try:
                previous = json.loads(latest.read_text(encoding="utf-8"))
                unsigned = dict(previous)
                claimed = unsigned.pop("state_sha256", None)
                if claimed == sha_object(unsigned) and previous.get("debate_id") == self.config["debate_id"]:
                    previous_pages = {str(row.get("page_id")): dict(row) for row in previous.get("pages") or []}
            except (OSError, json.JSONDecodeError):
                previous_pages = {}
        for action in actions:
            exists, revision_id, remote_text = self.adapter.read_page(action["title"])
            if not exists or revision_id is None:
                continue
            previous_pages[str(action["page_id"])] = {
                "page_id": str(action["page_id"]),
                "page_type": str(action.get("page_type") or "unknown"),
                "canonical_title": str(action["title"]),
                "content_sha256": sha_text(remote_text),
                "revision_id": int(revision_id),
                "status": "published",
            }
        now = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        pages = sorted(previous_pages.values(), key=lambda row: (row.get("page_type", ""), row.get("page_id", "")))
        receipt: dict[str, Any] = {
            "receipt_version": "wikidebia-publication-state-receipt-1.0",
            "kit_version": KIT_VERSION,
            "debate_id": self.config["debate_id"],
            "language": language,
            "corpus_version": self._corpus_version(),
            "published_at": now,
            "plan_sha256": plan["plan_sha256"],
            "pages": pages,
        }
        receipt["receipt_sha256"] = sha_object(receipt)
        receipt_base = self._resolve(self.config.get("receipts_dir") or ".state/receipts") / str(self.config["debate_id"])
        receipt_path = receipt_base / f"publication-{language}-{now.replace(':', '').replace('-', '')}.json"
        receipt_base.mkdir(parents=True, exist_ok=True)
        receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
        state: dict[str, Any] = {
            "state_version": "wikidebia-published-state-1.0",
            "debate_id": self.config["debate_id"],
            "language": language,
            "corpus_version": self._corpus_version(),
            "publication_date": now,
            "source_manifest_sha256": sha_file(self.manifest_path),
            "plan_sha256": plan["plan_sha256"],
            "receipt_path": portable(receipt_path, self.project_root),
            "receipt_sha256": receipt["receipt_sha256"],
            "pages": pages,
        }
        state["state_sha256"] = sha_object(state)
        base.mkdir(parents=True, exist_ok=True)
        latest.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
        stamped = base / (now.replace(":", "").replace("-", "") + ".json")
        stamped.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

    def publish(
        self,
        *,
        plan: dict[str, Any],
        confirmation: str,
        language: str | None = None,
        page_id: str | None = None,
        page_type: str | None = None,
        debate_test_receipt: dict[str, Any] | None = None,
    ) -> dict[str, int]:
        self._verify_plan(plan, confirmation)
        self._verify_debate_test_receipt(plan, debate_test_receipt)
        self._validate_local()
        self._prepare_logging()
        actions = list(plan["actions"])
        if language:
            actions = [item for item in actions if item["language"] == language]
        if page_id:
            actions = [item for item in actions if item["page_id"] == page_id]
        if page_type:
            actions = [item for item in actions if item["page_type"] == page_type]
        if not actions:
            raise PublicationError("Aucune action ne correspond aux filtres")
        counts = {"created": 0, "updated": 0, "skipped": 0}
        for current_language in self.languages:
            language_actions = [item for item in actions if item["language"] == current_language]
            if not language_actions:
                continue
            _, user = self._site(current_language)
            summary = self._summary(current_language)
            self.adapter.open_language(current_language, user)
            try:
                self.adapter.assert_identity(user)
                self._change_tag_gate(current_language)
                for action in language_actions:
                    result = self._execute_action(action, user, summary)
                    counts[result] += 1
                    delay = max(0.0, float(self.config.get("write_delay_seconds", 0.5)))
                    if result in {"created", "updated"} and delay:
                        time.sleep(delay)
                self._save_published_state(current_language, language_actions, plan)
            finally:
                self.adapter.close_language()
        return counts

    def _execute_action(self, action: dict[str, Any], user: str, summary: str) -> str:
        exists, revision_id, remote_text = self.adapter.read_page(action["title"])
        if action["operation"] == "create":
            source_path = self.root / action["source_path"]
            if sha_file(source_path) != action["local_file_sha256"]:
                raise PublicationError(f"Fichier local modifié : {action['source_path']}")
            desired_text = source_path.read_text(encoding="utf-8")
            if exists:
                if sha_text(remote_text) == action["desired_sha256"]:
                    self._log({"event": "resume_skip_equivalent", **self._identity(action), "revision_id": revision_id})
                    return "skipped"
                raise RevisionConflict(f"Collision créée depuis le plan : {action['title']}")
            new_revision = self.adapter.write_page(
                title=action["title"],
                text=desired_text,
                summary=summary,
                tags=self.tags,
                expected_user=user,
                create_only=True,
                base_revision_id=None,
            )
            self._verify_written_revision(
                title=action["title"], revision_id=new_revision, desired_text=desired_text, summary=summary
            )
            self._log({
                "event": "page_creation_verified",
                **self._identity(action),
                "new_revision_id": new_revision,
                "content_sha256": sha_text(desired_text),
                "summary": summary,
                "tags": self.tags,
            })
            return "created"
        if not exists or revision_id is None:
            raise RevisionConflict(f"Page distante absente : {action['title']}")
        desired_text, _ = self._desired_text(action, remote_text)
        current_sha = sha_text(remote_text)
        desired_sha = sha_text(desired_text)
        if desired_sha == current_sha:
            self._log({"event": "skip_equivalent", **self._identity(action), "revision_id": revision_id})
            return "skipped"
        if action["operation"] == "skip":
            raise RevisionConflict(f"La page n'est plus équivalente : {action['title']}")
        if action["operation"] != "update":
            raise PublicationError(f"Opération non exécutable : {action['operation']}")
        if revision_id != action["remote_revision_id"] or current_sha != action["remote_sha256"]:
            raise RevisionConflict(f"Révision distante divergente depuis le plan : {action['title']}")
        if desired_sha != action["desired_sha256"]:
            raise PublicationError(f"Résultat local divergent du plan : {action['title']}")
        new_revision = self.adapter.write_page(
            title=action["title"],
            text=desired_text,
            summary=summary,
            tags=self.tags,
            expected_user=user,
            create_only=False,
            base_revision_id=revision_id,
        )
        self._verify_written_revision(
            title=action["title"], revision_id=new_revision, desired_text=desired_text, summary=summary
        )
        event = "parameter_update_verified" if action["kind"] == "parameter_update" else "page_update_verified"
        self._log({
            "event": event,
            **self._identity(action),
            "old_revision_id": revision_id,
            "new_revision_id": new_revision,
            "old_content_sha256": current_sha,
            "new_content_sha256": desired_sha,
            "parameter": action.get("parameter"),
            "summary": summary,
            "tags": self.tags,
        })
        return "updated"

    @staticmethod
    def _identity(action: dict[str, Any]) -> dict[str, Any]:
        return {
            "operation_id": action["operation_id"],
            "language": action["language"],
            "page_id": action["page_id"],
            "page_type": action["page_type"],
            "title": action["title"],
        }


def load_config(path: str | Path) -> tuple[dict[str, Any], Path]:
    config_path = Path(path).expanduser().resolve()
    return json.loads(config_path.read_text(encoding="utf-8")), config_path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Kit générique de publication Wikidéb'IA : pages complètes ou paramètres ciblés."
    )
    parser.add_argument("--config", required=True)
    parser.add_argument("--pywikibot-dir")
    parser.add_argument("--mode", choices=("inspect", "plan", "debate-test", "publish"), default="plan")
    parser.add_argument("--plan-output", default="wikidebia_plan.json")
    parser.add_argument("--plan-input")
    parser.add_argument("--confirm-plan-sha256")
    parser.add_argument("--debate-test-receipt-output", default="wikidebia_debate_test_receipt.json")
    parser.add_argument("--debate-test-receipt")
    parser.add_argument("--language")
    parser.add_argument("--page-id")
    parser.add_argument("--page-type")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args(argv)

    config, config_path = load_config(args.config)
    if args.pywikibot_dir:
        config["pywikibot_dir"] = args.pywikibot_dir
    project_root = Path(config.get("project_root") or Path.cwd()).expanduser().resolve()
    def resolve(value: str | Path) -> Path:
        candidate = Path(value).expanduser()
        return candidate.resolve() if candidate.is_absolute() else (project_root / candidate).resolve()
    family_file = config.get("family_file")
    operation_languages = config["operation"].get("languages") or config.get("languages") or []
    adapter = PywikibotAdapter(
        str(config["family"]),
        {language: str(config["sites"][language]["code"]) for language in operation_languages},
        resolve(config["pywikibot_dir"]),
        resolve(family_file) if family_file else None,
    )
    publisher = GenericPublisher(config, adapter, config_path)

    if args.mode == "inspect":
        if args.execute:
            raise PublicationError("inspect est strictement en lecture seule")
        print(json.dumps(publisher.inspect(), ensure_ascii=False, indent=2))
        return 0
    if args.mode == "plan":
        if args.execute:
            raise PublicationError("plan est strictement en lecture seule")
        plan = publisher.build_plan()
        Path(args.plan_output).write_text(
            json.dumps(plan, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        print(plan["plan_sha256"])
        print(json.dumps(plan["counts"], ensure_ascii=False, sort_keys=True))
        return 3 if plan["blockers"] else 0
    if args.mode == "debate-test":
        if not args.execute or not args.plan_input or not args.confirm_plan_sha256:
            raise PublicationError(
                "debate-test exige --execute, --plan-input et --confirm-plan-sha256"
            )
        plan = json.loads(Path(args.plan_input).read_text(encoding="utf-8"))
        receipt = publisher.create_debate_test_receipt(
            plan=plan,
            confirmation=args.confirm_plan_sha256,
        )
        Path(args.debate_test_receipt_output).write_text(
            json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        print(receipt["receipt_sha256"])
        return 0
    if not args.execute or not args.plan_input or not args.confirm_plan_sha256:
        raise PublicationError(
            "publish exige --execute, --plan-input et --confirm-plan-sha256"
        )
    plan = json.loads(Path(args.plan_input).read_text(encoding="utf-8"))
    receipt = None
    if args.debate_test_receipt:
        receipt = json.loads(Path(args.debate_test_receipt).read_text(encoding="utf-8"))
    counts = publisher.publish(
        plan=plan,
        confirmation=args.confirm_plan_sha256,
        language=args.language,
        page_id=args.page_id,
        page_type=args.page_type,
        debate_test_receipt=receipt,
    )
    print(json.dumps(counts, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except PublicationError as exc:
        print(f"PUBLICATION BLOQUÉE : {exc}", file=sys.stderr)
        raise SystemExit(2)
```

# Source incorporée : `scripts/wikidebia_update.py`

**SHA-256 :** `73490a6b3ad8b9253142bcb8b821ec4736309eaa04ee4d2d3cad57178b741b6e`

```py
from __future__ import annotations

import argparse
import datetime as dt
import difflib
import hashlib
import importlib.util
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

# Import the publication adapter without requiring installation as a package.
_PUBLISH_PATH = Path(__file__).resolve().with_name("wikidebia_publish.py")
_spec = importlib.util.spec_from_file_location("wikidebia_publish_runtime", _PUBLISH_PATH)
_publish = importlib.util.module_from_spec(_spec)
assert _spec and _spec.loader
sys.modules.setdefault(_spec.name, _publish)
_spec.loader.exec_module(_publish)

PywikibotAdapter = _publish.PywikibotAdapter
normalize_wikicode = _publish.normalize_wikicode
sha_text = _publish.sha_text
sha_file = _publish.sha_file
sha_object = _publish.sha_object

KIT_VERSION = "2.2.2"
REQUIRED_VALIDATOR_VERSION = "0.4.19"
PLAN_VERSION = "wikidebia-remote-update-plan-1.0"
STATE_VERSION = "wikidebia-published-state-1.0"
RECEIPT_VERSION = "wikidebia-remote-update-receipt-1.0"
OPERATIONS = ("create", "update", "move", "redirect", "delete", "skip", "manual_review", "blocked")
GENERATED_MARKERS = (
    "avertissements-argument=Argument généré par IA",
    "avertissements-débat=Débat généré par IA",
    "argument-warnings=Argument generated by AI",
    "debate-warnings=Debate generated by AI",
    "avertissements-argument=Généré par ChatGPT",
    "avertissements-débat=Généré par ChatGPT",
)


class UpdateError(RuntimeError):
    pass


class PlanConflict(UpdateError):
    pass


class PermissionDenied(UpdateError):
    pass


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise UpdateError(f"JSON illisible : {path}") from exc
    if not isinstance(value, dict):
        raise UpdateError(f"Objet JSON attendu : {path}")
    return value


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def portable(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.name


def content_version(manifest: dict[str, Any]) -> str:
    for dotted in (
        ("release", "version"),
        ("release_version",),
        ("version",),
        ("generated_date",),
    ):
        current: Any = manifest
        for key in dotted:
            if not isinstance(current, dict) or key not in current:
                current = None
                break
            current = current[key]
        if isinstance(current, str) and current.strip():
            return current.strip()
    return "manifest-" + sha_object(manifest)[:16]


def page_key(language: str, page_id: str) -> tuple[str, str]:
    return language, page_id


def is_generated(text: str, extra_markers: Iterable[str] = ()) -> bool:
    markers = tuple(GENERATED_MARKERS) + tuple(extra_markers)
    return any(marker in text for marker in markers)


def is_redirect(text: str) -> bool:
    return bool(re.match(r"^\s*#(?:REDIRECTION|REDIRECT)\s*\[\[", text, flags=re.I))


def redirect_text(language: str, target: str) -> str:
    keyword = "REDIRECTION" if language == "fr" else "REDIRECT"
    return f"#{keyword} [[{target}]]\n"


def unified_diff(old: str | None, remote: str, new: str | None) -> dict[str, str]:
    result: dict[str, str] = {}
    if old is not None:
        result["published_to_remote"] = "".join(
            difflib.unified_diff(
                normalize_wikicode(old).splitlines(keepends=True),
                normalize_wikicode(remote).splitlines(keepends=True),
                fromfile="published",
                tofile="remote",
                n=3,
            )
        )
    if new is not None:
        result["remote_to_proposed"] = "".join(
            difflib.unified_diff(
                normalize_wikicode(remote).splitlines(keepends=True),
                normalize_wikicode(new).splitlines(keepends=True),
                fromfile="remote",
                tofile="proposed",
                n=3,
            )
        )
    return result


@dataclass(frozen=True)
class StatePage:
    language: str
    page_id: str
    page_type: str
    title: str
    content_sha256: str
    revision_id: int | None
    status: str = "published"
    source_path: str | None = None
    content: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "language": self.language,
            "page_id": self.page_id,
            "page_type": self.page_type,
            "canonical_title": self.title,
            "content_sha256": self.content_sha256,
            "revision_id": self.revision_id,
            "status": self.status,
            "source_path": self.source_path,
        }


class StateResolver:
    """Resolve the last attested published state without trusting the new manifest alone."""

    def __init__(self, project_root: Path, debate_id: str, corpus_root: Path) -> None:
        self.project_root = project_root.resolve()
        self.debate_id = debate_id
        self.corpus_root = corpus_root.resolve()

    def resolve(self, languages: Iterable[str]) -> tuple[dict[tuple[str, str], StatePage], dict[str, Any]]:
        wanted = set(languages)
        explicit = self._latest_state_files(wanted)
        if explicit is not None:
            return explicit, {"kind": "published_state_receipt", "paths": sorted({p.source_path for p in explicit.values() if p.source_path})}
        previous = self._previous_manifest_state(wanted)
        if previous:
            return previous, {"kind": "previous_installed_manifest", "manifest": self._last_manifest_path}
        inventory = self._remote_inventory_state(wanted)
        if inventory is not None:
            return inventory, {"kind": "remote_inventory", "paths": sorted({p.source_path for p in inventory.values() if p.source_path})}
        raise UpdateError(
            "Dernier état publié introuvable. Un reçu d’état, un ancien manifeste installé "
            "ou un inventaire distant explicitement rattaché au débat est requis."
        )

    def _latest_state_files(self, languages: set[str]) -> dict[tuple[str, str], StatePage] | None:
        result: dict[tuple[str, str], StatePage] = {}
        base = self.project_root / ".state" / "published" / self.debate_id
        for language in sorted(languages):
            path = base / language / "latest.json"
            if not path.is_file():
                return None
            data = load_json(path)
            unsigned = dict(data)
            claimed = unsigned.pop("state_sha256", None)
            if claimed != sha_object(unsigned):
                raise UpdateError(f"Empreinte d’état publié divergente : {path}")
            if data.get("debate_id") != self.debate_id or data.get("language") != language:
                raise UpdateError(f"État publié rattaché à un autre débat ou une autre langue : {path}")
            for row in data.get("pages") or []:
                page = StatePage(
                    language=language,
                    page_id=str(row["page_id"]),
                    page_type=str(row.get("page_type") or "unknown"),
                    title=str(row["canonical_title"]),
                    content_sha256=str(row["content_sha256"]),
                    revision_id=int(row["revision_id"]) if row.get("revision_id") is not None else None,
                    status=str(row.get("status") or "published"),
                    source_path=portable(path, self.project_root),
                    content=None,
                )
                result[page_key(language, page.page_id)] = page
        return result

    def _remote_inventory_state(self, languages: set[str]) -> dict[tuple[str, str], StatePage] | None:
        """Load a signed read-only inventory explicitly attached to this debate.

        The inventory is produced outside the validator from a constrained remote scan and
        stored under .state/inventories/<debate_id>/<language>.json. It uses the same signed
        page shape as a published state and is never inferred from all wiki pages.
        """
        result: dict[tuple[str, str], StatePage] = {}
        base = self.project_root / ".state" / "inventories" / self.debate_id
        for language in sorted(languages):
            path = base / f"{language}.json"
            if not path.is_file():
                return None
            data = load_json(path)
            unsigned = dict(data)
            claimed = unsigned.pop("inventory_sha256", None)
            if claimed != sha_object(unsigned):
                raise UpdateError(f"Empreinte d’inventaire distant divergente : {path}")
            if data.get("debate_id") != self.debate_id or data.get("language") != language:
                raise UpdateError(f"Inventaire distant rattaché à un autre débat ou une autre langue : {path}")
            if data.get("inventory_mode") != "explicit_debate_pages_read_only":
                raise UpdateError(f"Inventaire distant non borné au débat : {path}")
            for row in data.get("pages") or []:
                page = StatePage(
                    language=language,
                    page_id=str(row["page_id"]),
                    page_type=str(row.get("page_type") or "unknown"),
                    title=str(row["canonical_title"]),
                    content_sha256=str(row["content_sha256"]),
                    revision_id=int(row["revision_id"]) if row.get("revision_id") is not None else None,
                    status=str(row.get("status") or "published"),
                    source_path=portable(path, self.project_root),
                    content=row.get("content") if isinstance(row.get("content"), str) else None,
                )
                result[page_key(language, page.page_id)] = page
        return result

    def _previous_manifest_state(self, languages: set[str]) -> dict[tuple[str, str], StatePage]:
        candidates: list[Path] = []
        archive_root = self.project_root / "archives" / "debates"
        if archive_root.is_dir():
            candidates.extend(
                sorted(
                    archive_root.glob(f"*-{self.debate_id}/previous-corpus/manifest.json"),
                    reverse=True,
                )
            )
        # A user may keep an explicitly named previous corpus beside the installed corpus.
        candidates.extend(sorted(self.project_root.glob(f"corpus/{self.debate_id}.previous*/manifest.json"), reverse=True))
        current_manifest = self.corpus_root / "manifest.json"
        current_sha = sha_file(current_manifest) if current_manifest.is_file() else None
        for manifest_path in candidates:
            if current_sha and sha_file(manifest_path) == current_sha:
                continue
            manifest = load_json(manifest_path)
            if manifest.get("debate_id") != self.debate_id:
                continue
            pages: dict[tuple[str, str], StatePage] = {}
            root = manifest_path.parent
            for row in manifest.get("pages") or []:
                language = str(row.get("language") or "")
                if language not in languages:
                    continue
                rel = str(row.get("file_path") or row.get("source_path") or "")
                source = root / rel if rel else None
                text = source.read_text(encoding="utf-8") if source and source.is_file() else None
                digest = str(row.get("sha256") or (sha_text(text) if text is not None else ""))
                if not digest:
                    continue
                page = StatePage(
                    language=language,
                    page_id=str(row.get("page_id")),
                    page_type=str(row.get("page_type") or "unknown"),
                    title=str(row.get("canonical_title")),
                    content_sha256=digest,
                    revision_id=None,
                    source_path=portable(source, self.project_root) if source else portable(manifest_path, self.project_root),
                    content=text,
                )
                pages[page_key(language, page.page_id)] = page
            if pages:
                self._last_manifest_path = portable(manifest_path, self.project_root)
                return pages
        return {}


class UpdateAdapter:
    """Thin extension contract around the publication adapter."""

    def __init__(self, base: Any) -> None:
        self.base = base

    def __getattr__(self, name: str) -> Any:
        return getattr(self.base, name)

    def user_rights(self) -> set[str]:
        site = getattr(self.base, "site", None)
        if site is None:
            raise UpdateError("Site non ouvert")
        data = site.simple_request(action="query", meta="userinfo", uiprop="rights").submit()
        return set(((data.get("query") or {}).get("userinfo") or {}).get("rights") or [])

    def move_page(self, *, old_title: str, new_title: str, reason: str, expected_user: str, leave_redirect: bool) -> int | None:
        site = getattr(self.base, "site", None)
        if site is None:
            raise UpdateError("Site non ouvert")
        self.base.assert_identity(expected_user)
        params: dict[str, Any] = {
            "action": "move",
            "from": old_title,
            "to": new_title,
            "reason": reason,
            "movetalk": 1,
            "assert": "user",
            "assertuser": expected_user,
            "token": site.tokens["csrf"],
        }
        if not leave_redirect:
            params["noredirect"] = 1
        data = site.simple_request(**params).submit()
        moved = data.get("move") or {}
        return int(moved["toid"]) if moved.get("toid") is not None else None

    def delete_page(self, *, title: str, reason: str, expected_user: str) -> None:
        site = getattr(self.base, "site", None)
        if site is None:
            raise UpdateError("Site non ouvert")
        self.base.assert_identity(expected_user)
        site.simple_request(**{
            "action": "delete",
            "title": title,
            "reason": reason,
            "assert": "user",
            "assertuser": expected_user,
            "token": site.tokens["csrf"],
        }).submit()

    def backlinks(self, title: str) -> list[str]:
        site = getattr(self.base, "site", None)
        if site is None:
            raise UpdateError("Site non ouvert")
        found: list[str] = []
        continuation: dict[str, Any] = {}
        while True:
            data = site.simple_request(
                action="query", list="backlinks", bltitle=title, bllimit="max", blnamespace="0", **continuation
            ).submit()
            found.extend(str(row.get("title")) for row in ((data.get("query") or {}).get("backlinks") or []) if row.get("title"))
            if not data.get("continue"):
                break
            continuation = data["continue"]
        return found


class RemoteUpdatePlanner:
    def __init__(self, config: dict[str, Any], adapter: Any, config_path: Path) -> None:
        self.config = config
        self.config_path = config_path.resolve()
        self.project_root = Path(config.get("project_root") or Path.cwd()).resolve()
        self.corpus_root = self._resolve(config["corpus_root"])
        self.manifest_path = self.corpus_root / str(config.get("manifest_file") or "manifest.json")
        self.manifest = load_json(self.manifest_path)
        self.debate_id = str(config["debate_id"])
        self.languages = tuple(config.get("languages") or ("fr", "en"))
        self.adapter = adapter if hasattr(adapter, "user_rights") else UpdateAdapter(adapter)
        self.extra_markers = tuple(config.get("generated_markers") or ())
        self.migrations = self._load_migrations()
        self._validate_config()
        self.state, self.state_source = StateResolver(self.project_root, self.debate_id, self.corpus_root).resolve(self.languages)
        self.new_pages = self._new_pages()

    def _resolve(self, value: str | Path) -> Path:
        path = Path(value).expanduser()
        return path.resolve() if path.is_absolute() else (self.project_root / path).resolve()

    def _validate_config(self) -> None:
        if self.config.get("kit_version") != KIT_VERSION:
            raise UpdateError(f"kit_version doit être {KIT_VERSION}")
        if self.manifest.get("debate_id") != self.debate_id:
            raise UpdateError("debate_id divergent entre la configuration et le manifeste")
        validator = self.config.get("validator") or {}
        if validator.get("required_version") != REQUIRED_VALIDATOR_VERSION:
            raise UpdateError(f"Le validateur requis doit être {REQUIRED_VALIDATOR_VERSION}")
        if not self.languages:
            raise UpdateError("Aucune langue sélectionnée")

    def _load_migrations(self) -> list[dict[str, Any]]:
        rel = self.config.get("migrations_file")
        if not rel:
            candidate = self.corpus_root / "data" / "remote_migrations.json"
            if not candidate.is_file():
                return []
            path = candidate
        else:
            path = self._resolve(rel)
        data = load_json(path)
        if data.get("debate_id") != self.debate_id:
            raise UpdateError("Le registre de migrations appartient à un autre débat")
        entries = data.get("entries") or []
        if not isinstance(entries, list):
            raise UpdateError("entries doit être une liste dans le registre de migrations")
        return [dict(row) for row in entries]

    def _new_pages(self) -> dict[tuple[str, str], dict[str, Any]]:
        result: dict[tuple[str, str], dict[str, Any]] = {}
        for row in self.manifest.get("pages") or []:
            language = str(row.get("language") or "")
            if language not in self.languages:
                continue
            pid = str(row.get("page_id") or "")
            if not pid:
                raise UpdateError("page_id absent dans le nouveau manifeste")
            key = page_key(language, pid)
            if key in result:
                raise UpdateError(f"Page dupliquée : {language}/{pid}")
            source = self.corpus_root / str(row.get("file_path") or row.get("source_path") or "")
            if not source.is_file():
                raise UpdateError(f"Fichier de page absent : {source}")
            text = source.read_text(encoding="utf-8")
            result[key] = {
                "language": language,
                "page_id": pid,
                "page_type": str(row.get("page_type") or "unknown"),
                "title": str(row.get("canonical_title") or ""),
                "source_path": portable(source, self.project_root),
                "content": text,
                "content_sha256": sha_text(text),
                "file_sha256": sha_file(source),
            }
        if not result:
            raise UpdateError("Le nouveau manifeste ne contient aucune page sélectionnée")
        return result

    def _site(self, language: str) -> tuple[str, str]:
        row = (self.config.get("sites") or {}).get(language) or {}
        return str(row.get("code") or language), str(row.get("expected_user") or "")

    def _validate_new_corpus(self) -> dict[str, Any]:
        validator = self.config.get("validator") or {}
        command = [str(item) for item in validator.get("command") or []]
        if not command:
            raise UpdateError("Commande du validateur absente")
        if "validate" in command:
            idx = command.index("validate")
            command = command[: idx + 1] + [str(self.corpus_root)] + command[idx + 1 :]
        else:
            command.append(str(self.corpus_root))
        for scope in validator.get("scopes") or []:
            command.extend(["--scope", str(scope)])
        command.extend(["--format", "json"])
        import subprocess
        completed = subprocess.run(command, cwd=self.project_root, text=True, capture_output=True, check=False)
        if completed.returncode != 0:
            raise UpdateError("Validation du nouveau corpus refusée :\n" + completed.stdout + completed.stderr)
        try:
            report = json.loads(completed.stdout)
        except json.JSONDecodeError as exc:
            raise UpdateError("Sortie JSON du validateur illisible") from exc
        if report.get("result") not in {"passed", "passed_with_warnings"} or int((report.get("summary") or {}).get("errors", 0)):
            raise UpdateError("Le validateur n’a pas produit un résultat positif")
        actual = str(report.get("validator_version") or report.get("version") or "")
        if not actual:
            # Recursively find the first version field, as historical reports vary.
            def find(value: Any) -> str | None:
                if isinstance(value, dict):
                    for key in ("validator_version", "version"):
                        if isinstance(value.get(key), str):
                            return value[key]
                    for child in value.values():
                        found = find(child)
                        if found:
                            return found
                if isinstance(value, list):
                    for child in value:
                        found = find(child)
                        if found:
                            return found
                return None
            actual = str(find(report) or "")
        if actual != REQUIRED_VALIDATOR_VERSION:
            raise UpdateError(f"Version réelle du validateur divergente : {actual!r}")
        return report

    def _known_other_owner(self, language: str, title: str) -> str | None:
        base = self.project_root / ".state" / "published"
        if not base.is_dir():
            return None
        for state_path in base.glob("*/*/latest.json"):
            try:
                data = load_json(state_path)
            except UpdateError:
                continue
            owner = str(data.get("debate_id") or "")
            if not owner or owner == self.debate_id or data.get("language") != language:
                continue
            for row in data.get("pages") or []:
                if row.get("status") == "published" and row.get("canonical_title") == title:
                    return owner
        return None

    def _migration_for(self, language: str, old_page_id: str) -> dict[str, Any] | None:
        matches = [
            row for row in self.migrations
            if row.get("language") == language and str(row.get("old_page_id")) == old_page_id
        ]
        if len(matches) > 1:
            raise UpdateError(f"Migration dupliquée : {language}/{old_page_id}")
        return matches[0] if matches else None

    def build_plan(self, *, mode: str = "all") -> dict[str, Any]:
        report = self._validate_new_corpus()
        buckets: dict[str, list[dict[str, Any]]] = {name: [] for name in OPERATIONS}
        comparisons: list[dict[str, Any]] = []
        for language in self.languages:
            _, user = self._site(language)
            if not user:
                raise UpdateError(f"expected_user absent pour {language}")
            self.adapter.open_language(language, user)
            try:
                self.adapter.assert_identity(user)
                self._plan_language(language, buckets, comparisons)
            finally:
                self.adapter.close_language()
        for name in OPERATIONS:
            buckets[name].sort(key=lambda row: (row.get("language", ""), row.get("phase", 99), row.get("page_type", ""), row.get("page_id", ""), row.get("title", "")))
        plan: dict[str, Any] = {
            "plan_version": PLAN_VERSION,
            "kit_version": KIT_VERSION,
            "required_validator_version": REQUIRED_VALIDATOR_VERSION,
            "debate_id": self.debate_id,
            "corpus_version": content_version(self.manifest),
            "languages": list(self.languages),
            "scope_mode": mode,
            "state_source": self.state_source,
            "new_manifest_sha256": sha_file(self.manifest_path),
            "validator_report_sha256": sha_object(report),
            "config_sha256": sha_file(self.config_path),
            "operations": buckets,
            "comparisons": comparisons,
            "counts": {name: len(buckets[name]) for name in OPERATIONS},
            "preconditions": [
                "new_corpus_validated",
                "plan_sha256_confirmed",
                "effective_rights_checked_before_first_write",
                "remote_revision_rechecked_before_each_mutation",
            ],
        }
        plan["plan_sha256"] = sha_object(plan)
        return plan

    def _base_operation(self, *, language: str, page_id: str, page_type: str, title: str, justification: str) -> dict[str, Any]:
        return {
            "wiki": str((self.config.get("sites") or {}).get(language, {}).get("code") or language),
            "language": language,
            "title": title,
            "page_id": page_id,
            "page_type": page_type,
            "old_sha256": None,
            "new_sha256": None,
            "expected_revision_id": None,
            "observed_revision_id": None,
            "justification": justification,
            "preconditions": [],
            "result": None,
            "phase": 99,
        }

    def _plan_language(self, language: str, buckets: dict[str, list[dict[str, Any]]], comparisons: list[dict[str, Any]]) -> None:
        old = {key: value for key, value in self.state.items() if key[0] == language}
        new = {key: value for key, value in self.new_pages.items() if key[0] == language}
        handled_old: set[tuple[str, str]] = set()

        # Current corpus pages: create, skip, controlled update, move, or review.
        for key, proposed in new.items():
            prior = old.get(key)
            if prior and prior.title != proposed["title"]:
                self._plan_move(prior, proposed, buckets, comparisons)
                handled_old.add(key)
                continue
            exists, revision_id, remote_text = self.adapter.read_page(proposed["title"])
            op = self._base_operation(
                language=language,
                page_id=proposed["page_id"],
                page_type=proposed["page_type"],
                title=proposed["title"],
                justification="Page du nouveau corpus",
            )
            op.update({
                "source_path": proposed["source_path"],
                "local_file_sha256": proposed["file_sha256"],
                "new_sha256": proposed["content_sha256"],
                "observed_revision_id": revision_id,
                "remote_sha256": sha_text(remote_text) if exists else None,
                "phase": 1 if proposed["page_type"] == "debate" else 2,
            })
            if not exists:
                op["preconditions"] = ["title_absent_at_execution"]
                buckets["create"].append(op)
            elif sha_text(remote_text) == proposed["content_sha256"]:
                op["justification"] = "Contenu distant déjà équivalent"
                op["phase"] = 0
                buckets["skip"].append(op)
            elif prior is None:
                op["justification"] = "Page existante non attestée dans l’ancien état publié"
                op["phase"] = 0
                op["remote_excerpt"] = remote_text[:500]
                buckets["blocked"].append(op)
            elif self._remote_matches_prior(prior, revision_id, remote_text):
                op.update({
                    "old_sha256": prior.content_sha256,
                    "expected_revision_id": revision_id,
                    "justification": "Page inchangée depuis la dernière publication automatisée; remplacement contrôlé autorisé",
                    "preconditions": ["same_debate_id", "remote_matches_published_state", "baserevid_unchanged"],
                    "phase": 1 if proposed["page_type"] == "debate" else 3,
                })
                buckets["update"].append(op)
            else:
                op.update({
                    "old_sha256": prior.content_sha256,
                    "expected_revision_id": prior.revision_id,
                    "justification": "Modification humaine ou provenance distante indéterminée détectée",
                    "phase": 0,
                })
                comparison = self._comparison(prior, remote_text, proposed["content"])
                comparisons.append(comparison)
                op["comparison_id"] = comparison["comparison_id"]
                buckets["manual_review"].append(op)

        # Retired pages: explicit merge policy or safe deletion; never infer ownership from absence alone.
        for key, prior in old.items():
            if key in handled_old or key in new:
                continue
            migration = self._migration_for(language, prior.page_id)
            if migration and migration.get("kind") == "merge":
                self._plan_merge(prior, migration, buckets, comparisons)
            else:
                self._plan_retirement(prior, migration, buckets, comparisons)

    def _remote_matches_prior(self, prior: StatePage, revision_id: int | None, remote_text: str) -> bool:
        digest_matches = sha_text(remote_text) == prior.content_sha256
        revision_matches = prior.revision_id is not None and revision_id == prior.revision_id
        return digest_matches or revision_matches

    def _comparison(self, prior: StatePage, remote_text: str, proposed_text: str | None) -> dict[str, Any]:
        payload = {
            "language": prior.language,
            "page_id": prior.page_id,
            "title": prior.title,
            "published_sha256": prior.content_sha256,
            "remote_sha256": sha_text(remote_text),
            "proposed_sha256": sha_text(proposed_text) if proposed_text is not None else None,
            "diffs": unified_diff(prior.content, remote_text, proposed_text),
        }
        payload["comparison_id"] = sha_object(payload)[:20]
        return payload

    def _plan_move(self, prior: StatePage, proposed: dict[str, Any], buckets: dict[str, list[dict[str, Any]]], comparisons: list[dict[str, Any]]) -> None:
        source_exists, source_rev, source_text = self.adapter.read_page(prior.title)
        target_exists, target_rev, target_text = self.adapter.read_page(proposed["title"])
        op = self._base_operation(
            language=prior.language,
            page_id=prior.page_id,
            page_type=prior.page_type,
            title=prior.title,
            justification="Titre canonique modifié sans changement d’identité logique",
        )
        op.update({
            "old_title": prior.title,
            "new_title": proposed["title"],
            "old_sha256": prior.content_sha256,
            "new_sha256": proposed["content_sha256"],
            "source_path": proposed["source_path"],
            "local_file_sha256": proposed["file_sha256"],
            "expected_revision_id": source_rev,
            "observed_revision_id": source_rev,
            "target_revision_id": target_rev,
            "policy": "move",
            "leave_redirect": bool(self.config.get("move_leave_redirect", True)),
            "phase": 4,
            "preconditions": ["source_matches_published_state", "target_absent", "move_right"],
        })
        if not source_exists:
            if target_exists and sha_text(target_text) == proposed["content_sha256"]:
                op["title"] = proposed["title"]
                op["justification"] = "Déplacement déjà effectué et cible équivalente"
                op["phase"] = 0
                buckets["skip"].append(op)
            else:
                op["justification"] = "Source du déplacement absente et cible non équivalente"
                op["phase"] = 0
                buckets["blocked"].append(op)
            return
        if target_exists:
            op["justification"] = "La cible du déplacement existe déjà"
            op["phase"] = 0
            buckets["blocked"].append(op)
            return
        if not self._remote_matches_prior(prior, source_rev, source_text):
            comparison = self._comparison(prior, source_text, proposed["content"])
            comparisons.append(comparison)
            op["comparison_id"] = comparison["comparison_id"]
            op["justification"] = "Source du déplacement modifiée depuis la publication automatisée"
            op["phase"] = 0
            buckets["manual_review"].append(op)
            return
        buckets["move"].append(op)

    def _plan_merge(self, prior: StatePage, migration: dict[str, Any], buckets: dict[str, list[dict[str, Any]]], comparisons: list[dict[str, Any]]) -> None:
        target_id = str(migration.get("target_page_id") or "")
        target = self.new_pages.get(page_key(prior.language, target_id))
        if not target:
            op = self._base_operation(language=prior.language, page_id=prior.page_id, page_type=prior.page_type, title=prior.title, justification="Cible de fusion absente du nouveau corpus")
            buckets["blocked"].append(op)
            return
        policy = str(migration.get("policy") or "redirect")
        if policy == "delete":
            self._plan_retirement(prior, {**migration, "reason": "fusion", "target_title": target["title"]}, buckets, comparisons)
            return
        if policy != "redirect":
            raise UpdateError(f"Politique de fusion inconnue : {policy}")
        exists, revision_id, remote_text = self.adapter.read_page(prior.title)
        op = self._base_operation(language=prior.language, page_id=prior.page_id, page_type=prior.page_type, title=prior.title, justification="Argument fusionné; redirection explicite vers la page conservée")
        desired = redirect_text(prior.language, target["title"])
        backlinks = self.adapter.backlinks(prior.title) if exists else []
        op.update({
            "old_sha256": prior.content_sha256,
            "new_sha256": sha_text(desired),
            "redirect_target": target["title"],
            "expected_revision_id": revision_id,
            "observed_revision_id": revision_id,
            "remote_sha256": sha_text(remote_text) if exists else None,
            "backlinks": backlinks,
            "phase": 5,
            "preconditions": ["same_debate_id", "source_matches_published_state", "target_in_new_corpus", "edit_right"],
        })
        if not exists:
            op["justification"] = "Ancienne page déjà absente"
            op["phase"] = 0
            buckets["skip"].append(op)
        elif sha_text(remote_text) == sha_text(desired):
            op["justification"] = "Redirection déjà installée"
            op["phase"] = 0
            buckets["skip"].append(op)
        elif not self._remote_matches_prior(prior, revision_id, remote_text):
            comparison = self._comparison(prior, remote_text, desired)
            comparisons.append(comparison)
            op["comparison_id"] = comparison["comparison_id"]
            op["justification"] = "Ancienne page fusionnée modifiée manuellement"
            op["phase"] = 0
            buckets["manual_review"].append(op)
        else:
            buckets["redirect"].append(op)

    def _plan_retirement(self, prior: StatePage, migration: dict[str, Any] | None, buckets: dict[str, list[dict[str, Any]]], comparisons: list[dict[str, Any]]) -> None:
        reason = str((migration or {}).get("reason") or (migration or {}).get("kind") or "suppression")
        target = (migration or {}).get("target_title")
        owner = self._known_other_owner(prior.language, prior.title)
        exists, revision_id, remote_text = self.adapter.read_page(prior.title)
        op = self._base_operation(language=prior.language, page_id=prior.page_id, page_type=prior.page_type, title=prior.title, justification=f"Page retirée de l’ancien corpus ({reason})")
        op.update({
            "old_sha256": prior.content_sha256,
            "expected_revision_id": prior.revision_id,
            "observed_revision_id": revision_id,
            "remote_sha256": sha_text(remote_text) if exists else None,
            "retirement_reason": reason,
            "target": target,
            "phase": 7,
            "preconditions": [
                "attested_in_previous_state",
                "absent_from_new_corpus",
                "not_owned_by_other_known_debate",
                "remote_matches_published_state",
                "generated_marker_present",
                "delete_right",
            ],
        })
        if not exists:
            op["justification"] = "Page retirée déjà absente; reprise idempotente"
            op["phase"] = 0
            buckets["skip"].append(op)
            return
        if owner:
            op["justification"] = f"Titre également utilisé par le débat {owner}"
            op["other_debate_id"] = owner
            op["phase"] = 0
            buckets["blocked"].append(op)
            return
        if is_redirect(remote_text):
            op["justification"] = "L’ancienne page est devenue une redirection ou une page indépendante"
            op["phase"] = 0
            buckets["manual_review"].append(op)
            return
        if not self._remote_matches_prior(prior, revision_id, remote_text):
            comparison = self._comparison(prior, remote_text, None)
            comparisons.append(comparison)
            op["comparison_id"] = comparison["comparison_id"]
            op["justification"] = "Page retirée modifiée après la dernière publication automatisée"
            op["phase"] = 0
            buckets["manual_review"].append(op)
            return
        if not is_generated(remote_text, self.extra_markers):
            op["justification"] = "Marqueur Wikidéb’IA attendu absent"
            op["phase"] = 0
            buckets["blocked"].append(op)
            return
        try:
            op["backlinks"] = self.adapter.backlinks(prior.title)
        except Exception:
            op["backlinks"] = []
        buckets["delete"].append(op)


class PlanExecutor:
    def __init__(self, config: dict[str, Any], adapter: Any, config_path: Path) -> None:
        self.config = config
        self.config_path = config_path.resolve()
        self.project_root = Path(config.get("project_root") or Path.cwd()).resolve()
        self.corpus_root = self._resolve(config["corpus_root"])
        self.manifest = load_json(self.corpus_root / str(config.get("manifest_file") or "manifest.json"))
        self.debate_id = str(config["debate_id"])
        self.languages = tuple(config.get("languages") or ("fr", "en"))
        self.adapter = adapter if hasattr(adapter, "user_rights") else UpdateAdapter(adapter)
        self.logs_dir = self._resolve(config.get("logs_dir") or "logs")
        self.state_dir = self._resolve(config.get("published_state_dir") or ".state/published")
        self.receipts_dir = self._resolve(config.get("receipts_dir") or ".state/receipts")

    def _resolve(self, value: str | Path) -> Path:
        path = Path(value).expanduser()
        return path.resolve() if path.is_absolute() else (self.project_root / path).resolve()

    def verify_plan(self, plan: dict[str, Any], confirmation: str) -> None:
        unsigned = dict(plan)
        claimed = unsigned.pop("plan_sha256", None)
        if not claimed or claimed != sha_object(unsigned) or confirmation != claimed:
            raise PlanConflict("Empreinte du plan divergente")
        checks = {
            "plan_version": PLAN_VERSION,
            "kit_version": KIT_VERSION,
            "required_validator_version": REQUIRED_VALIDATOR_VERSION,
            "debate_id": self.debate_id,
            "new_manifest_sha256": sha_file(self.corpus_root / "manifest.json"),
            "config_sha256": sha_file(self.config_path),
        }
        for field, expected in checks.items():
            if plan.get(field) != expected:
                raise PlanConflict(f"Plan divergent : {field}")
        if (plan.get("operations") or {}).get("blocked"):
            raise PlanConflict("Le plan contient des opérations bloquées")

    def _selected_operations(self, plan: dict[str, Any], *, only_delete: bool, no_delete: bool) -> list[dict[str, Any]]:
        operations = plan.get("operations") or {}
        names: tuple[str, ...]
        if only_delete:
            names = ("redirect", "delete")
        elif no_delete:
            names = ("create", "update", "move", "redirect")
        else:
            names = ("create", "update", "move", "redirect", "delete")
        selected: list[dict[str, Any]] = []
        for name in names:
            for row in operations.get(name) or []:
                selected.append({**row, "operation": name})
        return selected

    @staticmethod
    def _required_rights(operation: str) -> set[str]:
        return {
            "create": {"edit", "createpage"},
            "update": {"edit"},
            "move": {"move"},
            "redirect": {"edit"},
            "delete": {"delete"},
        }.get(operation, set())

    def _preflight_rights(self, selected: list[dict[str, Any]]) -> None:
        for language in self.languages:
            relevant = [row for row in selected if row["language"] == language]
            if not relevant:
                continue
            expected_user = str(self.config["sites"][language]["expected_user"])
            self.adapter.open_language(language, expected_user)
            try:
                self.adapter.assert_identity(expected_user)
                available = self.adapter.user_rights()
                required = set().union(*(self._required_rights(row["operation"]) for row in relevant))
                missing = sorted(required - available)
                if missing:
                    raise PermissionDenied(
                        f"Droits MediaWiki absents sur {language} : {', '.join(missing)}. "
                        "Aucune écriture n’a été effectuée."
                    )
            finally:
                self.adapter.close_language()

    def execute(self, plan: dict[str, Any], confirmation: str, *, only_delete: bool = False, no_delete: bool = False) -> dict[str, Any]:
        if only_delete and no_delete:
            raise UpdateError("--only-delete et --no-delete sont incompatibles")
        self.verify_plan(plan, confirmation)
        selected = self._selected_operations(plan, only_delete=only_delete, no_delete=no_delete)
        self._preflight_rights(selected)
        lock = self._acquire_lock()
        results: list[dict[str, Any]] = []
        try:
            for language in self.languages:
                rows = [row for row in selected if row["language"] == language]
                if not rows:
                    continue
                user = str(self.config["sites"][language]["expected_user"])
                self.adapter.open_language(language, user)
                try:
                    self.adapter.assert_identity(user)
                    ordered = sorted(rows, key=lambda item: (item.get("phase", 99), item.get("page_id", "")))
                    for row in [item for item in ordered if item["operation"] != "delete"]:
                        results.append(self._execute_one(row, user, plan))
                    # Verify the complete new graph before the first destructive deletion.
                    delete_rows = [item for item in ordered if item["operation"] == "delete"]
                    if delete_rows:
                        self._verify_new_pages(language)
                    for row in delete_rows:
                        results.append(self._execute_one(row, user, plan))
                finally:
                    self.adapter.close_language()
            receipt = self._final_receipt(plan, results, only_delete=only_delete, no_delete=no_delete)
            self._write_receipt(receipt)
            self._write_published_states(plan, receipt)
            return receipt
        finally:
            try:
                lock.unlink()
            except FileNotFoundError:
                pass

    def _acquire_lock(self) -> Path:
        path = self.project_root / ".state" / "locks" / f"{self.debate_id}.lock"
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError as exc:
            raise UpdateError(f"Une reprise est déjà verrouillée : {path}") from exc
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(str(os.getpid()))
        return path

    def _summary(self, language: str, operation: str, plan: dict[str, Any]) -> str:
        configured = (self.config.get("edit_summaries") or {}).get(language)
        if configured:
            return str(configured).format(debate_id=self.debate_id, corpus_version=plan.get("corpus_version"), operation=operation)
        if language == "fr":
            return f"Mise à jour du corpus Wikidéb’IA {self.debate_id}, version {plan.get('corpus_version')}"
        return f"Update of Wikidéb’IA corpus {self.debate_id}, version {plan.get('corpus_version')}"

    def _source_text(self, row: dict[str, Any]) -> str:
        path = self._resolve(row["source_path"])
        if sha_file(path) != row.get("local_file_sha256"):
            raise PlanConflict(f"Fichier local modifié depuis le plan : {row['source_path']}")
        text = path.read_text(encoding="utf-8")
        if sha_text(text) != row.get("new_sha256"):
            raise PlanConflict(f"Contenu local divergent du plan : {row['title']}")
        return text

    def _execute_one(self, row: dict[str, Any], user: str, plan: dict[str, Any]) -> dict[str, Any]:
        operation = row["operation"]
        title = row["title"]
        exists, revision_id, remote_text = self.adapter.read_page(title)
        summary = self._summary(row["language"], operation, plan)
        result = {"operation": operation, "language": row["language"], "page_id": row["page_id"], "title": title, "status": None}
        if operation == "create":
            desired = self._source_text(row)
            if exists:
                if sha_text(remote_text) == row["new_sha256"]:
                    result.update(status="already_done", revision_id=revision_id)
                    return result
                raise PlanConflict(f"Collision apparue après le plan : {title}")
            new_rev = self.adapter.write_page(title=title, text=desired, summary=summary, tags=["chatgpt"], expected_user=user, create_only=True, base_revision_id=None)
            result.update(status="created", revision_id=new_rev, content_sha256=sha_text(desired))
            return result
        if operation == "update":
            desired = self._source_text(row)
            if not exists or revision_id is None:
                raise PlanConflict(f"Page à mettre à jour devenue absente : {title}")
            if sha_text(remote_text) == row["new_sha256"]:
                result.update(status="already_done", revision_id=revision_id)
                return result
            if revision_id != row.get("expected_revision_id") or sha_text(remote_text) != row.get("old_sha256"):
                raise PlanConflict(f"Modification distante intervenue depuis le plan : {title}")
            new_rev = self.adapter.write_page(title=title, text=desired, summary=summary, tags=["chatgpt"], expected_user=user, create_only=False, base_revision_id=revision_id)
            result.update(status="updated", old_revision_id=revision_id, revision_id=new_rev, content_sha256=sha_text(desired))
            return result
        if operation == "move":
            old_title, new_title = row["old_title"], row["new_title"]
            source_exists, source_rev, source_text = self.adapter.read_page(old_title)
            target_exists, target_rev, target_text = self.adapter.read_page(new_title)
            desired = self._source_text(row)
            if not source_exists:
                if target_exists and sha_text(target_text) == row["new_sha256"]:
                    result.update(status="already_done", title=new_title, revision_id=target_rev)
                    return result
                raise PlanConflict(f"Source du déplacement absente : {old_title}")
            if target_exists:
                raise PlanConflict(f"Cible du déplacement apparue : {new_title}")
            if source_rev != row.get("expected_revision_id") or sha_text(source_text) != row.get("old_sha256"):
                raise PlanConflict(f"Source du déplacement modifiée : {old_title}")
            self.adapter.move_page(old_title=old_title, new_title=new_title, reason=summary, expected_user=user, leave_redirect=bool(row.get("leave_redirect", True)))
            moved_exists, moved_rev, moved_text = self.adapter.read_page(new_title)
            if not moved_exists or moved_rev is None:
                raise PlanConflict(f"Déplacement non vérifiable : {new_title}")
            if sha_text(moved_text) != row["new_sha256"]:
                moved_rev2 = self.adapter.write_page(title=new_title, text=desired, summary=summary, tags=["chatgpt"], expected_user=user, create_only=False, base_revision_id=moved_rev)
                moved_rev = moved_rev2
            result.update(status="moved", title=new_title, revision_id=moved_rev)
            return result
        if operation == "redirect":
            desired = redirect_text(row["language"], row["redirect_target"])
            if not exists or revision_id is None:
                result.update(status="already_absent")
                return result
            if sha_text(remote_text) == sha_text(desired):
                result.update(status="already_done", revision_id=revision_id)
                return result
            if revision_id != row.get("expected_revision_id") or sha_text(remote_text) != row.get("old_sha256"):
                raise PlanConflict(f"Page à rediriger modifiée depuis le plan : {title}")
            new_rev = self.adapter.write_page(title=title, text=desired, summary=summary, tags=["chatgpt"], expected_user=user, create_only=False, base_revision_id=revision_id)
            result.update(status="redirected", revision_id=new_rev, target=row["redirect_target"])
            return result
        if operation == "delete":
            if not exists:
                result.update(status="already_absent")
                return result
            if revision_id != row.get("observed_revision_id") or sha_text(remote_text) != row.get("old_sha256"):
                raise PlanConflict(f"Page à supprimer modifiée depuis le plan : {title}")
            if not is_generated(remote_text, self.config.get("generated_markers") or ()):
                raise PlanConflict(f"Marqueur Wikidéb’IA absent avant suppression : {title}")
            self.adapter.delete_page(title=title, reason=summary, expected_user=user)
            after_exists, _, _ = self.adapter.read_page(title)
            if after_exists:
                raise PlanConflict(f"Suppression non vérifiée : {title}")
            result.update(status="deleted", old_revision_id=revision_id)
            return result
        raise UpdateError(f"Opération inconnue : {operation}")

    def _verify_new_pages(self, language: str) -> None:
        for row in self.manifest.get("pages") or []:
            if row.get("language") != language:
                continue
            source = self.corpus_root / str(row.get("file_path") or row.get("source_path") or "")
            desired_sha = sha_text(source.read_text(encoding="utf-8"))
            exists, _, remote_text = self.adapter.read_page(str(row.get("canonical_title")))
            if not exists or sha_text(remote_text) != desired_sha:
                raise PlanConflict(
                    "Suppression finale interdite : le nouveau graphe publié n’est pas entièrement équivalent "
                    f"pour {language}/{row.get('page_id')}"
                )

    def _final_receipt(self, plan: dict[str, Any], results: list[dict[str, Any]], *, only_delete: bool, no_delete: bool) -> dict[str, Any]:
        receipt: dict[str, Any] = {
            "receipt_version": RECEIPT_VERSION,
            "kit_version": KIT_VERSION,
            "debate_id": self.debate_id,
            "corpus_version": plan.get("corpus_version"),
            "plan_sha256": plan["plan_sha256"],
            "executed_at": utc_now(),
            "execution_mode": "only_delete" if only_delete else ("no_delete" if no_delete else "full_update"),
            "results": results,
            "counts": {},
        }
        statuses = sorted({str(row.get("status")) for row in results})
        receipt["counts"] = {status: sum(1 for row in results if row.get("status") == status) for status in statuses}
        receipt["receipt_sha256"] = sha_object(receipt)
        return receipt

    def _write_receipt(self, receipt: dict[str, Any]) -> None:
        stamp = receipt["executed_at"].replace(":", "").replace("-", "")
        directory = self.receipts_dir / self.debate_id
        write_json(directory / f"{stamp}.json", receipt)
        write_json(directory / "latest.json", receipt)

    def _write_published_states(self, plan: dict[str, Any], receipt: dict[str, Any]) -> None:
        # Read the final remote state sequentially. This captures revision IDs for future safe updates.
        for language in self.languages:
            user = str(self.config["sites"][language]["expected_user"])
            self.adapter.open_language(language, user)
            try:
                pages: list[dict[str, Any]] = []
                for row in self.manifest.get("pages") or []:
                    if row.get("language") != language:
                        continue
                    title = str(row.get("canonical_title"))
                    exists, revision_id, remote_text = self.adapter.read_page(title)
                    if not exists or revision_id is None:
                        continue
                    pages.append({
                        "page_id": str(row.get("page_id")),
                        "page_type": str(row.get("page_type") or "unknown"),
                        "canonical_title": title,
                        "content_sha256": sha_text(remote_text),
                        "revision_id": revision_id,
                        "status": "published",
                    })
                state: dict[str, Any] = {
                    "state_version": STATE_VERSION,
                    "debate_id": self.debate_id,
                    "language": language,
                    "corpus_version": plan.get("corpus_version"),
                    "publication_date": utc_now(),
                    "source_manifest_sha256": sha_file(self.corpus_root / "manifest.json"),
                    "plan_sha256": plan["plan_sha256"],
                    "receipt_path": portable(self.receipts_dir / self.debate_id / "latest.json", self.project_root),
                    "receipt_sha256": receipt["receipt_sha256"],
                    "pages": sorted(pages, key=lambda row: (row["page_type"], row["page_id"])),
                }
                state["state_sha256"] = sha_object(state)
                directory = self.state_dir / self.debate_id / language
                write_json(directory / "latest.json", state)
                write_json(directory / f"{state['publication_date'].replace(':', '').replace('-', '')}.json", state)
            finally:
                self.adapter.close_language()


def build_adapter(config: dict[str, Any], project_root: Path) -> Any:
    def resolve(value: str | Path) -> Path:
        path = Path(value).expanduser()
        return path.resolve() if path.is_absolute() else (project_root / path).resolve()
    family_file = config.get("family_file")
    base = PywikibotAdapter(
        str(config.get("family") or "wikidebates"),
        {language: str(config["sites"][language]["code"]) for language in config.get("languages") or []},
        resolve(config["pywikibot_dir"]),
        resolve(family_file) if family_file else None,
    )
    return UpdateAdapter(base)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Reprise distante contrôlée d’un corpus Wikidéb’IA déjà publié")
    parser.add_argument("--config", required=True)
    parser.add_argument("--mode", choices=("plan", "execute"), default="plan")
    parser.add_argument("--plan-output", default="wikidebia_update_plan.json")
    parser.add_argument("--plan-input")
    parser.add_argument("--confirm-plan-sha256")
    parser.add_argument("--only-delete", action="store_true")
    parser.add_argument("--no-delete", action="store_true")
    args = parser.parse_args(argv)
    config_path = Path(args.config).resolve()
    config = load_json(config_path)
    project_root = Path(config.get("project_root") or Path.cwd()).resolve()
    adapter = build_adapter(config, project_root)
    if args.mode == "plan":
        planner = RemoteUpdatePlanner(config, adapter, config_path)
        mode = "only_delete" if args.only_delete else ("no_delete" if args.no_delete else "all")
        plan = planner.build_plan(mode=mode)
        write_json(Path(args.plan_output), plan)
        print(plan["plan_sha256"])
        print(json.dumps(plan["counts"], ensure_ascii=False, sort_keys=True))
        return 3 if plan["operations"]["blocked"] else 0
    if not args.plan_input or not args.confirm_plan_sha256:
        raise UpdateError("execute exige --plan-input et --confirm-plan-sha256")
    plan = load_json(Path(args.plan_input))
    executor = PlanExecutor(config, adapter, config_path)
    receipt = executor.execute(plan, args.confirm_plan_sha256, only_delete=args.only_delete, no_delete=args.no_delete)
    print(json.dumps(receipt["counts"], ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:  # No unhandled Pywikibot traceback in production automation.
        print(f"MISE À JOUR BLOQUÉE : {exc}", file=sys.stderr)
        raise SystemExit(2)
```

# Source incorporée : `tests/test_versions_file.py`

**SHA-256 :** `8e57fffa870005788a63f7af4b2f830231d2e8eceed11eac5750e00b69e8b498`

```py
from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_versions_file_has_only_the_three_functional_versions():
    versions = json.loads((ROOT / "VERSIONS.json").read_text(encoding="utf-8"))
    assert versions == {"norm": "1.2.18", "validator": "0.4.19", "kit": "2.2.2"}


def test_versions_file_matches_kit_metadata_and_script():
    versions = json.loads((ROOT / "VERSIONS.json").read_text(encoding="utf-8"))
    manifest = json.loads((ROOT / "KIT_MANIFEST.json").read_text(encoding="utf-8"))
    assert manifest["version"] == versions["kit"]
    assert manifest["validator_version"] == versions["validator"]
    assert manifest["normative_revision"] == versions["norm"]
    script = (ROOT / "scripts/wikidebia_publish.py").read_text(encoding="utf-8")
    assert re.search(r'^KIT_VERSION\s*=\s*"' + re.escape(versions["kit"]) + r'"', script, re.M)
    assert re.search(r'^REQUIRED_VALIDATOR_VERSION\s*=\s*"' + re.escape(versions["validator"]) + r'"', script, re.M)
```

# Source incorporée : `tests/test_wikidebia_manage.py`

**SHA-256 :** `0597f39adf34cc3927f126435984264ec19d8a87d924c43f2a024a69b1560375`

```py
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "wikidebia_manage.py"
spec = importlib.util.spec_from_file_location("wikidebia_manage", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
sys.modules[spec.name] = module
spec.loader.exec_module(module)


def test_scope_values_cover_requested_publication_modes():
    assert module.scope_values("all") == (["fr", "en"], [])
    assert module.scope_values("fr") == (["fr"], [])
    assert module.scope_values("en") == (["en"], [])
    assert module.scope_values("fr-debate") == (["fr"], ["debate"])
    assert module.scope_values("en-debate") == (["en"], ["debate"])


def test_generated_config_is_relative_and_debate_first(tmp_path: Path):
    (tmp_path / "config").mkdir()
    run_dir = tmp_path / "plans" / "demo" / "run"
    run_dir.mkdir(parents=True)
    path = module.publication_config(tmp_path, "demo", "all", run_dir)
    config = json.loads(path.read_text(encoding="utf-8"))
    assert config["project_root"] == "."
    assert config["pywikibot_dir"] == "private/pywikibot"
    assert config["corpus_root"] == "corpus/demo"
    assert config["operation"]["page_type_order"] == ["debate", "argument"]
    assert config["validator"]["required_version"] == "0.4.19"
    assert config["manifest_requirements"] == {}
    assert str(tmp_path) not in path.read_text(encoding="utf-8")


def test_gitignore_excludes_secrets_runtime_and_corpus():
    ignore = (SCRIPT.parents[1] / "root_template" / ".gitignore").read_text(encoding="utf-8")
    for token in (
        "/private/", "/corpus/", "/archives/", "/updates/", "/incoming/",
        "/logs/", "/plans/", "/configs/", "/apicache/", "/.gitconfig-wikidebia",
        "/user-config.py", "/user-password.cfg", "*.lwp", "throttle.ctrl",
    ):
        assert token in ignore


def test_portability_check_rejects_current_root_literal(tmp_path: Path):
    (tmp_path / "kit").mkdir()
    (tmp_path / "kit" / "bad.txt").write_text(str(tmp_path), encoding="utf-8")
    try:
        module.assert_portable_sources(tmp_path)
    except module.ManagementError as exc:
        assert "Chemin absolu" in str(exc)
    else:
        raise AssertionError("chemin absolu accepté")


def test_git_commit_sets_repository_identity_when_none_is_configured(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("GIT_CONFIG_NOSYSTEM", "1")
    monkeypatch.setenv("GIT_CONFIG_GLOBAL", str(tmp_path / "empty-global-gitconfig"))
    (tmp_path / ".gitignore").write_text((SCRIPT.parents[1] / "root_template" / ".gitignore").read_text(encoding="utf-8"), encoding="utf-8")
    (tmp_path / "tracked.txt").write_text("contenu\n", encoding="utf-8")
    module.git_commit_and_push(tmp_path, "Test", push=False)
    name = module.run(["git", "config", "--local", "--get", "user.name"], cwd=tmp_path, capture=True).stdout.strip()
    email = module.run(["git", "config", "--local", "--get", "user.email"], cwd=tmp_path, capture=True).stdout.strip()
    assert name == "Wikidéb’IA"
    assert email == "wikidebia@localhost"


def test_single_zip_in_incoming_is_selected_automatically(tmp_path: Path):
    incoming = tmp_path / "incoming"
    incoming.mkdir()
    archive = incoming / "gpa_autorisation.zip"
    archive.write_bytes(b"not-opened-here")
    assert module.find_debate_archive(tmp_path, None) == archive


def test_multiple_zips_require_an_identifier(tmp_path: Path):
    incoming = tmp_path / "incoming"
    incoming.mkdir()
    (incoming / "gpa_autorisation.zip").write_bytes(b"a")
    (incoming / "vote_obligatoire.zip").write_bytes(b"b")
    try:
        module.find_debate_archive(tmp_path, None)
    except module.ManagementError as exc:
        message = str(exc)
        assert "Plusieurs archives ZIP" in message
        assert "gpa_autorisation" in message
        assert "vote_obligatoire" in message
    else:
        raise AssertionError("plusieurs ZIP acceptés sans identifiant")


def test_identifier_selects_matching_zip_in_incoming(tmp_path: Path):
    incoming = tmp_path / "incoming"
    incoming.mkdir()
    expected = incoming / "gpa_autorisation.zip"
    expected.write_bytes(b"a")
    (incoming / "vote_obligatoire.zip").write_bytes(b"b")
    assert module.find_debate_archive(tmp_path, "gpa_autorisation") == expected


def test_identifier_must_not_include_zip_extension(tmp_path: Path):
    (tmp_path / "incoming").mkdir()
    try:
        module.find_debate_archive(tmp_path, "gpa_autorisation.zip")
    except module.ManagementError as exc:
        assert "sans l’extension .zip" in str(exc)
    else:
        raise AssertionError("extension .zip acceptée dans l’identifiant")


def test_single_legacy_named_zip_uses_manifest_debate_id(tmp_path: Path):
    import zipfile

    incoming = tmp_path / "incoming"
    incoming.mkdir()
    archive = incoming / "education_sexualite_ecole_fr_en_release_ready_repaired_2026-07-31.zip"
    with zipfile.ZipFile(archive, "w") as bundle:
        bundle.writestr("manifest.json", json.dumps({"debate_id": "education_sexualite_ecole"}))
        bundle.writestr("payload.txt", "contenu")

    assert module.find_debate_archive(tmp_path, None) == archive
    debate_id, target = module.install_debate_corpus(tmp_path, archive)
    assert debate_id == "education_sexualite_ecole"
    assert target == tmp_path / "corpus" / "education_sexualite_ecole"
    assert (target / "payload.txt").read_text(encoding="utf-8") == "contenu"


def test_explicit_archive_stem_may_differ_from_manifest_debate_id(tmp_path: Path):
    import zipfile

    incoming = tmp_path / "incoming"
    incoming.mkdir()
    selected = incoming / "ancienne_livraison_2026-07-31.zip"
    other = incoming / "autre_debat.zip"
    with zipfile.ZipFile(selected, "w") as bundle:
        bundle.writestr("manifest.json", json.dumps({"debate_id": "education_sexualite_ecole"}))
    other.write_bytes(b"non-selected")

    archive = module.find_debate_archive(tmp_path, "ancienne_livraison_2026-07-31")
    assert archive == selected
    debate_id, target = module.install_debate_corpus(tmp_path, archive)
    assert debate_id == "education_sexualite_ecole"
    assert target.name == "education_sexualite_ecole"


def test_legacy_incoming_debates_is_migrated_to_incoming(tmp_path: Path):
    legacy = tmp_path / "incoming" / "debates"
    legacy.mkdir(parents=True)
    archive = legacy / "gpa_autorisation.zip"
    archive.write_bytes(b"archive")
    backup = tmp_path / "archives" / "updates" / "test"
    backup.mkdir(parents=True)
    module.migrate_legacy_debate_inbox(tmp_path, backup)
    assert (tmp_path / "incoming" / "gpa_autorisation.zip").read_bytes() == b"archive"
    assert not legacy.exists()


def test_runtime_requirements_include_pywikibot_and_validator_dependencies():
    requirements = (SCRIPT.parents[1] / "root_template" / "requirements-runtime.txt").read_text(encoding="utf-8")
    for dependency in ("pywikibot", "jsonschema", "referencing", "pytest"):
        assert dependency in requirements


def test_launcher_bootstraps_virtual_environment_and_dependencies():
    launcher = (SCRIPT.parents[1] / "root_template" / "wikidebia").read_text(encoding="utf-8")
    assert '-m venv "$VENV"' in launcher
    assert '-m pip install' in launcher
    assert 'requirements-runtime.txt' in launcher
    assert 'pywikibot' in launcher
    assert 'runtime-requirements.sha256' in launcher


def test_runtime_report_detects_missing_environment(tmp_path: Path):
    (tmp_path / "requirements-runtime.txt").write_text("pywikibot\n", encoding="utf-8")
    report = module.runtime_environment_report(tmp_path)
    assert report["python_available"] is False
    assert "pywikibot" in report["missing_modules"]


def test_doctor_reports_missing_runtime_environment(tmp_path: Path):
    (tmp_path / "requirements-runtime.txt").write_text("pywikibot\n", encoding="utf-8")
    (tmp_path / "private" / "pywikibot").mkdir(parents=True)
    (tmp_path / "private" / "pywikibot" / "user-config.py").write_text("family='wikidebates'\n", encoding="utf-8")
    report = module.doctor(tmp_path)
    assert report["status"] == "failed"
    assert any(".venv/bin/python" in issue for issue in report["issues"])


def _init_git_repo(root: Path) -> None:
    module.run(["git", "init", "-b", "main"], cwd=root)
    module.run(["git", "config", "user.name", "Test"], cwd=root)
    module.run(["git", "config", "user.email", "test@example.invalid"], cwd=root)


def test_root_configs_is_ignored_but_kit_configs_is_trackable(tmp_path: Path):
    (tmp_path / ".gitignore").write_text((SCRIPT.parents[1] / "root_template" / ".gitignore").read_text(encoding="utf-8"), encoding="utf-8")
    _init_git_repo(tmp_path)
    ignored = module.run(["git", "check-ignore", "-q", "--no-index", "--", "configs/test.json"], cwd=tmp_path, check=False)
    allowed = module.run(["git", "check-ignore", "-q", "--no-index", "--", "kit/configs/example.json"], cwd=tmp_path, check=False)
    assert ignored.returncode == 0
    assert allowed.returncode != 0


def test_prepare_git_security_untracks_lwp_without_deleting_it(tmp_path: Path):
    (tmp_path / ".gitignore").write_text((SCRIPT.parents[1] / "root_template" / ".gitignore").read_text(encoding="utf-8"), encoding="utf-8")
    secret = tmp_path / "pywikibot-session.lwp"
    secret.write_text("cookie", encoding="utf-8")
    _init_git_repo(tmp_path)
    module.run(["git", "add", "-f", "pywikibot-session.lwp"], cwd=tmp_path)
    assert module.git_tracked_forbidden_paths(tmp_path) == ["pywikibot-session.lwp"]
    module.prepare_git_security(tmp_path)
    assert secret.is_file()
    assert module.git_tracked_forbidden_paths(tmp_path) == []


def test_git_security_detects_missing_required_ignore_rule(tmp_path: Path):
    (tmp_path / ".gitignore").write_text("/private/\n", encoding="utf-8")
    missing = module.gitignore_missing_rules(tmp_path)
    assert "*.lwp" in missing
    assert "/apicache/" in missing


def test_doctor_reports_tracked_sensitive_file(tmp_path: Path, monkeypatch):
    (tmp_path / ".gitignore").write_text((SCRIPT.parents[1] / "root_template" / ".gitignore").read_text(encoding="utf-8"), encoding="utf-8")
    (tmp_path / "private" / "pywikibot").mkdir(parents=True)
    (tmp_path / "private" / "pywikibot" / "user-config.py").write_text("family='wikidebates'\n", encoding="utf-8")
    secret = tmp_path / "session.lwp"
    secret.write_text("cookie", encoding="utf-8")
    _init_git_repo(tmp_path)
    module.run(["git", "add", "-f", "session.lwp"], cwd=tmp_path)
    monkeypatch.setattr(module, "runtime_environment_report", lambda root: {"requirements_sha256":"x", "python_available":True, "missing_modules":[]})
    report = module.doctor(tmp_path)
    assert report["status"] == "failed"
    assert any("session.lwp" in issue for issue in report["issues"])


def test_runtime_requirements_bound_pywikibot_major_version():
    requirements = (SCRIPT.parents[1] / "root_template" / "requirements-runtime.txt").read_text(encoding="utf-8")
    assert "pywikibot>=11.5,<12" in requirements


def test_parser_exposes_github_sync_command():
    parser = module.build_parser()
    args = parser.parse_args(["github-sync"])
    assert args.command == "github-sync"


def test_git_push_disables_terminal_password_prompt(monkeypatch, tmp_path: Path):
    _init_git_repo(tmp_path)
    module.run(["git", "remote", "add", "origin", "https://github.com/example/example.git"], cwd=tmp_path)
    calls = []
    original = module.run
    def fake_run(command, **kwargs):
        calls.append((command, kwargs))
        if command[:2] == ["git", "push"]:
            import subprocess
            return subprocess.CompletedProcess(command, 1, stdout="", stderr="auth failed")
        return original(command, **kwargs)
    monkeypatch.setattr(module, "run", fake_run)
    assert module.git_push_current_branch(tmp_path, strict=False) is False
    push = next(item for item in calls if item[0][:2] == ["git", "push"])[1]
    assert push["env"]["GIT_TERMINAL_PROMPT"] == "0"


def test_forbidden_git_paths_keep_leading_dot_semantics():
    assert module.forbidden_git_path(".gitconfig-wikidebia")
    assert module.forbidden_git_path(".state/runtime.json")
    assert module.forbidden_git_path("kit/configs/example.json") is False


def test_github_sync_commits_pending_safe_changes_before_push(tmp_path: Path, monkeypatch):
    (tmp_path / ".gitignore").write_text((SCRIPT.parents[1] / "root_template" / ".gitignore").read_text(encoding="utf-8"), encoding="utf-8")
    _init_git_repo(tmp_path)
    (tmp_path / "safe.txt").write_text("contenu\n", encoding="utf-8")
    pushed = []
    monkeypatch.setattr(module, "git_push_current_branch", lambda root, strict: pushed.append((root, strict)) or True)
    module.github_sync(tmp_path)
    assert module.run(["git", "status", "--porcelain"], cwd=tmp_path, capture=True).stdout.strip() == ""
    assert module.run(["git", "log", "-1", "--pretty=%s"], cwd=tmp_path, capture=True).stdout.strip() == "Synchronisation sécurisée Wikidéb’IA"
    assert pushed == [(tmp_path, True)]


def test_publish_command_has_no_interactive_prompt(monkeypatch, tmp_path: Path):
    def forbidden_input(*args, **kwargs):
        raise AssertionError("input() ne doit jamais être appelé par publish")
    monkeypatch.setattr("builtins.input", forbidden_input)
    monkeypatch.setattr(module, "ensure_credentials", lambda root: None)
    archive = tmp_path / "incoming" / "demo.zip"
    archive.parent.mkdir(parents=True)
    archive.write_bytes(b"zip")
    monkeypatch.setattr(module, "find_debate_archive", lambda root, identifier: archive)
    corpus = tmp_path / "corpus" / "demo"
    corpus.mkdir(parents=True)
    monkeypatch.setattr(module, "install_debate_corpus", lambda root, selected: ("demo", corpus))
    monkeypatch.setattr(module, "publication_config", lambda root, debate_id, scope, run_dir: run_dir / "config.json")
    plan = {"blockers": [], "counts": {}, "actions": [], "plan_sha256": "a" * 64}
    def fake_run(command, *, cwd, capture=False, check=True, env=None):
        class Result:
            stdout = '{"created":0,"updated":0,"skipped":0}\n'
            returncode = 0
        if "--mode" in command and command[command.index("--mode") + 1] == "plan":
            output = Path(cwd) / command[command.index("--plan-output") + 1]
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(json.dumps(plan), encoding="utf-8")
        return Result()
    monkeypatch.setattr(module, "run", fake_run)
    result = module.publish_debate(tmp_path, None, "all", False, True)
    assert result == {"created": 0, "updated": 0, "skipped": 0}
```

# Source incorporée : `tests/test_wikidebia_publish.py`

**SHA-256 :** `35cbd1cd3d2ac90ce98da455f85193976f67071ae222b470923bebf81badb180`

```py
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "wikidebia_publish.py"
spec = importlib.util.spec_from_file_location("wikidebia_publish", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
sys.modules[spec.name] = module
spec.loader.exec_module(module)


class FakeAdapter:
    def __init__(self, pages=None):
        self.pages = dict(pages or {})
        self.revisions = {}
        self.next_revision = 100
        self.language = None

    def open_language(self, language, expected_user): self.language = language
    def close_language(self): self.language = None
    def assert_identity(self, expected_user): return None
    def available_change_tags(self): return {"chatgpt"}
    def read_page(self, title):
        row = self.pages.get((self.language, title))
        return (False, None, "") if row is None else (True, row[0], row[1])
    def read_revision(self, title, revision_id): return self.revisions.get(revision_id)
    def write_page(self, *, title, text, summary, tags, expected_user, create_only, base_revision_id):
        key = (self.language, title)
        if create_only and key in self.pages: raise RuntimeError("create collision")
        if not create_only and (key not in self.pages or self.pages[key][0] != base_revision_id): raise RuntimeError("revision collision")
        self.next_revision += 1
        revision = self.next_revision
        self.pages[key] = (revision, text)
        self.revisions[revision] = {"revision_id": revision, "text": text, "summary": summary, "tags": tags}
        return revision


def write_fixture(tmp_path: Path, kind: str):
    corpus = tmp_path / "corpus" / "demo"
    (corpus / "output" / "fr").mkdir(parents=True)
    (corpus / "output" / "en").mkdir(parents=True)
    (corpus / "data").mkdir(parents=True)
    fr = "{{Argument\n|résumé=Nouveau résumé.\n|rubriques=Société\n}}\n"
    en = "{{Argument\n|summary=New summary.\n|sections=Society\n}}\n"
    (corpus / "output" / "fr" / "A1.wiki").write_text(fr, encoding="utf-8")
    (corpus / "output" / "en" / "A1.wiki").write_text(en, encoding="utf-8")
    fr_debate = "{{Débat\n|sujet=Démo\n|sujet-complet=la démonstration\n}}\n"
    en_debate = "{{Debate\n|topic=Demo\n|complete-topic=the demonstration\n}}\n"
    (corpus / "output" / "fr" / "debate.wiki").write_text(fr_debate, encoding="utf-8")
    (corpus / "output" / "en" / "debate.wiki").write_text(en_debate, encoding="utf-8")
    manifest = {
      "debate_id":"demo",
      "normative_versions":{"validator":"0.4.19"},
      "core_files":{"registry":"data/registre_debat.json"},
      "pages":[
        {"language":"fr","page_id":"A1","page_type":"argument","canonical_title":"Titre FR","file_path":"output/fr/A1.wiki","sha256":module.sha_file(corpus / "output/fr/A1.wiki")},
        {"language":"en","page_id":"A1","page_type":"argument","canonical_title":"Title EN","file_path":"output/en/A1.wiki","sha256":module.sha_file(corpus / "output/en/A1.wiki")},
        {"language":"fr","page_id":"DEBATE","page_type":"debate","canonical_title":"Débat démo","file_path":"output/fr/debate.wiki","sha256":module.sha_file(corpus / "output/fr/debate.wiki")},
        {"language":"en","page_id":"DEBATE","page_type":"debate","canonical_title":"Demo debate","file_path":"output/en/debate.wiki","sha256":module.sha_file(corpus / "output/en/debate.wiki")}
      ]
    }
    registry = {
      "debate": {"id": "demo", "pages": {"en": {"canonical_title": "Demo debate", "title_status": "locked"}}},
      "graph": {"nodes": [{"id": "A1", "en": {"canonical_title": "Title EN", "title_status": "locked"}}]}
    }
    (corpus / "data" / "registre_debat.json").write_text(json.dumps(registry), encoding="utf-8")
    (corpus / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    validator = tmp_path / "validator"
    validator.mkdir()
    validator_script = validator / "validate.py"
    validator_script.write_text("import json; print(json.dumps({'validator_version':'0.4.19','result':'passed','summary':{'errors':0,'warnings':0}}))", encoding="utf-8")
    operation = {
      "id":"test",
      "kind":kind,
      "languages":["fr","en"],
      "page_types":["argument"],
      "source_path_field":"file_path",
      "create_missing": kind == "full_page",
      "update_existing": kind == "parameter_update",
      "edit_summaries":{"fr":"Résumé FR","en":"Summary EN"}
    }
    if kind == "parameter_update": operation["parameters"]={"fr":"résumé","en":"summary"}
    config = {
      "kit_version":"2.2.2","publication_profile":"legacy","project_root":str(tmp_path),"debate_id":"demo","corpus_root":"corpus/demo",
      "validator":{"command":[sys.executable,str(validator_script),"validate"],"required_version":"0.4.19","scopes":[],"max_warnings":0,"fingerprint_path":"validator"},
      "family":"wikidebates","family_file":str(Path(__file__)),"pywikibot_dir":str(tmp_path),
      "sites":{"fr":{"code":"fr","expected_user":"ChatGPT"},"en":{"code":"en","expected_user":"ChatGPT"}},
      "logs_dir":"logs","change_tags":["chatgpt"],"verification_attempts":1,"verification_delay_seconds":0,"write_delay_seconds":0,
      "manifest_requirements":{},"operation":operation
    }
    config_path = tmp_path / "config.json"
    config_path.write_text(json.dumps(config), encoding="utf-8")
    return config, config_path, fr, en


def test_extract_and_replace_parameter():
    text = "{{Argument\r\n|summary=Old\r\n|sections=Society\r\n}}\r\n"
    assert module.extract_parameter(text, "summary") == "Old"
    assert module.replace_parameter(text, "summary", "New") == "{{Argument\r\n|summary=New\r\n|sections=Society\r\n}}\r\n"


def test_full_page_creation_is_dynamic(tmp_path):
    config, path, fr, en = write_fixture(tmp_path, "full_page")
    adapter = FakeAdapter()
    publisher = module.GenericPublisher(config, adapter, path)
    plan = publisher.build_plan()
    assert plan["counts"]["fr"]["create"] == 1
    assert plan["counts"]["en"]["create"] == 1
    result = publisher.publish(plan=plan, confirmation=plan["plan_sha256"])
    assert result == {"created":2,"updated":0,"skipped":0}
    assert adapter.pages[("fr","Titre FR")][1] == fr
    assert adapter.pages[("en","Title EN")][1] == en


def test_parameter_update_preserves_other_content(tmp_path):
    config, path, fr, en = write_fixture(tmp_path, "parameter_update")
    old_fr = "{{Argument\n|résumé=Ancien.\n|rubriques=Société\n}}\n"
    old_en = "{{Argument\n|summary=Old.\n|sections=Society\n}}\n"
    adapter = FakeAdapter({("fr","Titre FR"):(10,old_fr),("en","Title EN"):(20,old_en)})
    publisher = module.GenericPublisher(config, adapter, path)
    plan = publisher.build_plan()
    assert plan["counts"]["fr"]["update"] == 1
    result = publisher.publish(plan=plan, confirmation=plan["plan_sha256"])
    assert result["updated"] == 2
    assert "|résumé=Nouveau résumé." in adapter.pages[("fr","Titre FR")][1]
    assert "|rubriques=Société" in adapter.pages[("fr","Titre FR")][1]
    assert "|summary=New summary." in adapter.pages[("en","Title EN")][1]


def test_existing_full_page_collision_blocks(tmp_path):
    config, path, fr, en = write_fixture(tmp_path, "full_page")
    adapter = FakeAdapter({("fr","Titre FR"):(1,"différent"),("en","Title EN"):(2,en)})
    publisher = module.GenericPublisher(config, adapter, path)
    plan = publisher.build_plan()
    assert plan["counts"]["fr"]["block"] == 1
    assert plan["blockers"]


def test_parameter_update_can_insert_missing_parameter(tmp_path):
    config, path, fr, en = write_fixture(tmp_path, "parameter_update")
    config["operation"]["languages"] = ["fr"]
    config["operation"]["parameters"] = {"fr": "interlangue"}
    config["operation"]["insert_missing_parameter"] = True

    corpus = tmp_path / "corpus" / "demo"
    local = "{{Argument\n|résumé=Nouveau résumé.\n|rubriques=Société\n|interlangue=English title\n}}\n"
    source = corpus / "output" / "fr" / "A1.wiki"
    source.write_text(local, encoding="utf-8")

    manifest_path = corpus / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["pages"] = [row for row in manifest["pages"] if row["language"] == "fr"]
    manifest["pages"][0]["sha256"] = module.sha_file(source)
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")

    path.write_text(json.dumps(config), encoding="utf-8")
    old_fr = "{{Argument\n|résumé=Ancien.\n|rubriques=Société\n}}\n"
    adapter = FakeAdapter({("fr", "Titre FR"): (10, old_fr)})
    publisher = module.GenericPublisher(config, adapter, path)
    plan = publisher.build_plan()

    assert plan["counts"]["fr"]["update"] == 1
    assert not plan["blockers"]

    result = publisher.publish(
        plan=plan,
        confirmation=plan["plan_sha256"],
        language="fr",
    )
    assert result["updated"] == 1
    written = adapter.pages[("fr", "Titre FR")][1]
    assert "|interlangue=English title" in written
    assert "|résumé=Ancien." in written
    assert "|rubriques=Société" in written



def make_direct_profile(config, path, tmp_path):
    config["publication_profile"] = module.DIRECT_INTERLANGUAGE_PROFILE
    config["validator"]["scopes"] = sorted(module.REQUIRED_DIRECT_SCOPES)
    config["operation"]["page_types"] = []
    corpus = tmp_path / "corpus" / "demo"
    manifest_path = corpus / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["consolidated_norm"] = "1.2.18"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    fr_debate = corpus / "output" / "fr" / "debate.wiki"
    fr_debate.write_text(
        "{{Débat\n|sujet=Démo\n|sujet-complet=la démonstration\n|articles-Wikipédia={{Article Wikipédia\n|page=Démonstration\n}}\n|interlangue={{Lien interlangue\n|langue=en\n|page=Demo debate\n}}\n}}\n",
        encoding="utf-8",
    )
    en_debate = corpus / "output" / "en" / "debate.wiki"
    en_debate.write_text(
        "{{Debate\n|topic=Demo\n|complete-topic=the demonstration\n|wikipedia-articles={{Wikipedia article\n|page=Demonstration\n}}\n}}\n",
        encoding="utf-8",
    )
    update_hash(manifest_path, "fr", "DEBATE", fr_debate)
    update_hash(manifest_path, "en", "DEBATE", en_debate)
    path.write_text(json.dumps(config), encoding="utf-8")
    return corpus, manifest_path


def update_hash(manifest_path, language, page_id, source):
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    for row in manifest["pages"]:
        if row["language"] == language and row["page_id"] == page_id:
            row["sha256"] = module.sha_file(source)
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")


def test_direct_profile_accepts_locked_future_english_target(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    fr_path = corpus / "output" / "fr" / "A1.wiki"
    fr_path.write_text("{{Argument\n|résumé=Texte.\n|interlangue={{Lien interlangue\n|langue=en\n|page=Title EN\n}}\n|rubriques=Société\n}}\n", encoding="utf-8")
    update_hash(manifest_path, "fr", "A1", fr_path)
    publisher = module.GenericPublisher(config, FakeAdapter(), path)
    plan = publisher.build_plan()
    assert plan["publication_profile"] == module.DIRECT_INTERLANGUAGE_PROFILE
    assert plan["counts"]["fr"]["create"] == 2


def test_direct_profile_rejects_debate_interlangue_model(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    fr_path = corpus / "output" / "fr" / "A1.wiki"
    fr_path.write_text("{{Argument\n|résumé=Texte.\n|interlangue={{Interlangue\n|langue=en\n|page=Title EN\n}}\n|rubriques=Société\n}}\n", encoding="utf-8")
    update_hash(manifest_path, "fr", "A1", fr_path)
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "Lien interlangue" in str(exc)
    else:
        raise AssertionError("ancienne forme interlangue acceptée")


def test_direct_profile_rejects_references_tag(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    fr_path = corpus / "output" / "fr" / "A1.wiki"
    fr_path.write_text("{{Argument\n|résumé=Texte.<references />\n|interlangue={{Lien interlangue\n|langue=en\n|page=Title EN\n}}\n|rubriques=Société\n}}\n", encoding="utf-8")
    update_hash(manifest_path, "fr", "A1", fr_path)
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "references" in str(exc)
    else:
        raise AssertionError("balise references acceptée")


def test_direct_profile_rejects_old_english_debate_shape(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    fr_source = corpus / "output" / "fr" / "A1.wiki"
    fr_source.write_text("{{Argument\n|résumé=Texte.\n|interlangue={{Lien interlangue\n|langue=en\n|page=Title EN\n}}\n|rubriques=Société\n}}\n", encoding="utf-8")
    update_hash(manifest_path, "fr", "A1", fr_source)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    en = next(row for row in manifest["pages"] if row["language"] == "en" and row["page_type"] == "debate")
    source = corpus / "output" / "en" / "debate.wiki"
    source.write_text("{{Debate\n|type=Is\n|topic=should measure X be adopted?\n}}\n", encoding="utf-8")
    en["sha256"] = module.sha_file(source)
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "|type=" in str(exc)
    else:
        raise AssertionError("ancienne structure Debate acceptée")


def test_direct_profile_forbids_interlanguage_parameter_update(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "parameter_update")
    config["publication_profile"] = module.DIRECT_INTERLANGUAGE_PROFILE
    config["validator"]["scopes"] = sorted(module.REQUIRED_DIRECT_SCOPES)
    config["operation"]["parameters"] = {"fr":"interlangue","en":"summary"}
    path.write_text(json.dumps(config), encoding="utf-8")
    try:
        module.GenericPublisher(config, FakeAdapter(), path)
    except module.PublicationError as exc:
        assert "interlangue" in str(exc)
    else:
        raise AssertionError("mise à jour interlangue séparée acceptée")


def test_direct_profile_rejects_parenthetical_em_dashes_in_french_summary(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    fr_path = corpus / "output" / "fr" / "A1.wiki"
    fr_path.write_text("{{Argument\n|résumé=Texte — précision incidente — suite.\n|interlangue={{Lien interlangue\n|langue=en\n|page=Title EN\n}}\n|rubriques=Société\n}}\n", encoding="utf-8")
    update_hash(manifest_path, "fr", "A1", fr_path)
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "parenthèses" in str(exc)
    else:
        raise AssertionError("tirets cadratins parenthétiques acceptés")


def test_direct_profile_allows_french_only_manifest_with_locked_registry_titles(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    config["operation"]["languages"] = ["fr"]
    config["operation"]["page_types"] = ["argument"]
    config["operation"]["language_order"] = ["fr"]
    config["operation"]["edit_summaries"] = {"fr": "Résumé FR"}
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["pages"] = [row for row in manifest["pages"] if row["language"] == "fr"]
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    fr_path = corpus / "output" / "fr" / "A1.wiki"
    fr_path.write_text(
        "{{Argument\n|résumé=Texte.\n|interlangue={{Lien interlangue\n|langue=en\n|page=Title EN\n}}\n|rubriques=Société\n}}\n",
        encoding="utf-8",
    )
    update_hash(manifest_path, "fr", "A1", fr_path)
    path.write_text(json.dumps(config), encoding="utf-8")
    adapter = FakeAdapter()
    publisher = module.GenericPublisher(config, adapter, path)
    plan = publisher.build_plan()
    assert plan["counts"]["fr"]["create"] == 1
    assert not plan["blockers"]
    result = publisher.publish(plan=plan, confirmation=plan["plan_sha256"])
    assert result == {"created": 1, "updated": 0, "skipped": 0}
    assert ("fr", "Titre FR") in adapter.pages


def test_direct_profile_rejects_unlocked_registry_title_without_english_manifest(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    config["operation"]["languages"] = ["fr"]
    config["operation"]["page_types"] = ["argument"]
    config["operation"]["language_order"] = ["fr"]
    config["operation"]["edit_summaries"] = {"fr": "Résumé FR"}
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["pages"] = [row for row in manifest["pages"] if row["language"] == "fr"]
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    registry_path = corpus / "data" / "registre_debat.json"
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    registry["graph"]["nodes"][0]["en"]["title_status"] = "draft"
    registry_path.write_text(json.dumps(registry), encoding="utf-8")
    fr_path = corpus / "output" / "fr" / "A1.wiki"
    fr_path.write_text(
        "{{Argument\n|résumé=Texte.\n|interlangue={{Lien interlangue\n|langue=en\n|page=Title EN\n}}\n|rubriques=Société\n}}\n",
        encoding="utf-8",
    )
    update_hash(manifest_path, "fr", "A1", fr_path)
    path.write_text(json.dumps(config), encoding="utf-8")
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "non verrouillé" in str(exc)
    else:
        raise AssertionError("titre anglais non verrouillé accepté")


def _prepare_direct_plan(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    fr_path = corpus / "output" / "fr" / "A1.wiki"
    fr_path.write_text(
        "{{Argument\n|résumé=Texte.\n|interlangue={{Lien interlangue\n|langue=en\n|page=Title EN\n}}\n|rubriques=Société\n}}\n",
        encoding="utf-8",
    )
    update_hash(manifest_path, "fr", "A1", fr_path)
    adapter = FakeAdapter()
    publisher = module.GenericPublisher(config, adapter, path)
    return publisher, adapter, publisher.build_plan()


def test_direct_profile_publish_requires_debate_test_receipt(tmp_path):
    publisher, _, plan = _prepare_direct_plan(tmp_path)
    try:
        publisher.publish(plan=plan, confirmation=plan["plan_sha256"])
    except module.PublicationError as exc:
        assert "debate-test-receipt" in str(exc)
    else:
        raise AssertionError("publication directe acceptée sans reçu de test")


def test_canonical_debate_test_receipt_is_created_and_reverified(tmp_path):
    publisher, adapter, plan = _prepare_direct_plan(tmp_path)
    receipt = publisher.create_debate_test_receipt(
        plan=plan,
        confirmation=plan["plan_sha256"],
    )
    assert receipt["status"] == "passed"
    assert receipt["plan_sha256"] == plan["plan_sha256"]
    assert receipt["canonical_title"] == "Débat démo"
    assert receipt["page_type"] == "debate"
    result = publisher.publish(
        plan=plan,
        confirmation=plan["plan_sha256"],
        debate_test_receipt=receipt,
    )
    assert result == {"created": 3, "updated": 0, "skipped": 1}
    assert ("fr", "Débat démo") in adapter.pages
    assert not any("Utilisateur:" in title for _, title in adapter.pages)


def test_tampered_debate_test_receipt_is_rejected(tmp_path):
    publisher, _, plan = _prepare_direct_plan(tmp_path)
    receipt = publisher.create_debate_test_receipt(
        plan=plan,
        confirmation=plan["plan_sha256"],
    )
    receipt["page_id"] = "A9999"
    try:
        publisher.publish(
            plan=plan,
            confirmation=plan["plan_sha256"],
            debate_test_receipt=receipt,
        )
    except module.PublicationError as exc:
        assert "Empreinte" in str(exc)
    else:
        raise AssertionError("reçu altéré accepté")


def test_changed_remote_debate_test_revision_is_rejected(tmp_path):
    publisher, adapter, plan = _prepare_direct_plan(tmp_path)
    receipt = publisher.create_debate_test_receipt(
        plan=plan,
        confirmation=plan["plan_sha256"],
    )
    adapter.pages[("fr", receipt["canonical_title"])] = (999, "contenu modifié")
    try:
        publisher.publish(
            plan=plan,
            confirmation=plan["plan_sha256"],
            debate_test_receipt=receipt,
        )
    except module.RevisionConflict as exc:
        assert "page Débat" in str(exc)
    else:
        raise AssertionError("révision de test distante modifiée acceptée")


def test_debate_test_refuses_existing_canonical_debate(tmp_path):
    publisher, adapter, plan = _prepare_direct_plan(tmp_path)
    adapter.pages[("fr", "Débat démo")] = (42, "autre contenu")
    try:
        publisher.create_debate_test_receipt(
            plan=plan,
            confirmation=plan["plan_sha256"],
        )
    except module.CollisionError as exc:
        assert "existe déjà" in str(exc)
    else:
        raise AssertionError("page Débat canonique existante acceptée comme test")


def test_direct_plan_allows_argument_only_selection(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    config["operation"]["languages"] = ["fr"]
    config["operation"]["page_types"] = ["argument"]
    config["operation"]["language_order"] = ["fr"]
    config["operation"]["edit_summaries"] = {"fr": "Résumé FR"}
    fr_path = corpus / "output" / "fr" / "A1.wiki"
    fr_path.write_text(
        "{{Argument\n|résumé=Texte.\n|interlangue={{Lien interlangue\n|langue=en\n|page=Title EN\n}}\n|rubriques=Société\n}}\n",
        encoding="utf-8",
    )
    update_hash(manifest_path, "fr", "A1", fr_path)
    path.write_text(json.dumps(config), encoding="utf-8")
    plan = module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    assert plan["counts"]["fr"]["create"] == 1
    assert all(action["page_type"] == "argument" for action in plan["actions"])


def test_rehashed_receipt_with_wrong_summary_is_rejected(tmp_path):
    publisher, _, plan = _prepare_direct_plan(tmp_path)
    receipt = publisher.create_debate_test_receipt(
        plan=plan,
        confirmation=plan["plan_sha256"],
    )
    receipt["summary"] = "Résumé falsifié"
    unsigned = dict(receipt)
    unsigned.pop("receipt_sha256")
    receipt["receipt_sha256"] = module.sha_object(unsigned)
    try:
        publisher.publish(
            plan=plan,
            confirmation=plan["plan_sha256"],
            debate_test_receipt=receipt,
        )
    except module.PublicationError as exc:
        assert "summary" in str(exc)
    else:
        raise AssertionError("reçu recalculé avec un mauvais résumé accepté")


def test_active_cli_has_no_user_test_mode():
    source = SCRIPT.read_text(encoding="utf-8")
    assert '"user-test"' not in source
    assert "--user-test" not in source
    assert '"debate-test"' in source
    assert "--debate-test-receipt" in source


def test_generic_kit_contains_no_debate_specific_configs():
    root = SCRIPT.parents[1]
    assert not (root / "configs" / "legacy").exists()
    active_files = [
        root / "README.md",
        root / "GUIDE_PUBLICATION.md",
        root / "config.example.json",
        root / "configs" / "creation_bilingue_1.2.18.example.json",
        root / "scripts" / "wikidebia_publish.py",
    ]
    combined = "\n".join(path.read_text(encoding="utf-8").casefold() for path in active_files)
    for token in (
        "parapsychologie_science",
        "reseaux_sociaux_adolescents",
        "transparent psi",
        "réseaux sociaux aux adolescents",
    ):
        assert token not in combined


def test_direct_profile_requires_editorial_scope_for_introduction_review(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    make_direct_profile(config, path, tmp_path)
    config["validator"]["scopes"] = [scope for scope in config["validator"]["scopes"] if scope != "editorial"]
    try:
        module.GenericPublisher(config, FakeAdapter(), path)
    except module.PublicationError as exc:
        assert "editorial" in str(exc)
    else:
        raise AssertionError("profil direct accepté sans portée editorial")


def _write_valid_direct_argument(corpus: Path, manifest_path: Path) -> None:
    source = corpus / "output" / "fr" / "A1.wiki"
    source.write_text(
        "{{Argument\n|résumé=Texte.\n|interlangue={{Lien interlangue\n|langue=en\n|page=Title EN\n}}\n|rubriques=Société\n}}\n",
        encoding="utf-8",
    )
    update_hash(manifest_path, "fr", "A1", source)


def test_direct_profile_rejects_unsorted_sections(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    _write_valid_direct_argument(corpus, manifest_path)
    source = corpus / "output" / "en" / "A1.wiki"
    source.write_text(
        "{{Argument\n|summary=Text.\n|sections=Science, Philosophy\n}}\n",
        encoding="utf-8",
    )
    update_hash(manifest_path, "en", "A1", source)
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "ordre alphabétique" in str(exc)
    else:
        raise AssertionError("sections non alphabétiques acceptées")


def test_direct_profile_rejects_lowercase_topic(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    _write_valid_direct_argument(corpus, manifest_path)
    source = corpus / "output" / "en" / "debate.wiki"
    source.write_text(
        "{{Debate\n|topic=parapsychology\n|complete-topic=the scientific status of parapsychology\n|wikipedia-articles={{Wikipedia article\n|page=Parapsychology\n}}\n}}\n",
        encoding="utf-8",
    )
    update_hash(manifest_path, "en", "DEBATE", source)
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "commencer par une majuscule" in str(exc)
    else:
        raise AssertionError("topic en minuscule accepté")


def test_direct_profile_rejects_interrogative_complete_topic(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    _write_valid_direct_argument(corpus, manifest_path)
    source = corpus / "output" / "en" / "debate.wiki"
    source.write_text(
        "{{Debate\n|topic=Parapsychology\n|complete-topic=whether parapsychology meets the criteria for scientific status\n|wikipedia-articles={{Wikipedia article\n|page=Parapsychology\n}}\n}}\n",
        encoding="utf-8",
    )
    update_hash(manifest_path, "en", "DEBATE", source)
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "forme non interrogative" in str(exc)
    else:
        raise AssertionError("complete-topic interrogatif accepté")


def test_direct_profile_rejects_split_adjacent_templates(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    source = corpus / "output" / "fr" / "A1.wiki"
    source.write_text(
        "{{Argument\n|résumé=Texte.\n|références-bibliographiques={{Référence bibliographique\n"
        "|auteurs=A\n|ouvrage=O1\n|date=25 juin 2012\n}}\n{{Référence bibliographique\n"
        "|auteurs=B\n|ouvrage=O2\n|date=26 juin 2012\n}}\n"
        "|interlangue={{Lien interlangue\n|langue=en\n|page=Title EN\n}}\n|rubriques=Société\n}}\n",
        encoding="utf-8",
    )
    update_hash(manifest_path, "fr", "A1", source)
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "}}{{" in str(exc)
    else:
        raise AssertionError("jonction de modèles séparée par un saut de ligne acceptée")


def test_full_page_order_is_debate_then_arguments_in_both_languages(tmp_path):
    publisher, _, plan = _prepare_direct_plan(tmp_path)
    sequence = [(row["language"], row["page_type"]) for row in plan["actions"]]
    assert sequence == [
        ("fr", "debate"),
        ("fr", "argument"),
        ("en", "debate"),
        ("en", "argument"),
    ]


def test_equivalent_existing_french_debate_needs_no_test_receipt(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    _write_valid_direct_argument(corpus, manifest_path)
    fr_debate = (corpus / "output" / "fr" / "debate.wiki").read_text(encoding="utf-8")
    adapter = FakeAdapter({("fr", "Débat démo"): (42, fr_debate)})
    publisher = module.GenericPublisher(config, adapter, path)
    plan = publisher.build_plan()
    debate_action = next(row for row in plan["actions"] if row["language"] == "fr" and row["page_type"] == "debate")
    assert debate_action["operation"] == "skip"
    result = publisher.publish(plan=plan, confirmation=plan["plan_sha256"])
    assert result["skipped"] == 1
    assert result["created"] == 3


def test_historical_manifest_versions_do_not_block_current_validation(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus = tmp_path / "corpus" / "demo"
    manifest_path = corpus / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["normative_versions"] = {
        "consolidated_norm": "1.2.10",
        "validator": "0.4.10",
        "kit": "2.1.10",
    }
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    publisher = module.GenericPublisher(config, FakeAdapter(), path)
    plan = publisher.build_plan()
    assert not plan["blockers"]
    assert plan["required_validator_version"] == "0.4.19"


def test_explicit_custom_manifest_requirement_is_still_enforced(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    config["manifest_requirements"] = {"normative_versions.validator": "0.4.19"}
    path.write_text(json.dumps(config), encoding="utf-8")
    corpus = tmp_path / "corpus" / "demo"
    manifest_path = corpus / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["normative_versions"]["validator"] = "0.4.10"
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    try:
        module.GenericPublisher(config, FakeAdapter(), path)
    except module.PublicationError as exc:
        assert "Exigence de manifeste divergente" in str(exc)
    else:
        raise AssertionError("exigence explicite ignorée")


def test_direct_profile_rejects_empty_wikipedia_articles(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    fr_debate = corpus / "output" / "fr" / "debate.wiki"
    text = fr_debate.read_text(encoding="utf-8")
    text = text.replace("|articles-Wikipédia={{Article Wikipédia\n|page=Démonstration\n}}\n", "|articles-Wikipédia=\n")
    fr_debate.write_text(text, encoding="utf-8")
    update_hash(manifest_path, "fr", "DEBATE", fr_debate)
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "articles-Wikipédia" in str(exc)
    else:
        raise AssertionError("paramètre Wikipédia vide accepté")


def test_direct_profile_rejects_related_debates(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    _write_valid_direct_argument(corpus, manifest_path)
    fr_debate = corpus / "output" / "fr" / "debate.wiki"
    text = fr_debate.read_text(encoding="utf-8").replace("|interlangue=", "|débats-connexes={{Débat connexe\n|page=Autre débat\n}}\n|interlangue=")
    fr_debate.write_text(text, encoding="utf-8")
    update_hash(manifest_path, "fr", "DEBATE", fr_debate)
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "débats-connexes" in str(exc)
    else:
        raise AssertionError("débats connexes acceptés")


def test_direct_profile_rejects_json_author_array(tmp_path):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    _write_valid_direct_argument(corpus, manifest_path)
    fr_debate = corpus / "output" / "fr" / "debate.wiki"
    text = fr_debate.read_text(encoding="utf-8").replace("|interlangue=", "|sitographie-ni-pour-ni-contre={{Référence sitographique\n|lien=https://example.test\n|auteurs=[\"L'Encyclopédie philosophique\"]\n|site=L'Encyclopédie philosophique\n}}\n|interlangue=")
    fr_debate.write_text(text, encoding="utf-8")
    update_hash(manifest_path, "fr", "DEBATE", fr_debate)
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "tableau JSON" in str(exc)
    else:
        raise AssertionError("tableau JSON auteurs accepté")


def _set_norm(manifest_path, norm):
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    data.setdefault("normative_versions", {})["consolidated_norm"] = norm
    manifest_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def _inject_author_value(tmp_path, value, norm="1.2.18"):
    config, path, _, _ = write_fixture(tmp_path, "full_page")
    corpus, manifest_path = make_direct_profile(config, path, tmp_path)
    _write_valid_direct_argument(corpus, manifest_path)
    _set_norm(manifest_path, norm)
    fr_debate = corpus / "output" / "fr" / "debate.wiki"
    text = fr_debate.read_text(encoding="utf-8").replace("|interlangue=", f"|sitographie-ni-pour-ni-contre={{{{Référence sitographique\n|lien=https://example.test\n|auteurs={value}\n|site=Exemple\n}}}}\n|interlangue=")
    fr_debate.write_text(text, encoding="utf-8")
    update_hash(manifest_path, "fr", "DEBATE", fr_debate)
    return config, path

def test_direct_profile_accepts_comma_author_separator(tmp_path):
    config, path = _inject_author_value(tmp_path, "Auteur A, Auteur B")
    module.GenericPublisher(config, FakeAdapter(), path).build_plan()

def test_direct_profile_rejects_semicolon_author_separator(tmp_path):
    config, path = _inject_author_value(tmp_path, "Auteur A ; Auteur B")
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "virgule" in str(exc)
    else:
        raise AssertionError("point-virgule accepté")

def test_direct_profile_rejects_bad_comma_spacing(tmp_path):
    config, path = _inject_author_value(tmp_path, "Auteur A,Auteur B")
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "virgule" in str(exc)
    else:
        raise AssertionError("virgule sans espace acceptée")

def test_direct_profile_rejects_fullwidth_comma(tmp_path):
    config, path = _inject_author_value(tmp_path, "Auteur A， Auteur B")
    try:
        module.GenericPublisher(config, FakeAdapter(), path).build_plan()
    except module.PublicationError as exc:
        assert "virgule" in str(exc)
    else:
        raise AssertionError("virgule pleine chasse acceptée")

def test_author_separator_rule_is_not_retroactive_to_1217(tmp_path):
    config, path = _inject_author_value(tmp_path, "Auteur A ; Auteur B", "1.2.17")
    module.GenericPublisher(config, FakeAdapter(), path).build_plan()
```

# Source incorporée : `tests/test_wikidebia_remote_update.py`

**SHA-256 :** `a564627832a4f5ac5280b009c241ad6d3775023ce05e5f581fd8aa66275df9d9`

```py
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "wikidebia_update.py"
spec = importlib.util.spec_from_file_location("wikidebia_update_test", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
sys.modules[spec.name] = module
spec.loader.exec_module(module)

MARKER = "|avertissements-argument=Argument généré par IA\n"


class FakeAdapter:
    def __init__(self, pages=None, rights=None):
        self.pages = dict(pages or {})
        self.rights = set(rights or {"edit", "createpage", "move", "delete", "browsearchive"})
        self.language = None
        self.next_revision = 100
        self.events = []
        self.fail_after_writes = None
        self.write_count = 0

    def open_language(self, language, expected_user):
        assert self.language is None
        self.language = language
        self.events.append(("open", language))

    def close_language(self):
        self.events.append(("close", self.language))
        self.language = None

    def assert_identity(self, expected_user):
        return None

    def user_rights(self):
        return set(self.rights)

    def read_page(self, title):
        row = self.pages.get((self.language, title))
        return (False, None, "") if row is None else (True, row[0], row[1])

    def write_page(self, *, title, text, summary, tags, expected_user, create_only, base_revision_id):
        if self.fail_after_writes is not None and self.write_count >= self.fail_after_writes:
            raise RuntimeError("interruption")
        key = (self.language, title)
        if create_only and key in self.pages:
            raise RuntimeError("create collision")
        if not create_only and (key not in self.pages or self.pages[key][0] != base_revision_id):
            raise RuntimeError("revision collision")
        self.next_revision += 1
        self.write_count += 1
        self.pages[key] = (self.next_revision, text)
        self.events.append(("write", self.language, title))
        return self.next_revision

    def move_page(self, *, old_title, new_title, reason, expected_user, leave_redirect):
        old = (self.language, old_title)
        new = (self.language, new_title)
        rev, text = self.pages.pop(old)
        self.next_revision += 1
        self.pages[new] = (self.next_revision, text)
        if leave_redirect:
            self.next_revision += 1
            self.pages[old] = (self.next_revision, module.redirect_text(self.language, new_title))
        self.events.append(("move", self.language, old_title, new_title))
        return self.next_revision

    def delete_page(self, *, title, reason, expected_user):
        self.pages.pop((self.language, title), None)
        self.events.append(("delete", self.language, title))

    def backlinks(self, title):
        return ["Page entrante"]


def argument(text: str) -> str:
    return "{{Argument\n" + MARKER + f"|résumé={text}\n|rubriques=Société\n}}\n"


def make_fixture(tmp_path: Path, *, languages=("fr",), old_pages=None, new_pages=None, migrations=None):
    root = tmp_path
    corpus = root / "corpus" / "demo"
    corpus.mkdir(parents=True)
    manifest_pages = []
    for language in languages:
        (corpus / "output" / language).mkdir(parents=True)
    for row in new_pages or []:
        language, page_id, title, text = row[:4]
        page_type = row[4] if len(row) > 4 else "argument"
        path = corpus / "output" / language / f"{page_id}.wiki"
        path.write_text(text, encoding="utf-8")
        manifest_pages.append({
            "language": language,
            "page_id": page_id,
            "page_type": page_type,
            "canonical_title": title,
            "file_path": path.relative_to(corpus).as_posix(),
            "sha256": module.sha_file(path),
        })
    manifest = {"debate_id": "demo", "release_version": "2026-07-31", "pages": manifest_pages}
    (corpus / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    if migrations:
        (corpus / "data").mkdir()
        (corpus / "data" / "remote_migrations.json").write_text(json.dumps({"version":"1.0","debate_id":"demo","entries":migrations}), encoding="utf-8")
    for language in languages:
        pages = []
        for row in old_pages or []:
            if row[0] != language:
                continue
            _, page_id, title, text = row[:4]
            page_type = row[4] if len(row) > 4 else "argument"
            revision = row[5] if len(row) > 5 else 10
            pages.append({"page_id": page_id, "page_type": page_type, "canonical_title": title, "content_sha256": module.sha_text(text), "revision_id": revision, "status":"published"})
        state = {"state_version":module.STATE_VERSION,"debate_id":"demo","language":language,"corpus_version":"old","publication_date":"2026-07-30T00:00:00Z","source_manifest_sha256":"0"*64,"plan_sha256":"1"*64,"pages":pages}
        state["state_sha256"] = module.sha_object(state)
        path = root / ".state" / "published" / "demo" / language / "latest.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(state), encoding="utf-8")
    validator = root / "validator.py"
    validator.write_text("import json; print(json.dumps({'validator_version':'0.4.19','result':'passed','summary':{'errors':0,'warnings':0}}))", encoding="utf-8")
    config = {
        "kit_version":"2.2.2","project_root":str(root),"debate_id":"demo","corpus_root":"corpus/demo","languages":list(languages),
        "family":"wikidebates","pywikibot_dir":"private/pywikibot","sites":{lang:{"code":lang,"expected_user":"ChatGPT"} for lang in languages},
        "validator":{"command":[sys.executable,str(validator),"validate"],"required_version":"0.4.19","scopes":[]},
        "published_state_dir":".state/published","receipts_dir":".state/receipts","logs_dir":"logs",
    }
    config_path = root / "config.json"
    config_path.write_text(json.dumps(config), encoding="utf-8")
    return config, config_path


def plan(tmp_path, *, remote_pages=None, rights=None, **fixture):
    config, path = make_fixture(tmp_path, **fixture)
    adapter = FakeAdapter(remote_pages, rights)
    planner = module.RemoteUpdatePlanner(config, adapter, path)
    return planner.build_plan(), config, path, adapter


def test_01_new_page_is_create(tmp_path):
    p, *_ = plan(tmp_path, old_pages=[], new_pages=[("fr","A1","Titre",argument("Nouveau"))])
    assert p["counts"]["create"] == 1


def test_02_unchanged_page_is_skip(tmp_path):
    text = argument("Même")
    p, *_ = plan(tmp_path, old_pages=[("fr","A1","Titre",text)], new_pages=[("fr","A1","Titre",text)], remote_pages={("fr","Titre"):(10,text)})
    assert p["counts"]["skip"] == 1


def test_03_published_page_changed_in_corpus_is_update(tmp_path):
    old, new = argument("Ancien"), argument("Nouveau")
    p, *_ = plan(tmp_path, old_pages=[("fr","A1","Titre",old)], new_pages=[("fr","A1","Titre",new)], remote_pages={("fr","Titre"):(10,old)})
    assert p["counts"]["update"] == 1


def test_04_human_modified_page_is_manual_review(tmp_path):
    old, human, new = argument("Ancien"), argument("Modification humaine"), argument("Nouveau")
    p, *_ = plan(tmp_path, old_pages=[("fr","A1","Titre",old)], new_pages=[("fr","A1","Titre",new)], remote_pages={("fr","Titre"):(11,human)})
    assert p["counts"]["manual_review"] == 1
    assert p["comparisons"]


def test_05_removed_argument_is_delete(tmp_path):
    old = argument("Ancien")
    p, *_ = plan(tmp_path, old_pages=[("fr","A1","Titre",old)], new_pages=[("fr","A2","Conservé",argument("Présent"))], remote_pages={("fr","Titre"):(10,old),("fr","Conservé"):(20,argument("Présent"))})
    assert p["counts"]["delete"] == 1


def test_06_already_deleted_is_idempotent_skip(tmp_path):
    p, *_ = plan(tmp_path, old_pages=[("fr","A1","Titre",argument("Ancien"))], new_pages=[("fr","A2","Conservé",argument("Présent"))], remote_pages={("fr","Conservé"):(20,argument("Présent"))})
    assert any(row["page_id"] == "A1" for row in p["operations"]["skip"])


def test_07_renamed_argument_is_move(tmp_path):
    old, new = argument("Ancien"), argument("Nouveau")
    p, *_ = plan(tmp_path, old_pages=[("fr","A1","Ancien titre",old)], new_pages=[("fr","A1","Nouveau titre",new)], remote_pages={("fr","Ancien titre"):(10,old)})
    assert p["counts"]["move"] == 1


def test_08_merged_argument_can_redirect(tmp_path):
    old, target = argument("Fusionné"), argument("Cible")
    migrations=[{"language":"fr","old_page_id":"A1","kind":"merge","target_page_id":"A2","policy":"redirect"}]
    p, *_ = plan(tmp_path, old_pages=[("fr","A1","Ancien",old),("fr","A2","Cible",target)], new_pages=[("fr","A2","Cible",target)], migrations=migrations, remote_pages={("fr","Ancien"):(10,old),("fr","Cible"):(20,target)})
    assert p["counts"]["redirect"] == 1
    assert p["operations"]["redirect"][0]["backlinks"] == ["Page entrante"]


def test_09_never_published_page_is_not_deleted(tmp_path):
    p, *_ = plan(tmp_path, old_pages=[], new_pages=[("fr","A2","Conservé",argument("Présent"))], remote_pages={("fr","Étrangère"):(9,argument("Autre"))})
    assert p["counts"]["delete"] == 0


def test_10_page_owned_by_other_debate_is_blocked(tmp_path):
    old = argument("Ancien")
    p, config, path, adapter = plan(tmp_path, old_pages=[("fr","A1","Partagé",old)], new_pages=[("fr","A2","Conservé",argument("Présent"))], remote_pages={("fr","Partagé"):(10,old),("fr","Conservé"):(20,argument("Présent"))})
    other = {"state_version":module.STATE_VERSION,"debate_id":"autre","language":"fr","corpus_version":"x","publication_date":"x","source_manifest_sha256":"0"*64,"plan_sha256":"1"*64,"pages":[{"page_id":"Z","page_type":"argument","canonical_title":"Partagé","content_sha256":module.sha_text(old),"revision_id":10,"status":"published"}]}
    other["state_sha256"] = module.sha_object(other)
    op = tmp_path / ".state/published/autre/fr/latest.json"; op.parent.mkdir(parents=True); op.write_text(json.dumps(other),encoding="utf-8")
    p = module.RemoteUpdatePlanner(config, adapter, path).build_plan()
    assert p["counts"]["blocked"] == 1


def test_11_missing_delete_right_stops_before_write(tmp_path):
    old, kept = argument("Ancien"), argument("Présent")
    p, config, path, adapter = plan(tmp_path, rights={"edit","createpage"}, old_pages=[("fr","A1","Retiré",old),("fr","A2","Conservé",kept)], new_pages=[("fr","A2","Conservé",kept)], remote_pages={("fr","Retiré"):(10,old),("fr","Conservé"):(20,kept)})
    executor = module.PlanExecutor(config, adapter, path)
    try:
        executor.execute(p, p["plan_sha256"], only_delete=True)
    except module.PermissionDenied:
        pass
    else:
        raise AssertionError("delete sans droit accepté")
    assert not any(event[0] in {"write","delete","move"} for event in adapter.events)


def test_12_french_then_english_sessions_are_sequential(tmp_path):
    old_fr, old_en = argument("FR"), argument("EN")
    p, _, _, adapter = plan(tmp_path, languages=("fr","en"), old_pages=[("fr","A1","FR",old_fr),("en","A1","EN",old_en)], new_pages=[("fr","A1","FR",old_fr),("en","A1","EN",old_en)], remote_pages={("fr","FR"):(10,old_fr),("en","EN"):(11,old_en)})
    assert adapter.events[:4] == [("open","fr"),("close","fr"),("open","en"),("close","en")]


def test_13_interruption_then_resume_is_idempotent(tmp_path):
    one, two = argument("Un"), argument("Deux")
    p, config, path, adapter = plan(tmp_path, old_pages=[], new_pages=[("fr","A1","Un",one),("fr","A2","Deux",two)])
    executor = module.PlanExecutor(config, adapter, path)
    adapter.fail_after_writes = 1
    try:
        executor.execute(p, p["plan_sha256"])
    except RuntimeError:
        pass
    adapter.fail_after_writes = None
    receipt = executor.execute(p, p["plan_sha256"])
    assert receipt["counts"]["already_done"] == 1
    assert receipt["counts"]["created"] == 1


def test_14_remote_change_after_plan_is_conflict(tmp_path):
    old, new = argument("Ancien"), argument("Nouveau")
    p, config, path, adapter = plan(tmp_path, old_pages=[("fr","A1","Titre",old)], new_pages=[("fr","A1","Titre",new)], remote_pages={("fr","Titre"):(10,old)})
    adapter.pages[("fr","Titre")] = (11,argument("Changé après plan"))
    try:
        module.PlanExecutor(config, adapter, path).execute(p, p["plan_sha256"])
    except module.PlanConflict:
        pass
    else:
        raise AssertionError("conflit distant non détecté")


def test_15_only_delete_after_new_pages_already_published(tmp_path):
    retired, kept = argument("Retiré"), argument("Conservé")
    p, config, path, adapter = plan(tmp_path, old_pages=[("fr","A1","Retiré",retired),("fr","A2","Conservé",kept)], new_pages=[("fr","A2","Conservé",kept)], remote_pages={("fr","Retiré"):(10,retired),("fr","Conservé"):(20,kept)})
    receipt = module.PlanExecutor(config, adapter, path).execute(p, p["plan_sha256"], only_delete=True)
    assert receipt["counts"]["deleted"] == 1
    assert ("fr","Retiré") not in adapter.pages


def test_signed_read_only_remote_inventory_is_last_resort(tmp_path):
    text = argument("Inventorié")
    config, path = make_fixture(tmp_path, old_pages=[], new_pages=[("fr", "A1", "Titre", text)])
    state_path = tmp_path / ".state/published/demo/fr/latest.json"
    state_path.unlink()
    inventory = {
        "inventory_version": "1.0",
        "inventory_mode": "explicit_debate_pages_read_only",
        "debate_id": "demo",
        "language": "fr",
        "generated_at": "2026-07-31T20:00:00Z",
        "pages": [{
            "page_id": "A1",
            "page_type": "argument",
            "canonical_title": "Titre",
            "content_sha256": module.sha_text(text),
            "revision_id": 10,
            "status": "published",
            "content": text,
        }],
    }
    inventory["inventory_sha256"] = module.sha_object(inventory)
    inv_path = tmp_path / ".state/inventories/demo/fr.json"
    inv_path.parent.mkdir(parents=True)
    inv_path.write_text(json.dumps(inventory), encoding="utf-8")
    adapter = FakeAdapter({("fr", "Titre"): (10, text)})
    planner = module.RemoteUpdatePlanner(config, adapter, path)
    plan_data = planner.build_plan()
    assert plan_data["state_source"]["kind"] == "remote_inventory"
    assert plan_data["counts"]["skip"] == 1
```
