# Installation Wikidéb’IA 1.2.18 / 0.4.19 / 2.2.2

Installer ensemble les trois archives stables :

- `wikidebia-normes.zip` ;
- `wikidebia-validator.zip` ;
- `wikidebia-kit.zip`.

Dans une installation existante compatible, déposer les trois ZIP dans `updates/`, puis exécuter :

```bash
./wikidebia upgrade
```

Pour une publication initiale :

```bash
./wikidebia publish
```

Pour reprendre un débat publié :

```bash
./wikidebia update IDENTIFIANT --dry-run
./wikidebia update IDENTIFIANT
```

La publication initiale ne demande plus de confirmation interactive. La reprise conserve une confirmation explicite de l’empreinte, car elle peut déplacer ou supprimer des pages.
