# Comparaison avec le dépôt GitHub précédent

Le dépôt public `wikidebates/wikidebia` expose la structure `kit/`, `norms/`, `validator/`, `receipts/`, le lanceur `wikidebia` et les sources actives. Son README public décrit encore `./wikidebia update` comme la commande de remplacement des composants.

La livraison 2.2.x conserve cette architecture, mais sépare désormais les intentions :

- `./wikidebia upgrade` met à niveau les composants ;
- `./wikidebia update IDENTIFIANT` reprend un débat déjà publié ;
- `./wikidebia publish` publie sans invite interactive, après plan signé.

La comparaison détaillée a utilisé les archives de référence 1.2.15 / 0.4.16 / 2.1.17 fournies avec la conversation. Les anciens fichiers actifs remplacés sont archivés ou renommés ; aucune fonction de base n’a été supprimée sans successeur.
