# Rapport final — correction du séparateur des auteurs et audit croisé

## Versions livrées

- norme : **1.2.18** ;
- validateur : **0.4.19** ;
- kit : **2.2.2**.

## Correction principale

La conversion d’une liste JSON d’auteurs vers MediaWiki utilise désormais la forme canonique :

```text
|auteurs=Auteur 1, Auteur 2
```

Un auteur reste scalaire et une liste vide entraîne l’omission du paramètre. Le validateur et le précontrôle du kit refusent sous 1.2.18 :

- `Auteur 1 ; Auteur 2` ;
- `Auteur 1,Auteur 2` ;
- `Auteur 1 , Auteur 2` ;
- `Auteur 1， Auteur 2` ;
- toute sérialisation JSON telle que `["Auteur"]`.

Le contrôle de ponctuation n’est pas appliqué rétroactivement aux paquets qui demeurent déclarés sous 1.2.17. Une migration vers 1.2.18 exige la virgule suivie d’une espace.

## Vérifications en plusieurs passes

### Passe 1 — cohérence fonctionnelle

Les quatre corrections de la conversation sont toujours présentes :

1. article Wikipédia obligatoire et non vide ;
2. absence de `débats-connexes` et `related-debates` dans les sorties ;
3. conversion des tableaux JSON d’auteurs ;
4. publication initiale sans question `[o/N]`, avec transmission automatique du SHA-256 du plan.

Les capacités de reprise ajoutées en 1.2.16 sont conservées : états publiés signés, `create/skip/update/move/redirect/delete/manual_review/blocked`, concurrence MediaWiki, protections des modifications humaines, suppressions attestées, idempotence, portées `--no-delete`, `--only-delete` et `--dry-run`.

### Passe 2 — non-régression des versions

Une omission héritée a été corrigée : plusieurs ensembles internes passaient directement de 1.2.14 à 1.2.17. Les révisions 1.2.15, 1.2.16, 1.2.17 et 1.2.18 sont maintenant présentes sans trou. Deux tests statiques empêchent la réintroduction de ce défaut.

Les documents de provenance 1.2.16 / 0.4.17 / 2.2.0 qui portaient par erreur des étiquettes 1.2.17 / 0.4.18 / 2.2.1 ont également été corrigés.

### Passe 3 — comparaison avec la base précédente

La structure publique du dépôt GitHub a été contrôlée, puis la comparaison fichier par fichier a été effectuée avec les paquets de référence 1.2.15 / 0.4.16 / 2.1.17 fournis dans la conversation.

- normes : 95 fichiers de référence, 20 ajouts ;
- validateur : 217 fichiers de référence, 23 ajouts ;
- kit : 31 fichiers de référence, 8 ajouts.

Les seuls chemins actifs de la base qui disparaissent sont les anciennes normes actives et les anciens exemples de configuration ; les normes remplacées sont conservées dans `history/`. Aucun script fonctionnel de la base n’a été supprimé.

### Passe 4 — tests depuis les sources

- validateur : **153 tests réussis**, 0 échec ;
- kit : **83 tests réussis**, 0 échec ;
- scénarios obligatoires de reprise : **15/15** ;
- schémas JSON : **19** ;
- catalogue : **357 exigences uniques**.

La suite du kit a été exécutée par fichiers et groupes indépendants, car l’environnement interrompt une commande pytest unique de longue durée. Tous les 83 tests collectés ont été exécutés et réussis.

### Passe 5 — tests depuis les ZIP réellement livrés

Les trois ZIP ont été extraits dans des dossiers propres. L’auto-audit et les 153 tests du validateur extrait ont réussi. Les 83 tests du kit extrait ont ensuite réussi par fichiers et groupes indépendants.

### Passe 6 — intégrité et reproductibilité

- inventaires internes complets ;
- tailles et SHA-256 contrôlés ;
- CRC ZIP réussi ;
- copies normatives normes/validateur identiques octet par octet ;
- syntaxe Python et JSON valide ;
- aucun secret ni chemin local `/mnt/data/` dans les paquets ;
- reconstruction déterministe vérifiée par deux générations successives aux mêmes empreintes.

## Résultat

**AUDIT FINAL : RÉUSSI**

Aucune connexion, publication, modification, suppression ou déplacement MediaWiki réel n’a été effectué.
