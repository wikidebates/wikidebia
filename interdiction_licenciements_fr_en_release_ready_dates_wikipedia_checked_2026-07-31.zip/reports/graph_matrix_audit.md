# Matrice de couverture du graphe

- Droit et libertés : couvert
- Économie, embauche et productivité : couvert
- Santé, pouvoir et inégalités : couvert
- Territoires et externalités : couvert
- Mise en œuvre et contournements : couvert
- Transitions technologiques et écologiques : couvert
- Alternatives et positions intermédiaires : couvert

Nœuds distincts : 84.
