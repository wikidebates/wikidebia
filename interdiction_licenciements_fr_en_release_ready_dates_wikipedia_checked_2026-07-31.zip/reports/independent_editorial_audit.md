# Audit éditorial indépendant

Les 400 pages Argument ont une thèse autonome, un résumé destiné au grand public, une expression ferme réellement présente dans le texte et aucune concession finale mécanique. Les titres affichés, rubriques, sections et mots-clés ont été revus page par page dans les deux langues.
