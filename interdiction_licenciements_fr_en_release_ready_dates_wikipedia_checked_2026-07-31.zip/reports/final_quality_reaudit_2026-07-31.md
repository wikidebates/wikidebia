# Réaudit approfondi de qualité — interdiction des licenciements

**Date :** 31 juillet 2026  
**Corpus :** `interdiction_licenciements`  
**État visé :** `release_ready`  
**Écriture distante :** aucune

## 1. Méthode

Le corpus a été repris comme un candidat non fiable, puis soumis à des passes indépendantes et successives :

1. contrôle du graphe logique, des occurrences, des relations, des profondeurs et des réutilisations ;
2. examen de la couverture argumentative à partir de synthèses institutionnelles récentes et de normes internationales ;
3. revue des pages Débat française et anglaise, famille documentaire par famille documentaire ;
4. contrôle individuel des 486 résumés d’Argument ;
5. recherche de répétitions exactes, quasi-doublons, ouvertures trop proches des titres, rythmes mécaniques, fragments et calques bilingues ;
6. vérification des sources, de leurs usages, des métadonnées audiovisuelles et des doublons documentaires ;
7. régénération des projections, lots, agrégats, empreintes et manifestes ;
8. validation intégrale avec le validateur Wikidéb’IA 0.4.16.

## 2. Graphe argumentatif

### État final

- **243 nœuds actifs** ;
- **245 relations actives** ;
- **269 occurrences actives** ;
- **24 branches principales**, soit 12 pour et 12 contre ;
- **23 nœuds réutilisés**, représentant 26 occurrences supplémentaires ;
- **aucun nœud dupliqué à l’intérieur d’une même branche principale** ;
- **aucun cycle, nœud orphelin, autojustification ou auto-objection** ;
- profondeur maximale ramenée à **6**.

### Corrections structurelles

Deux occurrences secondaires qui ne développaient aucun raisonnement propre ont été retirées avec leurs relations. Des réemplois localement redondants avaient déjà été supprimés lors de la passe précédente. Les réutilisations restantes relient des sous-débats réellement transversaux et demeurent des feuilles lorsqu’elles sont secondaires.

Les neuf chemins atteignant le niveau 6 ont été relus un par un. Ils portent sur des controverses qui exigent plusieurs réponses successives : droit au séjour lié à l’emploi, reprise d’entreprise, garantie d’emploi, critères de sélection, attrition, départs volontaires, réciprocité contractuelle et procédure judiciaire. Ils sont constitués d’occurrences primaires développées. Les aplatir uniquement pour satisfaire une préférence numérique ferait perdre la logique dialectique.

### Couverture argumentative

Le graphe couvre les principaux mécanismes relevés dans les synthèses contemporaines sur la protection de l’emploi : réduction des licenciements, effets sur l’embauche et les mobilités, segmentation entre contrats, investissement dans les compétences, productivité, adoption technologique, réallocation, pouvoir de négociation, risques de contournement, restructuration, transitions et garanties procédurales. Aucun axe majeur clairement distinct n’a été identifié comme manquant lors de la contre-recherche finale.

## 3. Pages Débat

### Structure des introductions

Chaque introduction comporte **six sous-parties** avec une progression autonome : définition, portée sociale, histoire juridique, situations nationales, état des connaissances et choix politique.

- appels de références dans l’introduction française : **9** ;
- appels de références dans l’introduction anglaise : **6** ;
- aucune balise `<references />` ;
- aucune note d’introduction contenant un modèle MediaWiki interdit ;
- aucune date documentaire au format machine dans la prose.

La terminologie française a été précisée en « licenciement pour motif personnel ». Le passage anglais sur l’emploi à volonté est désormais appuyé par une source gouvernementale américaine directe.

### Documentation générale

Chaque page Débat contient **24 notices distinctes** :

- bibliographie pour, contre et générale : 3 notices par rubrique ;
- sitographie pour, contre et générale : 3 notices par rubrique ;
- vidéographie pour, contre et générale : 2 notices par rubrique.

Le registre comprend **64 sources vérifiées et toutes utilisées**. Il n’existe plus de doublon exact de lien dans les paramètres documentaires d’une même page Débat. Les références générales trop étroites ont été remplacées par des rapports de synthèse ; les études spécialisées restent affectées aux pages Argument où elles sont pertinentes.

### Vidéographie

Les douze vidéos ont été revérifiées individuellement. Neuf notices ont reçu une correction d’auteur, de responsable éditorial ou de titre. Une vidéo promotionnelle insuffisamment indépendante a été remplacée par une analyse de Knowledge at Wharton. Aucune attribution n’a été inventée.

## 4. Pages Argument et résumés

### Couverture

- **243 pages françaises** et **243 pages anglaises** ;
- chaque page possède au moins **deux références documentaires** ;
- équivalence bilingue stricte des nœuds, relations et occurrences ;
- aucun résumé ne contient de donnée chiffrée non documentée.

### Relecture stylistique

Les 486 résumés ont été analysés individuellement et par comparaison globale. La reprise a notamment supprimé un patron de conclusion répété sur 93 paires bilingues, puis corrigé des répétitions résiduelles, des fragments, une coquille et plusieurs calques anglais.

État final :

- aucune phrase exacte répétée entre deux pages ;
- aucune conclusion exacte répétée ;
- aucun quasi-doublon de résumé au seuil de contrôle retenu ;
- aucun quasi-doublon de titre au seuil de contrôle retenu ;
- aucune ouverture trop proche du titre canonique ;
- aucun écart excessif de longueur entre versions française et anglaise ;
- aucune phrase de plus de 50 mots ;
- aucune auto-objection ni concession finale qui annule la thèse ;
- aucun terme technique non expliqué détecté ;
- aucun métadiscours de génération.

Les rythmes ne suivent plus un moule unique : les résumés utilisent trois ou quatre phrases selon la complexité du mécanisme. Une adaptation anglaise particulièrement dense a été réécrite de manière idiomatique au lieu de reproduire la syntaxe française.

## 5. Cohérence documentaire et technique

- aucune source rejetée encore utilisée ;
- aucune source vérifiée inutilisée ;
- aucune référence vers une page inexistante ;
- aucune collision normalisée de titre ;
- aucun fichier déclaré absent ;
- aucun fichier orphelin ;
- agrégats reconstruits depuis les pages individuelles ;
- lots français et anglais resynchronisés ;
- empreintes SHA-256 recalculées ;
- provenance historique **norme 1.2.10** conservée ;
- validation exécutée avec le validateur courant **0.4.16**, compatible avec cette provenance.

## 6. Résultat

La validation intégrale donne :

- **0 erreur** ;
- **1 avertissement** ;
- **1 information** ;
- résultat global : **réussi avec avertissement**.

L’avertissement `WDV-GRA-009` porte uniquement sur la profondeur maximale de 6. Il est conservé comme signal explicite, car les neuf chemins concernés ont été relus et justifiés ; aucune chaîne artificielle ou réutilisation développée n’y subsiste.

## 7. Décision éditoriale

Le corpus peut être maintenu à l’état `release_ready`. Cette décision repose sur la validation technique, la contre-relecture documentaire et la revue sémantique du graphe et des résumés. Elle ne prétend pas qu’un débat de 243 arguments est définitivement clos : elle atteste qu’aucune omission majeure identifiable, redondance structurelle dommageable ou faiblesse rédactionnelle systémique n’a subsisté après les passes effectuées.
