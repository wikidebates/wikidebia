# Images et conclusions réutilisées

Les expressions fortes ont été comparées. Aucune image saillante ni conclusion n'est répétée entre deux pages.
