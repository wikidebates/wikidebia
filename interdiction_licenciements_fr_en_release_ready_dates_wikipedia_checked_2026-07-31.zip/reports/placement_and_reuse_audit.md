# Audit du placement et des réutilisations

Date : 31 juillet 2026. Révision indépendante finale.

## Méthode

Chaque occurrence a été relue avec son parent immédiat, sa branche principale et sa fonction argumentative. Les réutilisations ont été séparées en deux catégories : accès transversal utile entre branches différentes, ou répétition locale du même nœud dans une seule branche.

## Corrections de placement antérieures conservées

- les dommages subis par les salariés restants et par les enfants sont des justifications directes de la protection contre la rupture unilatérale ;
- le capital organisationnel, les savoir-faire et les suppressions rentables sont rattachés au court-termisme financier ;
- l'argument sur l'assurance chômage est développé dans la branche des dommages du licenciement et réutilisé comme alternative dans la branche de la liberté d'entreprendre ;
- les consolidations sémantiques antérieures restent actives lorsqu'elles réunissent réellement un même raisonnement.

## Correction finale des réutilisations locales

Dix occurrences secondaires ont été retirées parce que le même nœud figurait déjà, dans la même branche principale, sous un parent plus précis. Leur suppression ne retire aucun argument et ne réduit aucun accès transversal pertinent.

Deux chaînes profondes ont en outre été reparentées pour distinguer une objection latérale d'une réponse séquentielle obligatoire.

## État final

Le graphe compte 243 nœuds et 269 occurrences. Il conserve 23 nœuds réutilisés, soit 28 occurrences supplémentaires, toutes entre contextes argumentatifs réellement distincts. Aucun nœud n'apparaît deux fois dans une même branche principale. Les occurrences secondaires restent des feuilles dans le rendu.


> Mise à jour du 31 juillet 2026 : le réaudit final a retiré deux réutilisations secondaires non développées de niveau 7. Voir `reports/final_quality_reaudit_2026-07-31.md`.
