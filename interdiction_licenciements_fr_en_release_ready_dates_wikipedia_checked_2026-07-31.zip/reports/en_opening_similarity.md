# Similarité des ouvertures

Aucune paire ne dépasse le seuil de revue.
