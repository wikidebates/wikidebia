# Doublons des notes de revue

Chaque note identifie l'ouverture, le mécanisme, la difficulté et l'expression forte propres à la page ; aucune note complète n'est dupliquée.
