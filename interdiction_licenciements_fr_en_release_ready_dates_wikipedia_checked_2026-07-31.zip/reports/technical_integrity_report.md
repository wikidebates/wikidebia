# Intégrité des composants techniques

Les composants actifs fournis avec le projet sont la norme 1.2.15, le validateur 0.4.16 et le kit 2.1.17. Le corpus conserve toutefois sa provenance de production déclarée sous la norme 1.2.10 et le validateur 0.4.10 : ces versions historiques ne sont pas réécrites uniquement pour publier ou corriger le contenu. Le validateur courant 0.4.16 déclare explicitement la compatibilité avec la norme 1.2.10 et a été utilisé pour tous les contrôles de cette reprise.

Aucun composant technique n’a été modifié. Aucune écriture distante n’a été exécutée. Les pages, agrégats, registres et empreintes du corpus ont seuls été régénérés.
