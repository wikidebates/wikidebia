# Audit récursif de complétude approfondi

> Rapport historique de la passe intermédiaire. Les chiffres finaux figurent dans `independent_graph_reaudit_2026-07-31.md`.

Le corpus de 84 nœuds a été réouvert sans faire confiance à sa première déclaration de saturation. L’audit a repris les 56 feuilles alors présentes, recherché les acteurs absents, les effets en amont de l’embauche, les modes de contournement, les alternatives et les meilleures contre-objections.

## Résultat

- 116 arguments distincts ajoutés ;
- 200 nœuds distincts au total ;
- 20 arguments principaux, soit 10 par camp ;
- 218 occurrences et 198 relations ;
- 107 nœuds développés et 93 feuilles ;
- 22 occurrences au niveau 5 ;
- 18 réutilisations contrôlées, toujours rendues comme feuilles secondaires.

## Branches développées jusqu’au niveau 5

Les chaînes longues portent sur les controverses qui changent réellement la conclusion : mutualisation du risque, démocratie dans l’entreprise, ajustement par les salaires et les heures, investissement, protection sociale, coûts collectifs, stabilisation, innovation, pouvoir de négociation, alternatives au licenciement, discrimination, territoires, survie des entreprises, embauche, informalité, réallocation, performance, proportionnalité, définition de l’interdiction et transition juste.

## Arrêt de la recherche

Après les ajouts, deux passes indépendantes ont repris le sujet avec des grilles différentes. Elles n’ont produit que des exemples, variantes nationales ou reformulations de mécanismes déjà représentés. La profondeur 5 n’a pas été imposée aux branches qui devenaient répétitives ou artificielles.
