# Séquences répétées de huit mots ou plus

Aucune séquence de huit mots n'est partagée entre deux résumés.
