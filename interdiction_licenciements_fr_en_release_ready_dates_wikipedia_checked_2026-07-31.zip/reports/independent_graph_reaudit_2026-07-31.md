# Réaudit indépendant du graphe argumentatif

Date : 31 juillet 2026.

## Périmètre

Le graphe a été repris avant l'examen documentaire et rédactionnel. Le contrôle a porté sur le DAG, les relations, les occurrences primaires et secondaires, la profondeur, les réutilisations, les doublons à l'intérieur d'une même branche principale et la fonction argumentative de chaque chaîne profonde.

## Anomalies constatées

Dix nœuds étaient affichés deux fois dans une même branche principale : une occurrence directe coexistait avec une occurrence plus précisément rattachée à une objection ou à une justification intermédiaire. Ces réemplois locaux n'apportaient aucun accès transversal ; ils répétaient le même argument à deux endroits voisins.

Deux chaînes atteignaient le niveau 8. Leur contenu était pertinent, mais leur parentage transformait des réponses latérales en prolongements obligatoires d'une chaîne unique.

## Corrections

- suppression de dix occurrences secondaires locales redondantes et de leurs relations propres ;
- conservation des réutilisations entre branches principales réellement distinctes ;
- rattachement de l'objection sur la soutenabilité budgétaire d'une garantie publique d'emploi directement au choix de financement concerné ;
- rattachement de l'objection sur les dommages provoqués par la longueur des procédures directement à la thèse qui défend ces délais ;
- régénération des profondeurs, compteurs, relations MediaWiki et agrégats bilingues.

## État obtenu

- 243 nœuds distincts ;
- 269 occurrences ;
- 245 relations ;
- 23 nœuds réutilisés et 28 réutilisations supplémentaires ;
- 152 nœuds développés et 91 feuilles ;
- profondeur maximale : 6 ;
- aucun nœud répété deux fois sous la même branche principale ;
- aucune occurrence secondaire développée ;
- 12 arguments principaux pour et 12 arguments principaux contre.

La profondeur 7 subsiste dans deux occurrences secondaires transversales. Elles restent des feuilles dans leur emplacement de réutilisation et ne créent donc pas une chaîne de lecture artificiellement prolongée.


> Mise à jour du 31 juillet 2026 : le réaudit final a retiré deux réutilisations secondaires non développées de niveau 7. Voir `reports/final_quality_reaudit_2026-07-31.md`.
