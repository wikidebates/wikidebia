# Rapport de qualité du corpus approfondi

- Graphe : 200 nœuds distincts, 10 arguments principaux par camp, profondeur maximale 5.
- Bilingue : 200 paires de pages Argument plus la paire Débat/Debate.
- Structure : 218 occurrences, 198 relations, 18 réutilisations contrôlées et 42 lots bilingues.
- Documentation : 44 sources vérifiées, usages et adaptation linguistique enregistrés.
- Style : revue individuelle et revue de force expressive pour les 400 pages Argument.
- Saturation : deux passes finales consécutives sans nouvel argument important distinct.
- Publication : aucune écriture distante.
