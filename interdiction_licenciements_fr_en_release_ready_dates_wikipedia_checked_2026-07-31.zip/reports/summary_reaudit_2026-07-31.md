# Audit final du style des résumés

Date : 31 juillet 2026.

## Objet de la dernière passe

Cette passe ne portait plus sur la couverture argumentative ni sur le graphe, mais sur l'impression de lecture produite par l'enchaînement des 243 résumés français et des 243 résumés anglais. Le contrôle a recherché les répétitions exactes, les patrons syntaxiques proches, les ouvertures et conclusions récurrentes, les cadences trop régulières, les formulations calquées sur les titres, les métaphores surutilisées et les adaptations anglaises peu naturelles.

## Défaut résiduel découvert

La précédente diversification avait bien fait varier le nombre de phrases, mais elle avait créé un nouveau patron : de nombreux résumés développaient le raisonnement puis reprenaient presque mot pour mot le titre comme phrase finale.

- 72 résumés français contenaient une phrase présentant une similarité très forte avec leur titre canonique ;
- 66 résumés anglais présentaient le même défaut ;
- les occurrences appartenaient aux mêmes 72 paires bilingues et se trouvaient presque toujours en conclusion.

Cette construction donnait une impression de démonstration suivie d'une légende, plutôt que celle d'un texte rédigé pour lui-même.

## Corrections effectuées

- Les conclusions calquées sur le titre ont été supprimées lorsqu'elles n'ajoutaient aucune information.
- Quinze paires qui seraient devenues trop brèves ont reçu une seconde phrase nouvelle, propre au mécanisme de l'argument.
- Sept paires supplémentaires ont été reprises pour éliminer des répétitions locales ou des formulations anglaises trop uniformes.
- Le résumé A0053 a été recomposé afin de supprimer la répétition immédiate de « difficulté » / « difficulty ».
- Le résumé A0065 a été réécrit pour éviter le martèlement de la métaphore de la facture / du bill.
- Cinq résumés anglais proches dans le graphe ont été diversifiés afin de ne plus enchaîner systématiquement « A ban would… ».
- Les formulations nouvelles ont été relues séparément en français et en anglais ; elles conservent la même thèse sans devenir des traductions mot à mot.

Au total, 79 paires bilingues ont été modifiées pendant cette dernière passe.

## Distribution finale

Dans chaque langue :

- 101 résumés de deux phrases ;
- 96 résumés de trois phrases ;
- 44 résumés de quatre phrases ;
- 2 résumés de cinq phrases.

Cette distribution n'est pas un quota : les résumés courts correspondent aux raisonnements qui gagnent à être resserrés, tandis que les mécanismes comportant une distinction, une chaîne causale ou une condition conservent davantage de phrases.

## Contrôles de sortie

- aucune phrase exactement dupliquée entre deux pages ;
- aucune phrase de résumé ne reprend désormais le titre avec une similarité élevée ;
- aucun trigramme d'ouverture n'apparaît sur trois pages ou davantage ;
- aucun trigramme de conclusion n'apparaît sur trois pages ou davantage ;
- aucune phrase ne dépasse 55 mots ;
- aucune moyenne de résumé ne dépasse 29 mots par phrase ;
- deux à cinq phrases par résumé ;
- aucune conclusion concessive ajoutée artificiellement ;
- registre bilingue de revue mis à jour avec un extrait exact de chaque résumé modifié ;
- aucune modification du graphe, des titres, des relations ou des sources.

## Conclusion éditoriale

Les résumés ne reposent plus sur une même architecture visible. Certains commencent par une conséquence concrète, d'autres par un mécanisme, une distinction juridique, une condition ou un conflit de répartition. Les conclusions peuvent préciser la portée, tirer une conséquence, formuler un arbitrage ou s'effacer lorsque le raisonnement est déjà complet. La variété obtenue vient de la logique propre à chaque argument, et non d'une rotation artificielle de modèles.
