# Sources de recherche du graphe approfondi

## Cadres juridiques et droits fondamentaux

- Organisation internationale du Travail : convention n° 158, motif valable, recours, consultation et alternatives au licenciement.
- Union européenne : protection contre le licenciement injustifié, liberté d’entreprise, droit au travail et règles sur les licenciements collectifs.
- Droit français et débats parlementaires : cause réelle et sérieuse, licenciement économique, liberté d’entreprendre, propositions relatives aux licenciements dits boursiers et aux entreprises bénéficiaires d’aides publiques.

## Effets économiques et fonctionnement du marché du travail

- OCDE : indicateurs de protection de l’emploi, flux d’emplois, dualité entre contrats, productivité, investissement, transitions et dispositifs de maintien dans l’emploi.
- Banque mondiale et OIT : effets comparés des règles de licenciement, articulation entre protection, création d’emplois et couverture sociale.
- Fonds monétaire international : effets macroéconomiques, investissement, réallocation et interaction avec les autres institutions du marché du travail.
- Littérature académique : destructions et créations d’emplois, pertes de revenu après licenciement, santé, innovation, capital organisationnel, pouvoir de négociation, salaires et mobilité.

## Sources spécialisées ajoutées pendant la reprise jusqu’au niveau 5

- Alexander Muravyev, synthèse sur la protection de l’emploi dans les économies en transition et émergentes : informalité, segmentation et contexte institutionnel.
- Adriana D. Kugler, étude des flux de travailleurs et d’emplois après une réforme italienne : embauches, séparations et réallocation.
- OCDE, *Preparing ERTE for the Future* : chômage partiel, maintien temporaire, ciblage et risque de préserver des emplois non viables.
- David Alzate et al., revue de littérature sur les réglementations des marchés du travail et des produits : investissement, création d’entreprises, productivité et hétérogénéité des effets.

## Méthode documentaire

Les sources nouvelles ont été versées au registre S00041 à S00044. Les publications originales en anglais utilisées sur les pages françaises sont explicitement marquées comme originales sans équivalent vérifié, et leurs dates sont localisées dans le wikicode français. Les sources générales déjà vérifiées ont été réutilisées lorsque leur portée couvrait directement le mécanisme étudié.
