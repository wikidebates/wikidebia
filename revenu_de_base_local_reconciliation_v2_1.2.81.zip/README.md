# Réconciliation locale `revenu_de_base` — correctif v2 de l’utilitaire — 1.2.81 / 0.4.85 / 2.16.14

Ce paquet **ne modifie ni la norme, ni le validateur, ni le kit**. Il corrige uniquement un défaut du premier utilitaire local de réconciliation.

## Défaut corrigé

La v1 représentait les 46 résumés historiquement absents par :

```json
"summary": ""
```

Cela est incorrect pour le verrou français : l’absence historique doit rester sémantiquement absente. La v2 reconstruit temporairement trois variantes (`null`, champ omis, chaîne vide), calcule leurs SHA-256, et **n’accepte que `null` ou champ omis si l’une de ces variantes reproduit exactement l’empreinte restaurée déjà scellée** :

```text
59ee182dafd35835829f432cbec7a7a14b07f53a9c6acac64ce747dbb1f0f4ee
```

La variante chaîne vide est conservée uniquement comme diagnostic afin de reconnaître le bug de la v1 ; elle ne peut jamais être appliquée.

Aucune relaxation du garde-fou n’est introduite : si ni `null` ni champ omis ne reproduit l’empreinte scellée, le script bloque et affiche les trois empreintes candidates.

## Préflight uniquement

Remplacer le dossier temporaire de la v1 puis lancer :

```bash
rm -rf /tmp/revenu1281-local-reconcile
mkdir -p /tmp/revenu1281-local-reconcile
unzip -q revenu_de_base_local_reconciliation_v2_1.2.81.zip \
  -d /tmp/revenu1281-local-reconcile

./.venv/bin/python \
  /tmp/revenu1281-local-reconcile/reconcile_revenu_de_base_local_state_1281.py \
  .
```

**Ne pas utiliser `--apply-local` tant que le préflight n’a pas conclu** :

```text
NO_FRENCH_PUBLICATION_REMAINS_BEFORE_ENGLISH
```

avec `restore_receipt.valid=true`.

Le rapport reste écrit dans :

```text
.state/manual-repairs/revenu_de_base_local_reconciliation_1.2.81/inspection.json
```

Le préflight n’effectue aucune écriture MediaWiki. Il peut écrire uniquement son rapport local de diagnostic/inspection.

## Important

Ne pas relancer `./wikidebia workflow` à ce stade. La réconciliation locale doit d’abord être prouvée puis appliquée ; la correction générique du défaut de préservation historique du kit viendra ensuite, séparément.
