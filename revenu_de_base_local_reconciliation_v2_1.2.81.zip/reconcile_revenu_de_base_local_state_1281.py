#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import dataclasses
import datetime as dt
import hashlib
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any, Mapping

DEBATE_ID = "revenu_de_base"
WORK_ID = "EDIT-20260811-001"
VERSIONS = {"norm": "1.2.81", "validator": "0.4.85", "kit": "2.16.14"}
BAD_LOCK_SHA = "c890ac6a43c4fdb027bcf3338af62ac39da1920e2341c94dc7e9850a143567f6"
RESTORED_LOCK_SHA = "59ee182dafd35835829f432cbec7a7a14b07f53a9c6acac64ce747dbb1f0f4ee"
MANUAL_STATE_REL = Path(".state/manual-repairs/revenu_de_base_local_reconciliation_1.2.81")
RESTORE_STATE_REL = Path(".state/manual-repairs/revenu_de_base_restore_original_summaries_intro_1.2.81")


class ReconcileError(RuntimeError):
    pass


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_text(text: str) -> str:
    return sha_bytes(text.encode("utf-8"))


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_obj(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha_bytes(raw)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.tmp-{os.getpid()}")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8", newline="\n")
    os.replace(tmp, path)


def load_json(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ReconcileError(f"{label} illisible: {path}") from exc
    if not isinstance(value, dict):
        raise ReconcileError(f"{label} doit être un objet JSON: {path}")
    return value


def copy_file(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def canonical_payload(payload: Mapping[str, Any]) -> str:
    body = copy.deepcopy(dict(payload))
    body.pop("payload_sha256", None)
    return sha_obj(body)


def load_payload(script_dir: Path) -> dict[str, Any]:
    payload = load_json(script_dir / "REMOTE_RESTORE_PAYLOAD.json", "payload de restauration")
    if payload.get("schema") != "wikidebia-manual-remote-restore-1.0":
        raise ReconcileError("Schéma du payload de restauration inattendu")
    if payload.get("debate_id") != DEBATE_ID or payload.get("work_id") != WORK_ID:
        raise ReconcileError("Le payload ne correspond pas à revenu_de_base / EDIT-20260811-001")
    if payload.get("versions") != VERSIONS:
        raise ReconcileError("Versions du payload inattendues")
    if payload.get("payload_sha256") != canonical_payload(payload):
        raise ReconcileError("Empreinte du payload de restauration invalide")
    if int(payload.get("operation_count") or -1) != len(payload.get("operations") or []):
        raise ReconcileError("Nombre d'opérations incohérent dans le payload")
    if payload.get("source_bad_lock_sha256") != BAD_LOCK_SHA or payload.get("source_restored_lock_sha256") != RESTORED_LOCK_SHA:
        raise ReconcileError("Empreintes de verrou inattendues dans le payload")
    return payload


@dataclasses.dataclass(frozen=True)
class ParamSpan:
    name: str
    pipe_start: int
    value_start: int
    value_end: int
    segment_end: int


def main_template_spans(text: str) -> tuple[str, list[ParamSpan], int]:
    start = text.find("{{")
    if start < 0:
        raise ReconcileError("Aucun modèle principal trouvé")
    template_depth = 0
    link_depth = 0
    in_comment = False
    pipes: list[int] = []
    main_close = None
    i = start
    while i < len(text):
        if in_comment:
            end = text.find("-->", i)
            if end < 0:
                raise ReconcileError("Commentaire HTML non fermé")
            i = end + 3
            in_comment = False
            continue
        if text.startswith("<!--", i):
            in_comment = True
            i += 4
            continue
        if text.startswith("[[", i):
            link_depth += 1
            i += 2
            continue
        if text.startswith("]]", i) and link_depth:
            link_depth -= 1
            i += 2
            continue
        if text.startswith("{{", i):
            template_depth += 1
            i += 2
            continue
        if text.startswith("}}", i):
            if template_depth == 1:
                main_close = i
                break
            if template_depth > 1:
                template_depth -= 1
                i += 2
                continue
            raise ReconcileError("Fermeture de modèle inattendue")
        if text[i] == "|" and template_depth == 1 and link_depth == 0:
            pipes.append(i)
        i += 1
    if main_close is None:
        raise ReconcileError("Modèle principal non fermé")
    first_pipe = pipes[0] if pipes else main_close
    name = text[start + 2:first_pipe].strip()
    bounds = pipes + [main_close]
    spans: list[ParamSpan] = []
    for pos, pipe in enumerate(pipes):
        seg_end = bounds[pos + 1]
        seg = text[pipe + 1:seg_end]
        eq = seg.find("=")
        if eq < 0:
            continue
        pname = seg[:eq].strip()
        if not pname:
            continue
        spans.append(ParamSpan(pname, pipe, pipe + 1 + eq + 1, seg_end, seg_end))
    return name, spans, main_close


def get_param(text: str, param: str) -> tuple[bool, str]:
    _, spans, _ = main_template_spans(text)
    matches = [s for s in spans if s.name == param]
    if not matches:
        return False, ""
    if len(matches) != 1:
        raise ReconcileError(f"|{param}= apparaît {len(matches)} fois")
    s = matches[0]
    return True, text[s.value_start:s.value_end].rstrip(" \t\r\n")


def set_param(text: str, param: str, present: bool, value: str) -> str:
    _, spans, close = main_template_spans(text)
    matches = [s for s in spans if s.name == param]
    if len(matches) > 1:
        raise ReconcileError(f"|{param}= apparaît {len(matches)} fois")
    if not present:
        if not matches:
            return text
        s = matches[0]
        return text[:s.pipe_start] + text[s.segment_end:]
    clean = value.rstrip(" \t\r\n")
    if matches:
        s = matches[0]
        old = text[s.value_start:s.value_end]
        suffix = old[len(old.rstrip(" \t\r\n")):]
        return text[:s.value_start] + clean + suffix + text[s.value_end:]
    insertion = (f"|{param}={clean}\n" if close > 0 and text[close - 1] in "\r\n" else f"\n|{param}={clean}\n")
    return text[:close] + insertion + text[close:]


def top_level_params(text: str) -> dict[str, str]:
    _, spans, _ = main_template_spans(text)
    out: dict[str, str] = {}
    for s in spans:
        out[s.name] = text[s.value_start:s.value_end].rstrip(" \t\r\n")
    return out


def differing_params(expected: str, actual: str) -> list[dict[str, Any]]:
    try:
        a = top_level_params(expected)
        b = top_level_params(actual)
    except Exception:
        return [{"parameter": "<page-text>", "expected_sha256": sha_text(expected), "actual_sha256": sha_text(actual)}]
    names = sorted(set(a) | set(b))
    rows = []
    for name in names:
        if a.get(name) != b.get(name):
            rows.append({
                "parameter": name,
                "expected_present": name in a,
                "actual_present": name in b,
                "expected_sha256": sha_text(a[name]) if name in a else None,
                "actual_sha256": sha_text(b[name]) if name in b else None,
            })
    return rows


def verify_versions(root: Path) -> dict[str, Any]:
    locations = {
        "norms": root / "norms" / "VERSIONS.json",
        "validator": root / "validator" / "VERSIONS.json",
        "kit": root / "kit" / "VERSIONS.json",
    }
    observed: dict[str, Any] = {}
    for name, path in locations.items():
        if not path.is_file():
            raise ReconcileError(f"VERSIONS.json absent pour {name}: {path}")
        data = load_json(path, f"versions {name}")
        observed[name] = data
        if data != VERSIONS:
            raise ReconcileError(f"Versions locales divergentes pour {name}: {data}; attendu {VERSIONS}")
    return observed


def add_project_modules(root: Path):
    scripts = root / "kit" / "scripts"
    if not scripts.is_dir():
        raise ReconcileError(f"Scripts du kit absents: {scripts}")
    sys.path.insert(0, str(scripts))
    from wikidebia_corpus_build import full_tree_sha256
    from wikidebia_editorial_workspace import workspace_receipt_hash
    from wikidebia_french_checkpoint import _build_content_checkpoint_copy
    from wikidebia_update import sha_object
    return full_tree_sha256, workspace_receipt_hash, _build_content_checkpoint_copy, sha_object


def patch_lock_document(lock: dict[str, Any], payload: Mapping[str, Any], *, absent_summary_representation: str = "null") -> dict[str, Any]:
    """Patch only owner-authorized intro/summary fields.

    Historical absence must remain semantically absent.  The exact historical
    lock serialized representation is recovered against RESTORED_LOCK_SHA;
    accepted candidates are JSON null or an omitted ``summary`` key.  The
    legacy empty-string candidate is computed only as a diagnostic so that the
    v1 bug can be identified unambiguously; it is never selected for apply.
    """
    if absent_summary_representation not in {"null", "omit", "empty"}:
        raise ReconcileError(f"Représentation de résumé absent inconnue: {absent_summary_representation}")
    out = copy.deepcopy(lock)
    if out.get("debate_id") != DEBATE_ID or out.get("work_id") != WORK_ID:
        raise ReconcileError("Le verrou français ne correspond pas au débat/Work attendus")
    debate = out.get("debate")
    args = out.get("arguments")
    if not isinstance(debate, dict) or not isinstance(args, list):
        raise ReconcileError("Structure inattendue du verrou français")
    by_id = {str(row.get("id")): row for row in args if isinstance(row, dict)}
    for op in payload.get("operations") or []:
        if op.get("parameter") == "introduction":
            debate["introduction"] = str(op.get("target_value") or "")
        elif op.get("parameter") == "résumé":
            page_id = str(op.get("page_id"))
            if page_id not in by_id:
                raise ReconcileError(f"Argument absent du verrou: {page_id}")
            row = by_id[page_id]
            if op.get("target_present"):
                row["summary"] = str(op.get("target_value") or "")
            elif absent_summary_representation == "null":
                row["summary"] = None
            elif absent_summary_representation == "omit":
                row.pop("summary", None)
            else:  # diagnostic only; never eligible for apply
                row["summary"] = ""
        else:
            raise ReconcileError(f"Paramètre inattendu dans le payload: {op.get('parameter')}")
    return out


def reconstruct_restored_lock(lock: dict[str, Any], payload: Mapping[str, Any], lock_path: Path) -> tuple[dict[str, Any], str, dict[str, str]]:
    """Recover the exact sealed lock representation without guessing.

    Writes only to the caller-provided temporary lock path.  ``empty`` is kept
    as a diagnostic candidate to recognize the v1 reconciliation-package bug,
    but only ``null`` or ``omit`` may satisfy the sealed target for use.
    """
    candidate_hashes: dict[str, str] = {}
    selected: tuple[dict[str, Any], str] | None = None
    for mode in ("null", "omit", "empty"):
        candidate = patch_lock_document(lock, payload, absent_summary_representation=mode)
        write_json(lock_path, candidate)
        digest = sha_file(lock_path)
        candidate_hashes[mode] = digest
        if digest == RESTORED_LOCK_SHA and mode in {"null", "omit"}:
            selected = (candidate, mode)
    if selected is None:
        detail = ", ".join(f"{k}={v}" for k, v in candidate_hashes.items())
        raise ReconcileError(
            "Aucune représentation sémantiquement correcte du verrou restauré ne reproduit l'empreinte scellée "
            f"{RESTORED_LOCK_SHA}. Candidats: {detail}"
        )
    candidate, mode = selected
    write_json(lock_path, candidate)
    return candidate, mode, candidate_hashes


def render_temp_desired(root: Path, workspace: Path, payload: Mapping[str, Any], full_tree_sha256, build_content_copy):
    source = workspace / "content-reviewed-copy"
    if not source.is_dir() or source.is_symlink():
        raise ReconcileError("content-reviewed-copy absent ou non sûr")
    lock_path = source / "data/fr_content_lock.json"
    current_lock_sha = sha_file(lock_path)
    if current_lock_sha not in {BAD_LOCK_SHA, RESTORED_LOCK_SHA}:
        raise ReconcileError(
            "Le verrou français local n'est ni le verrou fautif attendu ni le verrou restauré attendu: " + current_lock_sha
        )
    temp_root = Path(tempfile.mkdtemp(prefix="wikidebia-rdb-reconcile-"))
    patched_source = temp_root / "patched-content-reviewed-copy"
    rendered = temp_root / "rendered-checkpoint"
    shutil.copytree(source, patched_source, symlinks=False, copy_function=shutil.copy2)
    lock_temp_path = patched_source / "data/fr_content_lock.json"
    lock = load_json(lock_temp_path, "verrou français temporaire")
    if current_lock_sha == RESTORED_LOCK_SHA:
        patched = lock
        selected_absent_summary_representation = "already_restored"
        candidate_hashes = {"already_restored": current_lock_sha}
    else:
        patched, selected_absent_summary_representation, candidate_hashes = reconstruct_restored_lock(
            lock, payload, lock_temp_path
        )
    write_json(lock_temp_path, patched)
    patched_lock_sha = sha_file(lock_temp_path)
    if patched_lock_sha != RESTORED_LOCK_SHA:
        shutil.rmtree(temp_root, ignore_errors=True)
        raise ReconcileError(
            f"Le verrou restauré reconstruit ne correspond pas à l'empreinte attendue: {patched_lock_sha} != {RESTORED_LOCK_SHA}"
        )
    result = build_content_copy(root, patched_source, rendered, DEBATE_ID, WORK_ID)
    desired_tree_sha = full_tree_sha256(patched_source)
    registry = load_json(rendered / "data/registre_debat.json", "registre rendu")
    nodes = [n for n in ((registry.get("graph") or {}).get("nodes") or []) if n.get("status") == "active"]
    desired_pages: list[dict[str, Any]] = []
    debate_title = str((((registry.get("debate") or {}).get("pages") or {}).get("fr") or {}).get("canonical_title") or "")
    debate_id_actual = str((registry.get("debate") or {}).get("id") or DEBATE_ID)
    dp = rendered / "output/fr/debate/debate.wiki"
    desired_pages.append({"page_id": "DEBATE", "state_page_id": debate_id_actual, "page_type": "debate", "title": debate_title, "path": dp, "text": dp.read_text(encoding="utf-8")})
    for node in nodes:
        page_id = str(node.get("id"))
        title = str((node.get("fr") or {}).get("canonical_title") or "")
        path = rendered / f"output/fr/arguments/{page_id}.wiki"
        desired_pages.append({"page_id": page_id, "state_page_id": page_id, "page_type": "argument", "title": title, "path": path, "text": path.read_text(encoding="utf-8")})
    return {
        "temp_root": temp_root,
        "patched_source": patched_source,
        "rendered": rendered,
        "current_lock_sha256": current_lock_sha,
        "patched_lock_sha256": patched_lock_sha,
        "absent_summary_representation": selected_absent_summary_representation,
        "lock_candidate_sha256": candidate_hashes,
        "patched_content_reviewed_copy_tree_sha256": desired_tree_sha,
        "desired_pages": desired_pages,
        "build_result": result,
    }


class WikiReader:
    def __init__(self, root: Path):
        self.root = root
        self.site = None
        self.pywikibot = None

    def open(self) -> None:
        pdir = (self.root / "private/pywikibot").resolve()
        family = (self.root / "kit/families/wikidebates_family.py").resolve()
        if not (pdir / "user-config.py").is_file():
            raise ReconcileError(f"user-config.py absent: {pdir}")
        if not family.is_file():
            raise ReconcileError(f"Famille Pywikibot absente: {family}")
        os.environ["PYWIKIBOT_DIR"] = str(pdir)
        import pywikibot
        self.pywikibot = pywikibot
        pywikibot.config.family_files["wikidebates"] = str(family)
        self.site = pywikibot.Site(code="fr", fam="wikidebates")
        if self.site.user() is None:
            self.site.login()

    def close(self) -> None:
        self.site = None

    def read(self, title: str) -> tuple[int, str]:
        page = self.pywikibot.Page(self.site, title)
        if not page.exists():
            raise ReconcileError(f"Page distante absente: {title}")
        return int(page.latest_revision_id), page.text


def validate_restore_receipt(root: Path, payload: Mapping[str, Any]) -> dict[str, Any]:
    state_dir = root / RESTORE_STATE_REL
    receipt_path = state_dir / "receipt.json"
    result = {"path": receipt_path.as_posix(), "present": receipt_path.is_file(), "valid": False}
    if not receipt_path.is_file():
        return result
    receipt = load_json(receipt_path, "reçu de restauration distante")
    body = copy.deepcopy(receipt)
    claimed = body.pop("receipt_sha256", None)
    valid = (
        receipt.get("schema") == "wikidebia-manual-remote-restore-receipt-1.0"
        and receipt.get("debate_id") == DEBATE_ID
        and receipt.get("work_id") == WORK_ID
        and receipt.get("payload_sha256") == payload.get("payload_sha256")
        and claimed == sha_obj(body)
        and not ((receipt.get("postflight_counts") or {}).get("update"))
        and not ((receipt.get("postflight_counts") or {}).get("repair_tag"))
        and not ((receipt.get("postflight_counts") or {}).get("blocked"))
    )
    result.update({"valid": bool(valid), "receipt_sha256": receipt.get("receipt_sha256"), "postflight_counts": receipt.get("postflight_counts")})
    return result


def inspect(root: Path, script_dir: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    root = root.resolve()
    payload = load_payload(script_dir)
    observed_versions = verify_versions(root)
    full_tree_sha256, workspace_receipt_hash, build_content_copy, sha_object = add_project_modules(root)

    workflow_path = root / ".state/workflows" / DEBATE_ID / "workflow.json"
    workflow = load_json(workflow_path, "workflow")
    if workflow.get("debate_id") != DEBATE_ID or workflow.get("work_id") != WORK_ID:
        raise ReconcileError(f"Workflow inattendu: debate_id={workflow.get('debate_id')} work_id={workflow.get('work_id')}")
    workspace = root / ".state/editorial-workspaces" / DEBATE_ID / WORK_ID
    meta_path = workspace / "workspace.json"
    meta = load_json(meta_path, "workspace.json")
    if meta.get("workspace_sha256") != workspace_receipt_hash(meta):
        raise ReconcileError("Empreinte de workspace.json invalide avant réconciliation")
    rendered_info = render_temp_desired(root, workspace, payload, full_tree_sha256, build_content_copy)

    desired_pages = rendered_info["desired_pages"]
    if len(desired_pages) != len(payload.get("operations") or []):
        raise ReconcileError(f"Le rendu désiré contient {len(desired_pages)} pages, mais le payload de restauration en couvre {len(payload.get('operations') or [])}")
    payload_by_page = {str(op.get("page_id")): op for op in payload.get("operations") or []}
    if set(payload_by_page) != {str(p["page_id"]) for p in desired_pages}:
        raise ReconcileError("Le payload de restauration ne couvre pas exactement les pages françaises actives du rendu")

    published_path = root / ".state/published" / DEBATE_ID / "fr/latest.json"
    published = load_json(published_path, "état publié français") if published_path.is_file() else None
    published_valid = False
    published_by_page: dict[str, dict[str, Any]] = {}
    if published is not None:
        unsigned = copy.deepcopy(published)
        claimed = unsigned.pop("state_sha256", None)
        published_valid = claimed == sha_object(unsigned) and published.get("debate_id") == DEBATE_ID and published.get("language") == "fr"
        if published_valid:
            published_by_page = {str(row.get("page_id")): row for row in published.get("pages") or []}

    wiki = WikiReader(root)
    remote_rows: list[dict[str, Any]] = []
    try:
        wiki.open()
        for page in desired_pages:
            revision_id, remote_text = wiki.read(page["title"])
            op = payload_by_page[str(page["page_id"])]
            present, current_value = get_param(remote_text, str(op["parameter"]))
            target_ok = present == bool(op.get("target_present")) and current_value == str(op.get("target_value") or "")
            exact = remote_text == page["text"]
            prior = published_by_page.get(str(page["state_page_id"]))
            prior_state_matches = bool(prior and prior.get("content_sha256") == sha_text(remote_text) and int(prior.get("revision_id") or -1) == revision_id)
            remote_rows.append({
                "page_id": page["page_id"],
                "state_page_id": page["state_page_id"],
                "page_type": page["page_type"],
                "title": page["title"],
                "revision_id": revision_id,
                "remote_content_sha256": sha_text(remote_text),
                "desired_content_sha256": sha_text(page["text"]),
                "exact_desired_match": exact,
                "restored_parameter": str(op["parameter"]),
                "restored_parameter_matches_target": target_ok,
                "published_state_already_matches_remote": prior_state_matches,
                "differing_parameters": [] if exact else differing_params(page["text"], remote_text),
                "remote_text": remote_text,
            })
    finally:
        wiki.close()

    restore_receipt = validate_restore_receipt(root, payload)
    exact_count = sum(1 for r in remote_rows if r["exact_desired_match"])
    target_count = sum(1 for r in remote_rows if r["restored_parameter_matches_target"])
    state_match_count = sum(1 for r in remote_rows if r["published_state_already_matches_remote"])
    mismatches = [r for r in remote_rows if not r["exact_desired_match"]]
    restored_param_mismatches = [r for r in remote_rows if not r["restored_parameter_matches_target"]]
    remaining_params: dict[str, int] = {}
    for row in mismatches:
        for diff in row["differing_parameters"]:
            name = str(diff.get("parameter"))
            remaining_params[name] = remaining_params.get(name, 0) + 1

    pending = workflow.get("pending_review") if isinstance(workflow.get("pending_review"), dict) else None
    stale_english = {
        "pending_review_type": pending.get("review_type") if pending else None,
        "pending_review_package": pending.get("package_path") if pending else None,
        "translation_review_exists": (workspace / "reviews/en/translation_review.json").is_file(),
        "english_sources_working_exists": (workspace / "data/sources_en_working.json").is_file(),
        "translated_copy_exists": (workspace / "translated-copy").exists(),
        "rendered_copy_exists": (workspace / "rendered-copy").exists(),
        "release_copy_exists": (workspace / "release-copy").exists(),
        "workspace_status": meta.get("status"),
    }

    report = {
        "schema": "wikidebia-revenu-de-base-local-reconciliation-inspection-1.0",
        "created_at": now_iso(),
        "mode": "read_only_inspection",
        "debate_id": DEBATE_ID,
        "work_id": WORK_ID,
        "versions_required": VERSIONS,
        "versions_observed": observed_versions,
        "restore_payload_sha256": payload.get("payload_sha256"),
        "restore_receipt": restore_receipt,
        "workflow": {
            "path": workflow_path.relative_to(root).as_posix(),
            "phase": workflow.get("phase"),
            "status": workflow.get("status"),
            "french_graph_publication_present": bool(workflow.get("french_graph_publication")),
            "french_content_publication_present": bool(workflow.get("french_content_publication")),
        },
        "workspace": {
            "path": workspace.relative_to(root).as_posix(),
            "status": meta.get("status"),
            "workspace_sha256_valid": True,
            "content_lock_sha256_current": rendered_info["current_lock_sha256"],
            "content_lock_sha256_expected_bad": BAD_LOCK_SHA,
            "content_lock_sha256_expected_restored": RESTORED_LOCK_SHA,
            "content_lock_reconstruction_sha256": rendered_info["patched_lock_sha256"],
            "historical_absent_summary_representation": rendered_info["absent_summary_representation"],
            "content_lock_candidate_sha256": rendered_info["lock_candidate_sha256"],
            "patched_content_reviewed_copy_tree_sha256": rendered_info["patched_content_reviewed_copy_tree_sha256"],
        },
        "published_state": {
            "path": published_path.relative_to(root).as_posix(),
            "present": published is not None,
            "valid": published_valid,
            "pages_matching_current_remote": state_match_count,
            "page_count": len(remote_rows),
            "needs_refresh_after_manual_restore": published_valid and state_match_count != len(remote_rows),
        },
        "remote_verification": {
            "page_count": len(remote_rows),
            "restored_parameter_target_matches": target_count,
            "exact_desired_page_matches": exact_count,
            "all_restored_parameters_match": not restored_param_mismatches,
            "all_pages_exactly_match_desired_reconciled_state": not mismatches,
            "remaining_french_mutation_pages": len(mismatches),
            "remaining_french_parameter_counts": remaining_params,
        },
        "stale_english_artifacts": stale_english,
        "conclusion": (
            "NO_FRENCH_PUBLICATION_REMAINS_BEFORE_ENGLISH"
            if not mismatches and not restored_param_mismatches
            else "FRENCH_DELTA_REMAINS_OR_REMOTE_DIVERGENCE"
        ),
        "remaining_french_delta": [
            {k: v for k, v in row.items() if k != "remote_text"}
            for row in mismatches
        ],
        "remote_rows": [
            {k: v for k, v in row.items() if k != "remote_text"}
            for row in remote_rows
        ],
        "remote_snapshot": {str(row["page_id"]): {"revision_id": row["revision_id"], "text": row["remote_text"]} for row in remote_rows},
    }
    return report, {
        "payload": payload,
        "workflow": workflow,
        "workflow_path": workflow_path,
        "workspace": workspace,
        "meta": meta,
        "meta_path": meta_path,
        "published": published,
        "published_path": published_path,
        "remote_rows": remote_rows,
        "rendered_info": rendered_info,
        "full_tree_sha256": full_tree_sha256,
        "workspace_receipt_hash": workspace_receipt_hash,
        "sha_object": sha_object,
    }


def archive_if_exists(root: Path, path: Path, backup_root: Path) -> str | None:
    if not path.exists() and not path.is_symlink():
        return None
    try:
        rel = path.resolve().relative_to(root.resolve())
    except Exception:
        rel = Path(path.name)
    dest = backup_root / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    if path.is_dir() and not path.is_symlink():
        shutil.copytree(path, dest, symlinks=False, copy_function=shutil.copy2)
        shutil.rmtree(path)
    else:
        shutil.copy2(path, dest)
        path.unlink()
    return rel.as_posix()




def restore_backup_path(root: Path, backup_root: Path, rel: str) -> None:
    src = backup_root / rel
    dst = root / rel
    if not src.exists() and not src.is_symlink():
        raise ReconcileError(f"Sauvegarde de rollback absente: {src}")
    if dst.exists() or dst.is_symlink():
        if dst.is_dir() and not dst.is_symlink():
            shutil.rmtree(dst)
        else:
            dst.unlink()
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.is_dir() and not src.is_symlink():
        shutil.copytree(src, dst, symlinks=False, copy_function=shutil.copy2)
    else:
        shutil.copy2(src, dst)


def rollback_local_changes(root: Path, backup_root: Path, original_files: list[str], archived_paths: list[str], created_paths: list[str]) -> list[str]:
    errors: list[str] = []
    # Remove files/directories created by this attempt that had no pre-existing counterpart.
    for rel in created_paths:
        try:
            dst = root / rel
            if dst.exists() or dst.is_symlink():
                if dst.is_dir() and not dst.is_symlink():
                    shutil.rmtree(dst)
                else:
                    dst.unlink()
        except Exception as exc:
            errors.append(f"remove {rel}: {exc}")
    # Restore all original critical files and all artifacts archived during this attempt.
    for rel in list(dict.fromkeys(original_files + archived_paths)):
        try:
            restore_backup_path(root, backup_root, rel)
        except Exception as exc:
            errors.append(f"restore {rel}: {exc}")
    return errors

def apply_local(root: Path, script_dir: Path) -> dict[str, Any]:
    report, ctx = inspect(root, script_dir)
    if report["conclusion"] != "NO_FRENCH_PUBLICATION_REMAINS_BEFORE_ENGLISH":
        raise ReconcileError("Application locale refusée: le wiki ne correspond pas exactement à l'état français désiré restauré")
    if not report["restore_receipt"]["valid"]:
        raise ReconcileError("Application locale refusée: reçu de restauration distante absent ou invalide")
    if not report["published_state"]["valid"]:
        raise ReconcileError("Application locale refusée: état publié français absent ou invalide")

    root = root.resolve()
    workspace: Path = ctx["workspace"]
    payload = ctx["payload"]
    full_tree_sha256 = ctx["full_tree_sha256"]
    workspace_receipt_hash = ctx["workspace_receipt_hash"]
    sha_object = ctx["sha_object"]

    meta_pre = copy.deepcopy(ctx["meta"])
    workflow_pre = copy.deepcopy(ctx["workflow"])
    if (workspace / "translated-copy").exists() or (workspace / "rendered-copy").exists() or (workspace / "release-copy").exists():
        raise ReconcileError("Une traduction a déjà dépassé la simple préparation; réconciliation automatique refusée")
    if str(meta_pre.get("status") or "") in {"en_translation_review_finalized", "en_translation_applied", "bilingual_rendered", "release_ready"}:
        raise ReconcileError(f"Statut anglais trop avancé pour cette réparation locale: {meta_pre.get('status')}")
    pending = workflow_pre.get("pending_review") if isinstance(workflow_pre.get("pending_review"), dict) else None
    if pending and str(pending.get("review_type") or "") not in {"en_translation_review", "en_translation_correction"}:
        raise ReconcileError(f"Une autre revue est en attente ({pending.get('review_type')}); réparation automatique refusée")

    state_dir = root / MANUAL_STATE_REL
    state_dir.mkdir(parents=True, exist_ok=True)
    timestamp = now_iso().replace(":", "").replace("-", "")
    backup_root = state_dir / f"backup-{timestamp}"
    backup_root.mkdir(parents=True, exist_ok=False)

    critical = [
        workspace / "content-reviewed-copy/data/fr_content_lock.json",
        workspace / "workspace.json",
        root / ".state/workflows" / DEBATE_ID / "workflow.json",
        root / ".state/published" / DEBATE_ID / "fr/latest.json",
        workspace / "reviews/en/translation_readiness.json",
        state_dir / "receipt.json",
    ]
    original_files: list[str] = []
    for p in critical:
        if p.is_file():
            rel = p.relative_to(root).as_posix()
            copy_file(p, backup_root / rel)
            original_files.append(rel)

    archived: list[str] = []
    created_paths: list[str] = []
    receipt_rel = (state_dir / "receipt.json").relative_to(root).as_posix()
    if receipt_rel not in original_files:
        created_paths.append(receipt_rel)

    try:
        # Archive only English artifacts that were derived from the stale French content lock.
        for rel in (
            "reviews/en/translation_review.json",
            "data/sources_en_working.json",
            "audits/en_translation_inventory.json",
            "audits/en_translation_inventory.md",
            "reviews/en/semantic_convergence_findings.json",
            "reviews/en/semantic_convergence_review.json",
        ):
            got = archive_if_exists(root, workspace / rel, backup_root)
            if got:
                archived.append(got)
        if pending:
            package_path = str(pending.get("package_path") or "")
            if package_path:
                pkg = (root / package_path).resolve()
                try:
                    pkg.relative_to(root)
                except ValueError as exc:
                    raise ReconcileError(f"Paquet de revue anglais hors racine projet: {pkg}") from exc
                if pkg.is_file():
                    got = archive_if_exists(root, pkg, backup_root)
                    if got:
                        archived.append(got)

        # 1) Replace only the French lock fields covered by the owner-authorized restore payload.
        lock_path = workspace / "content-reviewed-copy/data/fr_content_lock.json"
        before_lock_sha = sha_file(lock_path)
        if before_lock_sha == BAD_LOCK_SHA:
            lock = load_json(lock_path, "verrou français")
            selected_mode = str(ctx["rendered_info"].get("absent_summary_representation") or "")
            if selected_mode not in {"null", "omit"}:
                raise ReconcileError(f"Représentation historique absente non applicable: {selected_mode}")
            patched = patch_lock_document(lock, payload, absent_summary_representation=selected_mode)
            write_json(lock_path, patched)
        elif before_lock_sha != RESTORED_LOCK_SHA:
            raise ReconcileError("Le verrou a changé depuis le préflight")
        after_lock_sha = sha_file(lock_path)
        if after_lock_sha != RESTORED_LOCK_SHA:
            raise ReconcileError("Le verrou français restauré n'a pas l'empreinte attendue après écriture locale")

        # 2) Reset only translation readiness; no French review is reopened or re-run.
        readiness_path = workspace / "reviews/en/translation_readiness.json"
        if readiness_path.is_file():
            readiness = load_json(readiness_path, "préparation anglaise")
            readiness["status"] = "ready_for_translation"
            readiness["french_content_locked_at"] = load_json(lock_path, "verrou français").get("applied_at")
            for item in readiness.get("items") or []:
                if isinstance(item, dict):
                    item["translation_status"] = "ready_for_translation"
                    item["french_content_review_status"] = "locked"
            write_json(readiness_path, readiness)

        # 3) Refresh workspace hashes after the local lock correction.
        content_tree_sha = full_tree_sha256(workspace / "content-reviewed-copy")
        meta = load_json(workspace / "workspace.json", "workspace.json")
        meta["status"] = "fr_content_applied"
        meta.setdefault("content_reviewed_copy", {})["tree_sha256"] = content_tree_sha
        meta["content_reviewed_copy"]["status"] = "fr_content_locked"
        meta.pop("english_translation_review", None)
        meta.setdefault("boundaries", {})["english_translation_started"] = False
        meta["boundaries"]["final_pages_generated"] = False
        meta["manual_reconciliation"] = {
            "schema": "wikidebia-revenu-de-base-content-lock-reconciliation-1.0",
            "reconciled_at": now_iso(),
            "restore_payload_sha256": payload.get("payload_sha256"),
            "bad_lock_sha256": BAD_LOCK_SHA,
            "restored_lock_sha256": RESTORED_LOCK_SHA,
            "remote_exact_match_verified": True,
        }
        meta["workspace_sha256"] = None
        meta["workspace_sha256"] = workspace_receipt_hash(meta)
        write_json(workspace / "workspace.json", meta)

        # 4) Refresh .state/published from the exact current remote revisions/content.
        published_path: Path = ctx["published_path"]
        published = load_json(published_path, "état publié français")
        unsigned = copy.deepcopy(published)
        claimed = unsigned.pop("state_sha256", None)
        if claimed != sha_object(unsigned):
            raise ReconcileError("État publié français modifié depuis le préflight")
        by_id = {str(row.get("page_id")): row for row in published.get("pages") or []}
        for remote in ctx["remote_rows"]:
            row = by_id.get(str(remote["state_page_id"]))
            if row is None:
                raise ReconcileError(f"Page absente de l'état publié: {remote['state_page_id']}")
            row["canonical_title"] = remote["title"]
            row["content_sha256"] = remote["remote_content_sha256"]
            row["revision_id"] = int(remote["revision_id"])
            row["status"] = "published"
        published["pages"] = sorted(by_id.values(), key=lambda r: (str(r.get("page_type") or ""), str(r.get("page_id") or "")))
        published["publication_date"] = now_iso()
        published["manual_reconciliation"] = {
            "schema": "wikidebia-revenu-de-base-published-state-reconciliation-1.0",
            "restore_payload_sha256": payload.get("payload_sha256"),
            "restore_receipt_path": RESTORE_STATE_REL.joinpath("receipt.json").as_posix(),
            "remote_exact_match_verified": True,
            "page_count": len(ctx["remote_rows"]),
            "reconciled_at": now_iso(),
        }
        published["state_sha256"] = None
        body = copy.deepcopy(published)
        body.pop("state_sha256", None)
        published["state_sha256"] = sha_object(body)
        write_json(published_path, published)

        # 5) Supersede the stale content-publication interpretation without deleting its historical receipt.
        workflow_path: Path = ctx["workflow_path"]
        workflow = load_json(workflow_path, "workflow")
        old_publication = copy.deepcopy(workflow.get("french_content_publication") or workflow.get("french_publication"))
        manual_pub = {
            "schema": "wikidebia-revenu-de-base-manual-fr-content-reconciliation-1.0",
            "stage": "content",
            "status": "reconciled_after_manual_restore",
            "reconciled_at": now_iso(),
            "restore_payload_sha256": payload.get("payload_sha256"),
            "restore_receipt_path": RESTORE_STATE_REL.joinpath("receipt.json").as_posix(),
            "remote_exact_match_verified": True,
            "remaining_french_mutation_pages": 0,
            "content_reviewed_copy_tree_sha256": content_tree_sha,
            "supersedes_publication": old_publication,
        }
        workflow["french_content_publication"] = copy.deepcopy(manual_pub)
        workflow["french_publication"] = copy.deepcopy(manual_pub)
        workflow["phase"] = "en_translation_review"
        workflow["status"] = "running"
        workflow["pending_review"] = None
        workflow.pop("remote_publication_stage", None)
        workflow.pop("last_remote_publication_error", None)
        workflow["manual_reconciliation"] = {
            "schema": "wikidebia-revenu-de-base-workflow-reconciliation-1.0",
            "reconciled_at": now_iso(),
            "restore_payload_sha256": payload.get("payload_sha256"),
            "no_french_publication_remaining": True,
            "english_review_must_be_regenerated": True,
        }
        workflow["updated_at"] = now_iso()
        write_json(workflow_path, workflow)

        # 6) Final local-only self-checks.
        meta2 = load_json(workspace / "workspace.json", "workspace.json")
        if meta2.get("workspace_sha256") != workspace_receipt_hash(meta2):
            raise ReconcileError("Empreinte workspace invalide après réconciliation")
        if full_tree_sha256(workspace / "content-reviewed-copy") != str((meta2.get("content_reviewed_copy") or {}).get("tree_sha256")):
            raise ReconcileError("Empreinte content-reviewed-copy invalide après réconciliation")
        state2 = load_json(published_path, "état publié français")
        unsigned2 = copy.deepcopy(state2)
        claimed2 = unsigned2.pop("state_sha256", None)
        if claimed2 != sha_object(unsigned2):
            raise ReconcileError("Empreinte .state/published invalide après réconciliation")
        if sha_file(lock_path) != RESTORED_LOCK_SHA:
            raise ReconcileError("Le verrou français n'est pas resté à l'empreinte restaurée")

        receipt = {
            "schema": "wikidebia-revenu-de-base-local-reconciliation-receipt-1.0",
            "completed_at": now_iso(),
            "debate_id": DEBATE_ID,
            "work_id": WORK_ID,
            "versions": VERSIONS,
            "restore_payload_sha256": payload.get("payload_sha256"),
            "restore_receipt_sha256": report["restore_receipt"].get("receipt_sha256"),
            "remote_exact_match_verified": True,
            "remote_page_count": len(ctx["remote_rows"]),
            "remaining_french_mutation_pages": 0,
            "lock_before_sha256": before_lock_sha,
            "lock_after_sha256": after_lock_sha,
            "content_reviewed_copy_tree_sha256": content_tree_sha,
            "published_state_sha256": state2.get("state_sha256"),
            "workspace_sha256": meta2.get("workspace_sha256"),
            "archived_stale_english_artifacts": archived,
            "backup_path": backup_root.relative_to(root).as_posix(),
            "remote_writes_performed": False,
        }
        receipt["receipt_sha256"] = sha_obj(receipt)
        write_json(state_dir / "receipt.json", receipt)

        temp_root = ctx["rendered_info"].get("temp_root")
        if isinstance(temp_root, Path):
            shutil.rmtree(temp_root, ignore_errors=True)
        return receipt
    except Exception as exc:
        rollback_errors = rollback_local_changes(root, backup_root, original_files, archived, created_paths)
        temp_root = ctx["rendered_info"].get("temp_root")
        if isinstance(temp_root, Path):
            shutil.rmtree(temp_root, ignore_errors=True)
        if rollback_errors:
            raise ReconcileError(
                f"Échec de réconciliation locale ({exc}); rollback incomplet: " + "; ".join(rollback_errors)
            ) from exc
        raise ReconcileError(f"Échec de réconciliation locale; état d'origine restauré: {exc}") from exc


def main() -> int:
    ap = argparse.ArgumentParser(
        description=(
            "Inspecte puis, sur demande explicite, réconcilie uniquement l'état local du workflow revenu_de_base "
            "après restauration distante des résumés et de l'introduction. Aucune écriture MediaWiki n'est implémentée."
        )
    )
    ap.add_argument("project_root", nargs="?", default=".")
    ap.add_argument("--apply-local", action="store_true", help="Appliquer la réconciliation locale après un préflight distant entièrement exact.")
    args = ap.parse_args()
    root = Path(args.project_root).resolve()
    script_dir = Path(__file__).resolve().parent
    state_dir = root / MANUAL_STATE_REL
    state_dir.mkdir(parents=True, exist_ok=True)
    try:
        if args.apply_local:
            receipt = apply_local(root, script_dir)
            print("Réconciliation locale terminée. Aucune écriture MediaWiki n'a été effectuée.")
            print(f"Reçu: {state_dir / 'receipt.json'}")
            print("Conclusion: aucun delta français ne reste à publier avant la régénération de la revue anglaise.")
        else:
            report, ctx = inspect(root, script_dir)
            write_json(state_dir / "inspection.json", report)
            temp_root = ctx["rendered_info"].get("temp_root")
            if isinstance(temp_root, Path):
                shutil.rmtree(temp_root, ignore_errors=True)
            print(json.dumps({
                "conclusion": report["conclusion"],
                "page_count": report["remote_verification"]["page_count"],
                "exact_desired_page_matches": report["remote_verification"]["exact_desired_page_matches"],
                "restored_parameter_target_matches": report["remote_verification"]["restored_parameter_target_matches"],
                "remaining_french_mutation_pages": report["remote_verification"]["remaining_french_mutation_pages"],
                "remaining_french_parameter_counts": report["remote_verification"]["remaining_french_parameter_counts"],
                "content_lock_sha256_current": report["workspace"]["content_lock_sha256_current"],
                "content_lock_sha256_reconstructed": report["workspace"]["content_lock_reconstruction_sha256"],
                "published_state_needs_refresh": report["published_state"]["needs_refresh_after_manual_restore"],
                "restore_receipt_valid": report["restore_receipt"]["valid"],
                "stale_english_artifacts": report["stale_english_artifacts"],
                "report": str(state_dir / "inspection.json"),
                "remote_writes_performed": False,
            }, ensure_ascii=False, indent=2))
            print("Aucune écriture locale de réconciliation ni aucune écriture MediaWiki n'a été effectuée.")
        return 0
    except Exception as exc:
        err = {
            "schema": "wikidebia-revenu-de-base-local-reconciliation-error-1.0",
            "created_at": now_iso(),
            "error": str(exc),
            "remote_writes_performed": False,
        }
        try:
            write_json(state_dir / "error.json", err)
        except Exception:
            pass
        print(f"WIKIDEBIA RÉCONCILIATION BLOQUÉE: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
