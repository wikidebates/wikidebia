# Graphe argumentatif — « Les hommes doivent-ils rejoindre le combat féministe ? »

Date d’extraction : 2026-10-22
Extracteur : 1.0.2 (kit 2.16.47)

## Statistiques

| Niveau | Pages uniques | Occurrences |
|---:|---:|---:|
| 1 | 10 | 10 |
| 2 | 49 | 62 |
| 3 | 39 | 79 |
| 4 | 2 | 47 |
| 5 | 0 | 40 |

- Pages uniques : **100**
- Occurrences dépliées par chemins : **238**
- Relations uniques : **115**
- Justifications : **48**
- Objections : **67**
- Niveau minimal maximal d’une page unique : **4**
- Niveau maximal d’une occurrence : **5**
- Profondeur maximale en nombre d’arêtes : **4**
- Pages sans sortie dans le graphe extrait : **72**
- Feuilles réelles : **72**
- Pages réutilisées : **41**
- Graphe sans cycle : **oui**

Une occurrence dépliée correspond à un chemin depuis un argument de niveau 1. Une même page peut donc produire plusieurs occurrences et apparaître à un niveau supérieur à son niveau minimal. La profondeur compte les arêtes : une occurrence de niveau 8 se trouve à une profondeur de 7.

## Réutilisations sans nouvelle page au niveau considéré

- Niveau 2 : **13** occurrence(s) réutilisée(s) — Bien des hommes ont fait la preuve de leur engagement pour le combat féministe; La solidarité masculine est construite sur le dénigrement et l'exclusion des femmes; Les hommes bénéficient des discriminations envers les femmes; Les hommes ne peuvent pas ne pas voir les violences et les discriminations sexistes; Les hommes ne peuvent pas rester insensibles au sort réservé à une moitié de l'humanité; Les hommes ont intérêt à en finir avec le machisme pour assumer leur sensibilité et leurs émotions; Les hommes ont intérêt à en finir avec le machisme pour se délivrer de l'injonction à la virilité; Les hommes ont intérêt à en finir avec le machisme pour simplifier et libérer les rapports de séduction; … (13 pages concernées)
- Niveau 3 : **40** occurrence(s) réutilisée(s) — Beaucoup d'hommes ne sont pas égoïstes; De nombreuses femmes préfèrent les hommes dominants; De nombreuses victimes n'osent pas parler des violences sexistes qu'elles ont subies, encore moins aux hommes; En renonçant à la virilité, les hommes perdraient leur pouvoir; L'expression des émotions affaiblirait la domination des hommes; L'injonction à la répression des émotions déteriore la santé mentale des hommes; L'éducation vise à développer notre empathie; L'émancipation des femmes doit être l'oeuvre des femmes elles-mêmes; … (28 pages concernées)
- Niveau 4 : **45** occurrence(s) réutilisée(s) — Beaucoup d'hommes ne sont pas égoïstes; Bien des hommes ont fait la preuve de leur engagement pour le combat féministe; L'éducation vise à développer notre empathie; La domination masculine est de nos jours largement contestée dans tous les domaines de la société; La manière dont le femmes sont traitées ne saurait être décrite autrement que comme de la déshumanisation; La socialisation vise à lutter contre notre égoïsme naturel; Le féminisme ne se décrédibilise jamais qu'aux yeux de ceux qui y sont déjà hostiles à la base; Le terme "déshumaniser" est démesuré, il y a une instrumentalisation des corps certes et une altère expression de la domination mais déshumaniser ne fait que décrédibiliser la cause féministe; … (17 pages concernées)
- Niveau 5 : **40** occurrence(s) réutilisée(s) — De nombreuses femmes préfèrent les hommes dominants; En renonçant à la virilité, les hommes perdraient leur pouvoir; L'expression des émotions affaiblirait la domination des hommes; L'injonction à la répression des émotions déteriore la santé mentale des hommes; La fin du sexisme entraînerait de nouvelles rivalités entre hommes et femmes; La manière dont le femmes sont traitées ne saurait être décrite autrement que comme de la déshumanisation; La rivalité est une source d'émulation; La virilité n'a pas que des mauvais côtés; … (14 pages concernées)

## Snapshot de provenance

Le wikicode de la page Débat et des 100 pages Argument est conservé dans `snapshot/pages/`.
Le fichier `snapshot/snapshot_manifest.json` associe chaque titre à sa révision, son URL, son empreinte SHA-256 et son fichier local.

## Frontières « débat détaillé »

Aucune.

## Informations sur les frontières

Aucune.

## Avertissements réels

Aucun.
