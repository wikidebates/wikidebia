# Audit du graphe — « Les hommes doivent-ils rejoindre le combat féministe ? »

**Résultat : RÉUSSI**

| Contrôle | Résultat | Détail |
|---|---:|---|
| racines uniques | OK | 10 |
| racines présentes | OK |  |
| nœuds uniques | OK | 100 |
| relations uniques | OK | 115 |
| types de relation | OK |  |
| endpoints présents | OK | [] |
| graphe sans cycle | OK | [] |
| frontières sans sorties | OK | [] |
| compteur nœuds | OK | 100/100 |
| compteur relations | OK | 115/115 |
| compteurs justification/objection | OK |  |
| somme des pages par niveau minimal | OK | 100/100 |
| somme des occurrences dépliées par niveau | OK | 238/238 |
| cohérence niveau maximal et profondeur en arêtes | OK | niveau=5; profondeur=4 |
| niveau minimal maximal inférieur ou égal au niveau maximal des occurrences | OK | (4, 5) |
| compteur des pages sans sortie | OK | 72 |
| compteur des feuilles réelles | OK | 72 |
| relations locales ignorées aux frontières | OK | 0 |
| aucune page manquante | OK | [] |
| snapshot complet | OK | {'argument_pages': 100, 'debate_pages': 1, 'total_pages': 101} |
| empreintes du snapshot | OK | 101 |
