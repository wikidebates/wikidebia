# Revue du graphe, des positions et des titres

Débat : `les_hommes_doivent_ils_rejoindre_le_combat_feministe`
Work : `EDIT-20261022-001`

Ce paquet a été préparé par Wikidéb’IA pour une intervention éditoriale externe.
Ne modifiez que les fichiers placés sous `editable/`. Les fichiers sous `context/` sont des sources en lecture seule.
Ne renommez, n'ajoutez et ne supprimez aucun fichier du ZIP.
Le fichier `REVIEW_PACKAGE.json` ne doit jamais être modifié.

Cette revue couvre en une seule étape les positions/relations du graphe, les suppressions/fusions/déplacements éventuels, les titres canoniques et les titres affichés.
Complétez aussi `reviews/fr/graph_title_review.json` pour tous les titres ; les rubriques, mots-clés, résumés et références restent hors de cette première revue.
Si la revue exige une modification structurelle, renseignez pour l'occurrence concernée l'objet `correction`.
Actions prises en charge : `remove`, `merge_redirect`, `move` et `relation_change`.
Pour `merge_redirect`, indiquez `target_node_id` : la page doublon deviendra `#REDIRECTION [[Titre de destination]]` et son lien sera retiré de la page mère.
Pour `remove`, indiquez `page_disposition=delete` : le lien sera retiré de la page mère avant suppression de la page.
Les décisions structurelles sont d’abord appliquées localement au graphe puis soumises à une nouvelle revue complète. Aucune page distante n’est modifiée pendant cette boucle.
Après réimport approuvé de ce même ZIP, toutes les mutations structurelles et de titres validées sont publiées immédiatement au premier checkpoint français, avec un résumé MediaWiki individualisé par page.
Pour un doublon, le résumé de la page mère mentionne la page conservée sous la forme `[[Titre de destination]]`.

## Fichiers à compléter

- `editable/reviews/graph_build_review.json`
- `editable/reviews/graph_placement_review.json`
- `editable/reviews/fr/graph_title_review.json`

Après la revue, rendez un ZIP conservant exactement la même structure, placez-le dans `incoming/`, puis lancez `./wikidebia review-import`. S'il y a plusieurs ZIP de revue dans `incoming/`, utilisez `./wikidebia review-import <debate_id>`.
