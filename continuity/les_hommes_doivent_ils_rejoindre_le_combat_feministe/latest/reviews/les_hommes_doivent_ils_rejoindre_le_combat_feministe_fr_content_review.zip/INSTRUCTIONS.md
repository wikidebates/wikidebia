# Revue du contenu français, des rubriques et des mots-clés

Débat : `les_hommes_doivent_ils_rejoindre_le_combat_feministe`
Work : `EDIT-20261023-001`

Ce paquet a été préparé par Wikidéb’IA pour une intervention éditoriale externe.
Ne modifiez que les fichiers placés sous `editable/`. Les fichiers sous `context/` sont des sources en lecture seule.
Ne renommez, n'ajoutez et ne supprimez aucun fichier du ZIP.
Le fichier `REVIEW_PACKAGE.json` ne doit jamais être modifié.

Cette revue porte sur les rubriques, mots-clés, documentation et autres contenus explicitement ouverts à la reprise.
Sur une page française préexistante, conservez les rubriques historiques autant que possible. Une correction (ajout/retrait) reste admise lorsqu’elle améliore réellement la classification ; consignez-la dans `preexisting_rubrique_change_rationale`. Le seul dépassement du profil 1–3/4 rubriques n’est pas un motif de correction.
Les quotas de mots-clés (2–4 pour un Argument, 5–8 pour un Débat) sont des profils de création et ne justifient jamais la suppression d’un mot-clé historique. En revanche, les règles qualitatives intrinsèques restent applicables : un mauvais mot-clé historique peut être corrigé, remplacé ou décomposé via `preexisting_keyword_corrections` avec une justification explicite.
Pour toute page préexistante importée du wiki, l’introduction du débat et les résumés des arguments sont préservés par défaut ; un résumé historiquement absent reste absent par défaut.
Vous pouvez signaler une anomalie et remplir `suggested_change` sans appliquer la suggestion : conservez alors `decision=keep`, `historical_text_status=preserved` et la valeur historique dans `proposed_*`.
Si le propriétaire a explicitement approuvé un changement, renseignez `decision=change`, la valeur finale dans `proposed_*`, `historical_text_status=authorization_requested` et un objet `historical_change_request` limité à ce champ, avec `field_key`, `final_value`, `change_type`, `rationale` et `owner_instruction_reference`.
Pour une introduction modifiée structurellement, ajoutez de préférence `change_scope` avec le delta exact des sous-parties (`added`, `modified`, `removed`, `reordered`). Ainsi une autorisation d’ajouter `Enjeux du débat` ne peut pas couvrir silencieusement une réécriture d’une autre sous-partie historique. Une réécriture explicitement large peut utiliser une portée `whole_field`.
Après autorisation, l’introduction ou le résumé final proposé devient la valeur éditoriale effective : tous les contrôles structurels, le verrou, le changeset, le rendu, le checkpoint 2 et la traduction doivent utiliser cette valeur finale. Les règles de création restent différentielles et ne s’appliquent qu’aux portions réellement ajoutées ou réécrites.
Une simple déclaration dans le ZIP ne vaut jamais consentement : sans preuve locale, `review-import` bloque. Après accord explicite du propriétaire, utilisez `./wikidebia review-import --authorize-historical-changes` (avec l’identifiant du débat seulement si nécessaire). Le kit scelle alors localement le ZIP exact et les SHA avant/après de chaque champ demandé.
N’étendez jamais une autorisation à un autre résumé ou à l’introduction entière si la décision propriétaire ne le couvre pas. Une correction locale autorisée ne déclenche pas rétroactivement toutes les préférences stylistiques de création.
Le checkpoint français n°2 publie normalement les rubriques, mots-clés, documentation et, lorsqu’ils sont autorisés, les deltas d’introduction/résumé ; aucune troisième frontière française n’est créée.

## Fichiers à compléter

- `editable/reviews/fr/content_review.json`
- `editable/data/sources_working.json`
- `editable/reviews/fr/classification_review.json`
- `editable/data/keyword_vocabulary_working.json`

Après la revue, rendez un ZIP conservant exactement la même structure, placez-le dans `incoming/`, puis lancez `./wikidebia review-import`. S'il y a plusieurs ZIP de revue dans `incoming/`, utilisez `./wikidebia review-import <debate_id>`.
