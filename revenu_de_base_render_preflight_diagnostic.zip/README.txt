Wikidéb’IA — diagnostic automatique de validation

Ce ZIP est généré automatiquement après un échec du validateur.
Il ne contient aucun secret ni état d’authentification.
Envoyez simplement ce ZIP à ChatGPT pour analyser toutes les erreurs en une fois.
La liste exhaustive se trouve dans ERRORS.json et ERRORS.txt.
