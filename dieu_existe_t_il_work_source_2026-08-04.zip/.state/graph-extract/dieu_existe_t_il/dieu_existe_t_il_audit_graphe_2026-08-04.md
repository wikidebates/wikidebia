# Audit du graphe — « Dieu existe-t-il ? »

**Résultat : RÉUSSI**

| Contrôle | Résultat | Détail |
|---|---:|---|
| racines uniques | OK | 25 |
| racines présentes | OK |  |
| nœuds uniques | OK | 680 |
| relations uniques | OK | 721 |
| types de relation | OK |  |
| endpoints présents | OK | [] |
| graphe sans cycle | OK | [] |
| frontières sans sorties | OK | [] |
| compteur nœuds | OK | 680/680 |
| compteur relations | OK | 721/721 |
| compteurs justification/objection | OK |  |
| somme des pages par niveau minimal | OK | 680/680 |
| somme des occurrences dépliées par niveau | OK | 1052/1052 |
| cohérence niveau maximal et profondeur en arêtes | OK | niveau=8; profondeur=7 |
| niveau minimal maximal inférieur ou égal au niveau maximal des occurrences | OK | (7, 8) |
| compteur des pages sans sortie | OK | 426 |
| compteur des feuilles réelles | OK | 417 |
| relations locales ignorées aux frontières | OK | 32 |
| aucune page manquante | OK | [] |
| snapshot complet | OK | {'argument_pages': 680, 'debate_pages': 1, 'total_pages': 681} |
| empreintes du snapshot | OK | 681 |
