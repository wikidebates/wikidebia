# Graphe argumentatif — « Dieu existe-t-il ? »

Date d’extraction : 2026-08-04
Extracteur : 1.0.1 (kit 2.15.4)

## Statistiques

| Niveau | Pages uniques | Occurrences |
|---:|---:|---:|
| 1 | 25 | 25 |
| 2 | 198 | 204 |
| 3 | 303 | 361 |
| 4 | 114 | 244 |
| 5 | 30 | 128 |
| 6 | 8 | 61 |
| 7 | 2 | 26 |
| 8 | 0 | 3 |

- Pages uniques : **680**
- Occurrences dépliées par chemins : **1052**
- Relations uniques : **721**
- Justifications : **194**
- Objections : **527**
- Niveau minimal maximal d’une page unique : **7**
- Niveau maximal d’une occurrence : **8**
- Profondeur maximale en nombre d’arêtes : **7**
- Pages sans sortie dans le graphe extrait : **426**
- Feuilles réelles : **417**
- Pages réutilisées : **155**
- Graphe sans cycle : **oui**

Une occurrence dépliée correspond à un chemin depuis un argument de niveau 1. Une même page peut donc produire plusieurs occurrences et apparaître à un niveau supérieur à son niveau minimal. La profondeur compte les arêtes : une occurrence de niveau 8 se trouve à une profondeur de 7.

## Réutilisations sans nouvelle page au niveau considéré

- Niveau 2 : **6** occurrence(s) réutilisée(s) — "Dieu est totalement bon mais il permet le mal le plus extrême" : c'est contradictoire; Dieu est un concept "bouche-trou"; Dieu n'est que le nom de notre ignorance; La liberté est inexplicable dans le cadre du matérialisme; Les expériences mystiques attestent la présence de Dieu; Si Dieu est omniscient, la création et la liberté sont inutiles
- Niveau 3 : **58** occurrence(s) réutilisée(s) — Certains courants religieux pensent que Dieu ne nous a même pas donné le libre arbitre; De nombreuses explication religieuses ont été remplacées par des explications scientifiques; Dieu est censé être omnipotent; Dieu est décrit comme tout puissant, mais est paradoxalement doté de failles typiquement humaines; Dieu est un concept "bouche-trou"; Dieu est une explication inexplicable; Dieu est une extrapolation des effets sur la cause; Dieu n'est que le nom de notre ignorance; … (51 pages concernées)
- Niveau 4 : **130** occurrence(s) réutilisée(s) — Attribuer l'entière responsabilité du mal aux humains contredit l'omniscience de Dieu; Avant d'expliquer un phénomène, il faut d'abord prouver son existence; C'est une récupération New Age de bas étage de prétendre que la science contemporaine tendrait vers la spiritualité; Ce n'est pas « tout » mais « tout effet » qui a une cause; Certains principes moraux sont erronément qualifiés d'invariants; Ces visions sont conditionnées par la culture et le milieu; Comparer Dieu à l'homme est une analogie légitime sous un certain rapport; De nombreuses explication religieuses ont été remplacées par des explications scientifiques; … (100 pages concernées)
- Niveau 5 : **98** occurrence(s) réutilisée(s) — Avant d'expliquer un phénomène, il faut d'abord prouver son existence; Beaucoup de scientifiques de renom avouent leur perplexité et tendent vers une vision spiritualiste de l'univers face aux découvertes contemporaines; C'est parce que la nature humaine "aspire" à "Dieu" que les humains ont créé cette notion de Dieu et que certains y croient; C'est une récupération New Age de bas étage de prétendre que la science contemporaine tendrait vers la spiritualité; Ce qui accrédite l'hypothèse de leur inexistence; Certaines choses qu'on croyait définitivement non explicables par la science ont fini par le devenir; Certaines religions disent que notre sort après la mort est indépendant de ce qu'on a fait de notre vivant; Compréhension insuffisante d'un phénomène; … (57 pages concernées)
- Niveau 6 : **53** occurrence(s) réutilisée(s) — Avant d'expliquer un phénomène, il faut d'abord prouver son existence; Beaucoup de scientifiques de renom avouent leur perplexité et tendent vers une vision spiritualiste de l'univers face aux découvertes contemporaines; C'est une récupération New Age de bas étage de prétendre que la science contemporaine tendrait vers la spiritualité; Ce n'est pas « tout » mais « tout effet » qui a une cause; Compréhension insuffisante d'un phénomène; Des cas décrits comme des possessions démoniaques sont aujourd'hui vus comme de simples troubles mentaux; Dieu est censé être omniscient; Dieu est hors du temps, donc sans cause; … (34 pages concernées)
- Niveau 7 : **24** occurrence(s) réutilisée(s) — Beaucoup de scientifiques de renom avouent leur perplexité et tendent vers une vision spiritualiste de l'univers face aux découvertes contemporaines; Dieu est un être simple; Il faut accepter le mystère; L'absence d'explication scientifique ne prouve pas l'existence de Dieu; L'existence implique par essence une temporalité; L'idée d'une cause première ne prouve ni n'infirme l'existence de Dieu; La cause première est inconnaissable; La science n'a jamais prétendu qu'elle pourra tout expliquer dans le futur; … (15 pages concernées)
- Niveau 8 : **3** occurrence(s) réutilisée(s) — Les athées affirment que l'univers antérieur au mur de planck est impossible à décrire, et non qu'il est sorti de "rien"; Un argument d'autorité n'est pas une preuve; Être scientifique n'immunise pas contre l'obscurantisme

## Snapshot de provenance

Le wikicode de la page Débat et des 680 pages Argument est conservé dans `snapshot/pages/`.
Le fichier `snapshot/snapshot_manifest.json` associe chaque titre à sa révision, son URL, son empreinte SHA-256 et son fichier local.

## Frontières « débat détaillé »

- **Il n'existe pas d'esprit en dehors de la matière** → Le matérialisme est-il vrai ? — 15 relation(s) locale(s) non suivie(s)
- **Il n'existe pas de libre-arbitre** → Sommes-nous libres de nos décisions ?
- **L'athéisme conduit au nihilisme, qui n'est pas vivable** → L'athéisme aboutit-il nécessairement au nihilisme ?
- **L'homme est déterminé** → Sommes-nous libres de nos décisions ?
- **L'homme est libre** → Sommes-nous libres de nos décisions ?
- **Les apparitions de la Vierge et ses prodiges à Fatima prouvent l'existence de Dieu** → Y a-t-il un miracle de la "danse du soleil" à Fatima au Portugal en 1917 ? — 13 relation(s) locale(s) non suivie(s)
- **Les religions se contredisent** → Les religions se rejoignent-elles ? — 2 relation(s) locale(s) non suivie(s)
- **On ne peut comprendre le mal que si la réincarnation existe** → La réincarnation existe-t-elle ? — 1 relation(s) locale(s) non suivie(s)
- **On peut être athée sans être nihiliste** → L'athéisme aboutit-il nécessairement au nihilisme ? — 1 relation(s) locale(s) non suivie(s)

Total des relations locales non suivies aux frontières : **32**.

## Informations sur les frontières

- Il n'existe pas d'esprit en dehors de la matière: frontière vers Le matérialisme est-il vrai ?; 15 relation(s) locale(s) non suivie(s)
- Les religions se contredisent: frontière vers Les religions se rejoignent-elles ?; 2 relation(s) locale(s) non suivie(s)
- On ne peut comprendre le mal que si la réincarnation existe: frontière vers La réincarnation existe-t-elle ?; 1 relation(s) locale(s) non suivie(s)
- Les apparitions de la Vierge et ses prodiges à Fatima prouvent l'existence de Dieu: frontière vers Y a-t-il un miracle de la "danse du soleil" à Fatima au Portugal en 1917 ?; 13 relation(s) locale(s) non suivie(s)
- On peut être athée sans être nihiliste: frontière vers L'athéisme aboutit-il nécessairement au nihilisme ?; 1 relation(s) locale(s) non suivie(s)

## Avertissements réels

Aucun.
