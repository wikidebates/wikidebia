# Initialisation du corpus — Dieu existe-t-il ?

Statut : `graph_draft`.

- Nœuds : 680
- Relations : 721
- Occurrences normatives : 746
- Pages sources importées : 681
- Normalisations ou replis consignés : 437

Les fichiers `imports/fr/` ne sont pas des pages de sortie validées.
