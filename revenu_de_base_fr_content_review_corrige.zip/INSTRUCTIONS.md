# Revue du contenu et de la documentation française

Débat : `revenu_de_base`
Work : `EDIT-20260811-001`

Ce paquet a été préparé par Wikidéb’IA pour une intervention éditoriale externe.
Ne modifiez que les fichiers placés sous `editable/`. Les fichiers sous `context/` sont des sources en lecture seule.
Ne renommez, n'ajoutez et ne supprimez aucun fichier du ZIP.
Le fichier `REVIEW_PACKAGE.json` ne doit jamais être modifié.

## Fichiers à compléter

- `editable/reviews/fr/content_review.json`
- `editable/data/sources_working.json`

Après la revue, rendez un ZIP conservant exactement la même structure. L'utilisateur lancera `./wikidebia review-import <debate_id> <zip>`.
