# Inventaire du contenu français

- Débat : `revenu_de_base`
- Arguments : 167
- Sous-parties importées : 7
- Articles Wikipédia importés : 1
- Résumés absents : 46
- Résumés de moins de 80 caractères : 47
- Citations importées : 97

Aucune correction automatique n’a été appliquée.
